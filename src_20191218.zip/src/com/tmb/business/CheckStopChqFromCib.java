package com.tmb.business;

import java.text.SimpleDateFormat;
import java.util.Properties;

import org.apache.log4j.Logger;

public class CheckStopChqFromCib {
	final static Logger logger = Logger.getLogger(CheckStopChqFromCib.class);
	private Properties prop;
	private SimpleDateFormat dateFormat;
	
	public CheckStopChqFromCib(Properties prop, SimpleDateFormat dateFormat) {
		this.prop = prop;
		this.dateFormat = dateFormat;
	}
	public void process(){
		
	}
}
