/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import connect.DbManagement;
import connect.EmailService;
import connect.FileSFTP;
import gen.ClearTempFile;
import gen.CompareFiles;
import gen.PHFileManagement;
import gen.Zipfile;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList; 
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import obj.DashbDataModel;
import obj.Pofile;
import obj.Tranfile;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;

import com.tmb.business.CLearTempDataNoti;
import com.tmb.business.CheckTransactionResponse;
import com.tmb.business.CompareFileMessageGenCbs;
import com.tmb.business.PickupPPRTransaction;
import com.tmb.business.PutFileSFTP;
import com.tmb.business.ReconcileFileFromCib;

import tmb.com.config.CSVManagementFile;
import tmb.com.config.TmbUtility;
import util.Constant;

/**
 *
 * @author Administrator
 */
public class PaymentClearFile {

    private static Log logger = LogFactory.getLog(PaymentClearFile.class);

    public static String config = System.getProperty("user.dir") + "/config/config.properties";
    private static ClearTempFile clearTempFile = null;
    private static CompareFiles compare = null;
    private static ReconcileFileFromCib recFileFromCib = null;
    private static CheckTransactionResponse checkTransRes = null;
    private  static CompareFileMessageGenCbs compareFileMessageGenCbs = null;  
    private  static CLearTempDataNoti   cLearTempDataNoti = null;
    private static PutFileSFTP  putFileSFTP = null;
    private static String paramAction = null;
    private  static PickupPPRTransaction pickupPPRTransaction  = null;

    public static void main(String[] args) {
        if (args.length <= 0 || StringUtils.isEmpty(args[0])) {
            //usage();
            return;
        }

        paramAction = !TmbUtility.isNull(args[0]) ? args[0].trim() : "";

        if (paramAction.equalsIgnoreCase(Constant.Part.COMPARE)) {
            loadConfig(1);
        } else {
            loadConfig(0);
        }
        Properties prop = new Properties();

        File share = null;
        File shareReupload = null;

        try {

            logger.debug(config);

            prop.load(new FileInputStream(config));

            TmbUtility.checkAndCreateFolders(prop.getProperty("file.share.path"));
            TmbUtility.checkAndCreateFolders(prop.getProperty("file.share.path.report"));
            TmbUtility.checkAndCreateFolders(prop.getProperty("file.share.reupload"));

            SimpleDateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"), Locale.UK);

            compare = new CompareFiles(prop, dateFormat);
            recFileFromCib = new ReconcileFileFromCib(prop, dateFormat);
            checkTransRes = new CheckTransactionResponse(prop, dateFormat);
            clearTempFile = new ClearTempFile(prop);
            // Get file backup node CPPP 2 
            if (paramAction.equalsIgnoreCase(Constant.Part.GET)) {
                logger.info(" ########### copy data from filebackup ################ ");

                File file = new File(prop.getProperty("file.backup.path"));
                if (file.list().length <= 0) {
                    throw new Exception("No file in Backup");
                } else {
                    compare.copyFileFolder(file);
                }

            } else if (paramAction.equalsIgnoreCase(Constant.Part.COMPARE)) {
                // Get file backup node CPPP 1 for  compare 

                Connection conn = null;

                try {

                    //Part Get
                    File bfile = new File(prop.getProperty("file.backup.path"));
                    //File bfile = new File(prop.getProperty("file.backup2.path"));
                    if (bfile.list().length <= 0) {
                        throw new Exception("No file in Backup");
                    } else {
                        compare.copyFileFolder(bfile);
                    }

                    //path Compare
                    share = new File(prop.getProperty("file.share.path"));
                    //path reupload
                    shareReupload = new File(prop.getProperty("file.share.reupload"));

                    FileUtils.cleanDirectory(shareReupload);

                    if (share.list().length <= 0) {
                        logger.info("No files in logs");
                    }

                    conn = new DbManagement(prop).connection();

                    /* find from db file partial create po */
                    List<Tranfile> tranfiles = compare.comparePartialCratePO(conn);

                    /* find from db file inprogress ,preupload   */
                    tranfiles = compare.checkFileStuckDASHF(tranfiles);

                    /* find from db file rejected , missing   */
                    List<Pofile> fileList = compare.compareLogsWithDb(share, conn, tranfiles);

                    if (fileList != null && fileList.size() > 0) {
                        if (tranfiles == null) {
                            tranfiles = new ArrayList<>();
                        }
                        for (Pofile tf : fileList) {
                            if (TmbUtility.containFileName(tranfiles, tf.getFileName()) == false) {
                                Tranfile trf = new Tranfile();
                                trf.setBatStatus(tf.getSanityStatus());
                                if (!TmbUtility.isNull(tf.getErrDesc())) {
                                    trf.setBatStatus(tf.getSanityStatus() + " : " + TmbUtility.getEmptyString(tf.getErrDesc()));
                                }

                                trf.setInOutFileName(tf.getFileName());

                                if (tf.getUploadDateStr() != null) {
                                    trf.setTrandate(tf.getUploadDateStr());
                                    tf.setUploadDate(TmbUtility.convertStringtoDate(tf.getUploadDateStr(), TmbUtility.yyyyMMddHHmmss));
                                    trf.setDifferenceInMinutes("" + TmbUtility.diffTime(tf.getUploadDate(), new Date()));
                                }
                                trf.setCurdate(TmbUtility.yyyyMMddHHmmss.format(new Date()));
                                if (trf.getCountMsd() == 0) {
                                    int cMsd = compare.countCon(conn, prop.getProperty("db.count.msd"), trf);
                                    if (cMsd == 0) {

                                        cMsd = CSVManagementFile.readCountTextFile("TXN", share.getAbsolutePath() + "/" + trf.getInOutFileName() + tf.getRemark());
                                    }
                                    trf.setCountMsd(cMsd);
                                }
                                tranfiles.add(trf);
                            }

                        }
                        logger.debug(" End  step loop set diff time 1 ");

                        for (int i = 0; i < tranfiles.size(); i++) {
                            if (tranfiles.get(i).getTrandate() == null) {
                                Pofile p = compare.getDataShown(conn, tranfiles.get(i).getInOutFileName());
                                Tranfile tranfileTemp = tranfiles.get(i);
                                if (p != null && p.getUploadDateStr() != null) {

                                    tranfileTemp.setTrandate(p.getUploadDateStr());
                                    tranfileTemp.setCurdate(TmbUtility.yyyyMMddHHmmss.format(new Date()));
                                } else {
                                    tranfileTemp.setTrandate(TmbUtility.getDateTimeOfFile(tranfileTemp.getInOutFileName().trim()));
                                    if (tranfileTemp.getTrandate() != null) {
                                        Date mDate = TmbUtility.convertStringtoDate(tranfileTemp.getTrandate(), TmbUtility.yyyyMMddHHmmss);
                                        if (mDate != null) {
                                            tranfileTemp.setDifferenceInMinutes("" + TmbUtility.diffTime(mDate, new Date()));
                                        } else {
                                            tranfileTemp.setDifferenceInMinutes("0");
                                        }
                                    }
                                }

                                tranfiles.set(i, tranfileTemp);
                            }
                            if (tranfiles.get(i).getCountMsd() == 0) {
                                Tranfile tranfileTemp2 = tranfiles.get(i);
                                int cnt = CSVManagementFile.readCountTextFile("TXN", share.getAbsolutePath() + "/" + tranfileTemp2.getInOutFileName());
                                tranfileTemp2.setCountMsd(cnt);
                                tranfiles.set(i, tranfileTemp2);
                            }

                           // logger.debug("Trandate = " + tranfiles.get(i).getTrandate());
                            try {
                                PHFileManagement.copyFileUsingApacheCommonsIO(new File(share + File.separator + tranfiles.get(i).getInOutFileName()), new File(shareReupload + File.separator + tranfiles.get(i).getInOutFileName()));
                            } catch (Exception e) {
                                e.getLocalizedMessage();
                                logger.error("error copyFiles share path to reupload path >> " + tranfiles.get(i).getInOutFileName());
                            }

                        }
                        logger.debug(" End  step loop set diff time 2");
                    }

                    if (!fileList.isEmpty()) {
                        new Zipfile(fileList, prop);

                        try {
                            FileSFTP sftp = new FileSFTP(prop);
                            sftp.putFileToSftp();
                        } catch (Exception e) {
                            logger.error(e);
                        }
                    }
                    logger.debug(" Start  step check data DASHB ");
                    Date startDB = new  Date();
                    /*find  from DB  monitor dash board  batch / file  status   */
                    List<DashbDataModel> dashbList = clearTempFile.getDataDASHB();
                    Date endDB = new  Date();
                     logger.debug(" End  step check data DASHB used time >> "+TmbUtility.diffTimeStr(startDB, endDB));
                    if (!fileList.isEmpty() || !tranfiles.isEmpty() || !dashbList.isEmpty()) {
                         logger.debug(" start  step sending...  email  ");
                        new EmailService(prop).sendEmail(tranfiles, dashbList);
                    } else {
                        logger.info("No data to send email");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error(e);
                } finally {
                    String fileName = prop.getProperty("file.name.prefix")
                            + dateFormat.format(new Date()) + "." + Constant.TypeFile.ZIP;
                    new File(fileName).delete();
                    logger.debug("Remove local file");
                    FileUtils.cleanDirectory(share);
                    logger.debug("Clean Directory " + share.getAbsolutePath());
                    if (conn != null) {
                        conn.close();
                    }
                    //logger.info("Database Connection close");
                }
            } else if (paramAction.equalsIgnoreCase(Constant.Part.DELETE)) {
                ClearTempFile.clearFileFolder(TmbUtility.getTempPoPath());

                shareReupload = new File(prop.getProperty("file.share.reupload"));
                if (shareReupload.exists()) {
                    FileUtils.cleanDirectory(shareReupload);
                }

                FileSFTP fileSFTP = new FileSFTP(prop);

                logger.info("############# START PICKUP FILE FROM SFTP FOR DELETE FILE ###################");
                //if (TmbUtility.isWindows()) {
                //  fileSFTP.readFileForClearPO();
                //} else {
                //fileSFTP.getFileFromSftp(); //PROD ,UAT
                //}
                clearTempFile = new ClearTempFile(prop);

                clearTempFile.checkFileForClear();
                // File fLogs = new File(System.getProperty("user.dir") + "/LOG/logs.log");
                //if (fLogs.exists()) {
                //	Zipfile.ZipfileLogs(fLogs, prop);

                try {
                    //FileSFTP sftp = new FileSFTP(prop);
                    fileSFTP.putFileToSftpLogs();
                } catch (Exception e) {
                    logger.error(e);
                }
                //}
                // new EmailService(prop).sendEmailLogs(fLogs);

            } else if (paramAction.equalsIgnoreCase(Constant.Part.TRANTRACKING_REPORT)) {

                FileUtils.cleanDirectory(new File(prop.getProperty("file.share.path.report")));

                DbManagement db = new DbManagement(prop);

                Connection conn = db.connection();

                StringBuilder sqlScripts = CSVManagementFile.readTextFileAppend(System.getProperty("user.dir") + "/config/scripts_trantracking.txt");

                List<String> dataList = db.inquiryTrantrackingReportDataStr(conn, sqlScripts.toString(), args);

                if (dataList != null && dataList.size() > 0) {
                    // Date reportDate = new Date();
                    // logger.debug(" data size = " + dataList.size());
                    String sharePath = prop.getProperty("file.share.path.report") + "trantrackingReport_" + TmbUtility.formateDateYYYYMMDD(new Date()) + ".csv";
                    if (args != null && args.length >= 2 && args[1] != null) {
                        //  reportDate = TmbUtility.sdfYYYYMMDD.parse(args[1]);
                        sharePath = prop.getProperty("file.share.path.report") + "trantrackingReport_" + args[1] + ".csv";
                    } else {
                        sharePath = prop.getProperty("file.share.path.report") + "trantrackingReport_" + TmbUtility.formateDateYYYYMMDD(new Date()) + ".csv";
                    }
                    CSVManagementFile.fileWriter(null, null, dataList, sharePath);
                    //File file = new File("Trantracking_" + dateFormat.format(dateReport) + "." + Constant.TypeFile.ZIP);

                    File fileReport = new File(sharePath);
                    try {
                        if (fileReport.exists()) {

                            //Zipfile.ZipfileLogs(fileReport, "Trantracking_", prop, reportDate);
                            FileSFTP fileSFTP = new FileSFTP(prop);
                            fileSFTP.putFileToSftpLogs(sharePath);
                            //new EmailService(prop).sendEmailToUser(fileReport, reportDate);

                        }

                    } catch (Exception e) {
                        logger.error(e.getLocalizedMessage());
                        e.printStackTrace();
                    }

                }

            } else if (paramAction.equalsIgnoreCase(Constant.Part.RECON_CIB_PH)) {
                /* generate report and  send email to user , CVS file   */

                //path Get
                File bfile = new File(prop.getProperty("file.backup.path"));
                //File bfile = new File(prop.getProperty("file.backup2.path"));
                if (bfile.list().length <= 0) {
                    logger.error("No file in Backup.");
                    //throw new Exception("No file in Backup");
                } else {
                    compare.copyFileFolder(bfile);
                }

                //path Compare
                share = new File(prop.getProperty("file.share.path"));
                if (!share.exists()) {
                    share.mkdirs();
                }

                if (share.list().length <= 0) {
                    logger.info("No files in logs");
                }

                recFileFromCib.reconcileCIBWithPH(share);
            } else if (paramAction.equalsIgnoreCase(Constant.DoAction.MODE_AUTO_DELETE)) {

                logger.info("#########  Action >> Start  MODE_AUTO_DELETE #########");

                shareReupload = new File(prop.getProperty("file.share.reupload"));

                if (shareReupload.list().length <= 0) {
                    logger.info(" Not found  files in path >>  " + shareReupload);
                } else {

                    InputStream in = new FileInputStream(new File(System.getProperty("user.dir") + "/config/templateAutoDelete.html"));
                    String templateAutodelete = IOUtils.toString(in, Charset.forName(Constant.CharSet.UTF));

                    String autoDelete = prop.getProperty("auto.delete.file");
                    String autoMove = prop.getProperty("AUTO_MOVE_PO_FILE");

                    logger.debug("#### Open mode auto delete file : " + autoDelete + " ,auto Move  fille " + autoMove);

                    String detail_data = "";

                    if (prop != null && !TmbUtility.isNull(autoDelete) && autoDelete.equalsIgnoreCase(Constant.ParamerConfig.AUTO_DELETE)) {
                        String files[] = shareReupload.list();

                        if (files != null && files.length > 0) {
                            detail_data = "";
                            try {
                                for (String filelReupload : files) {

                                    detail_data += "<TR bgcolor=\"#c0c0c0\"> "
                                            + "<th align=\"left\" >" + filelReupload + "</th>";

                                    boolean isMovedFile = false;
                                    try {
                                        if (filelReupload != null && filelReupload.length() > 0 && filelReupload.startsWith("PAYREQ")) {

                                            boolean deleteCompleted = (!clearTempFile.verifyFileNameCPYCKV(filelReupload)) ? true : clearTempFile.automateClearFile(filelReupload);

                                            if (!TmbUtility.isNull(autoMove)
                                                    && autoMove.equalsIgnoreCase(Constant.ParamerConfig.AUTO_MOVE_FILE_PO)) {

                                                 // logger.debug("deleteCompleted  :  " + deleteCompleted);
                                                    
                                                if (deleteCompleted) {
                                                    isMovedFile = clearTempFile.autoMoveBackupToPayshare(shareReupload, filelReupload);
                                                    if (isMovedFile) {
                                                        logger.debug("#### System moved file was completed : File name :  " + filelReupload);
                                                         detail_data += "<th align=\"center\">" + "completed" + "</th> </TR>";
                                                    } else {
                                                        logger.debug("#### System moved file was failed : File name :  " + filelReupload);
                                                        detail_data += "<th align=\"center\">" + "Failed" + "</th> </TR>";
                                                    }
                                                } else {
                                                    detail_data += "<th align=\"center\">" + "Failed,Data was completed (if want to delete , Pls manaul force delete file)" + "</th> </TR>";
                                                }
                                            } else {
                                                detail_data += "<th align=\"center\">" + "Failed,Paramerter do not set 'AUTO_MOVE_FILE_PO' " + "</th> </TR>";
                                            }
                                        }
                                    } catch (Exception exp) {
                                        exp.printStackTrace();
                                        detail_data += "<th align=\"center\">" + "Failed," + exp.getLocalizedMessage() + "</th> </TR>";
                                    }

                                }
                            } catch (Exception ex) {
                                ex.printStackTrace();
                                logger.error(" error == " + ex.getLocalizedMessage());
                            } finally {
                                logger.debug("Remove share reupload  all files ");
                                FileUtils.cleanDirectory(shareReupload);
                            }

                            templateAutodelete = templateAutodelete.replaceAll("#TOTAL_FILES", files.length + "");
                            templateAutodelete = templateAutodelete.replaceAll("#DETAIL_OF_DATA", detail_data);
                            //
                        } else {

                            detail_data += "<TR bgcolor=\"#c0c0c0\"><th colspan=\"2\" align=\"center\"> No data not found</th></TR>";

                            templateAutodelete = templateAutodelete.replaceAll("#TOTAL_FILES", "0");
                            templateAutodelete = templateAutodelete.replaceAll("#DETAIL_OF_DATA", detail_data);
                        }

                    }

                    new EmailService(prop).sendEmailAutoDelete(templateAutodelete);
                }
                logger.info("#########  Action >> end  MODE_AUTO_DELETE #########");
            }
            else if (paramAction.equalsIgnoreCase(Constant.DoAction.CHECK_TRANS_RESPONSE)) {
            	checkTransRes = new CheckTransactionResponse(prop, dateFormat);
            	checkTransRes.process(); 
            } 
            else if (paramAction.equalsIgnoreCase(Constant.DoAction.AUTO_PUT_SFTP_FILE)) {
            	putFileSFTP  = new PutFileSFTP(prop);
            	putFileSFTP.process();
            }
            else if (paramAction.equalsIgnoreCase(Constant.DoAction.COMPARE_FILE_MESSAGE_GEN)) {
            	compareFileMessageGenCbs = new CompareFileMessageGenCbs(prop, dateFormat);
            	compareFileMessageGenCbs.process();
            	 
            } else if (paramAction.equalsIgnoreCase(Constant.DoAction.CLEAR_TEMP_NOTI)) {
            	cLearTempDataNoti = new CLearTempDataNoti(prop);
            	cLearTempDataNoti.process();
            	 
            }else if (paramAction.equalsIgnoreCase(Constant.DoAction.PICKUP_PPR_STRUCK)) {
            	pickupPPRTransaction = new PickupPPRTransaction(prop);
            	pickupPPRTransaction.process();
            	 
            }


        } catch (Exception e) {
            e.printStackTrace();
            logger.error(" >> The  end  " + e.getLocalizedMessage());
        }

    }

    private static void loadConfig(int flag) {
        switch (flag) {
            case 1:
                PropertyConfigurator.configure(System.getProperty("user.dir") + "/config/log4jCompare.properties");
                break;
            case 2:
                PropertyConfigurator.configure(System.getProperty("user.dir") + "/config/log4j.properties");
                break;
            default:
                PropertyConfigurator.configure(System.getProperty("user.dir") + "/config/log4j.properties");

        }
        if (StringUtils.isEmpty(config)) {
            config = System.getProperty("user.dir") + "/config/config.properties";
        }
        logger = LogFactory.getLog(PaymentClearFile.class);

    }

    /*
    private static void usage() {
        System.out.println("Usage command");
        System.out.println("\tjava -Dconfig.file=${config.properties} -jar ${JobRec.jar} ${part}");
        System.out.println("\tUse -Dconfig.file=${config.properties} to get your config");
        System.out.println("\tUse -jar ${JobRec.jar} to get your jarfile to run");
        System.out.println("\tUse ${part} to get part of program (get|compare)");
    }*/
}
