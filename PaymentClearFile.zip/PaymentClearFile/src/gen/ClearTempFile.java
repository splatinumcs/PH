package gen;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

import obj.Pofile;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tmb.com.config.CSVManagementFile;
import tmb.com.config.ConnectDB;
import tmb.com.config.TmbUtility;
import util.Constant;
import connect.DbManagement;
import connect.EmailService;

public class ClearTempFile {

    private static Log logger = LogFactory.getLog(ClearTempFile.class);

    public static String config = System.getProperty("user.dir") + "/config/config.properties";
    public static String scripts = System.getProperty("user.dir") + "/config/scripts.txt";
    public static String listfilename = "";//System.getProperty("user.dir") + "/config/FILES_NAME.txt";
    private Properties prop = null;
    private CSVManagementFile fileMGT = new CSVManagementFile();

    public ClearTempFile(Properties prop) {
        this.prop = prop;

    }

    public void checkFileForClear() {

        String[] filesApp = new File(TmbUtility.getTempPoPath()).list();
        if (filesApp != null && filesApp.length > 1) {

            for (String scrfile : filesApp) {
                String tempFile = scrfile;
                scrfile = new File(TmbUtility.getTempPoPath()).getAbsolutePath() + File.separator + scrfile;
                if (new File(scrfile).isFile()
                        && tempFile != null
                        && tempFile.trim().startsWith("PAYREQ_CLEAR_FILE")
                        && tempFile.trim().endsWith(".TXT")) {
                    listfilename = scrfile;
                    break;
                }

            }

        }
        logger.info("list filename = " + listfilename);
        if (!TmbUtility.isNull(listfilename)) {
            List<String> listFiles = fileMGT.readTextFile(listfilename);
            PreparedStatement ps = null;
            Connection conn = null;
            String fileTmp = "";
            logger.info("################# START PROCESSING DELETE FILE #####################");
            int cntFile = 0;
            for (String fl : listFiles) {
                fileTmp = fl;
                if (!fileTmp.isEmpty() && fileTmp.startsWith("PAYREQ") && fileTmp.trim().length() > 5) {

                    if (!fileTmp.isEmpty()
                            && fileTmp.trim().length() > 1
                            && verifyFileNamebeforeDelete(fileTmp)
                            && verifyFileNameCPYCKV(fileTmp)) {
                        //fileTmp = "'"+fileTmp+"'";
                        cntFile += 1;
                        logger.info("################# No.Of [" + 1 + "] file name for delete is =" + fileTmp);
                        int countRecs = 0;
                        int records = 0;
                        List<String> listFile = fileMGT.readTextFile(scripts);
                        try {
                            conn = new DbManagement(prop).connection();

                            for (String scpt : listFile) {

                                if (!scpt.isEmpty() && scpt.startsWith("delete") && scpt.trim().length() > 5) {
                                    records = 0;
                                    
                                    // create our java preparedstatement using a sql update query
                                    ps = conn.prepareStatement(scpt.trim());
                                    // call executeUpdate to execute our sql update statement
                                    ps.setString(1, fileTmp);
                                    records = ps.executeUpdate();
                                    logger.info(" update  records =  "+records+"   ### "+scpt);
                                    //logger.info("records = " + records);
                                    //ps.close();
                                    countRecs += records;
                                }
                            }
                            if (conn != null) {
                                conn.commit();
                            }
                            logger.info("################# Results of processed  delete file ###############");
                            if (countRecs >= 1) {
                                logger.info("################# Delete file was successfully.[" + fileTmp + "]");
                            } else {
                                logger.info("################# Delete file was failed. [" + fileTmp + "]");
                            }

                        } catch (SQLException se) {
                            try {
                                if (conn != null) {
                                    conn.rollback();
                                }
                            } catch (SQLException e) {

                                logger.error(e.getLocalizedMessage());
                            }
                            if (ps != null) {
                                try {
                                    ConnectDB.closePreparedStatement(ps);
                                } catch (Exception e) {

                                    logger.error(e.getLocalizedMessage());
                                }
                            }
                            if (conn != null) {
                                try {
                                    ConnectDB.closeConnection(conn);
                                } catch (Exception e) {
                                    logger.error(e.getLocalizedMessage());
                                }
                            }
                            se.printStackTrace();
                            logger.error(se.getLocalizedMessage());
                        } catch (Exception se) {
                            try {
                                if (conn != null) {
                                    conn.rollback();
                                }
                            } catch (SQLException e) {

                                logger.error(e.getLocalizedMessage());
                            }
                            if (ps != null) {
                                try {
                                    ConnectDB.closePreparedStatement(ps);
                                } catch (Exception e) {

                                    logger.error(e.getLocalizedMessage());
                                }
                            }
                            if (conn != null) {
                                try {
                                    ConnectDB.closeConnection(conn);
                                } catch (Exception e) {
                                    logger.error(e.getLocalizedMessage());
                                }
                            }

                            logger.error(se.getLocalizedMessage());
                        } finally {
                            if (ps != null) {
                                try {
                                    ConnectDB.closePreparedStatement(ps);
                                } catch (Exception e) {

                                    logger.error(e.getLocalizedMessage());
                                }
                            }
                            if (conn != null) {
                                try {
                                    ConnectDB.closeConnection(conn);
                                } catch (Exception e) {
                                    logger.error(e.getLocalizedMessage());
                                }
                            }
                        }

                    }

                }
            }

            File srcFile = new File(listfilename);
            CSVManagementFile.moveFileDesc(srcFile, new File(TmbUtility.getTempPoBKPath()).getAbsolutePath(), srcFile.getName(), true);

        } else {
            logger.info("source file for delete  not  found .");
            //System.exit(0);
        }

    }

    public boolean verifyFileNameCPYCKV(String fileName) {

        Connection conn = new DbManagement(prop).connection();
        Calendar calendar = Calendar.getInstance(Locale.UK);
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        String startCurDate = new SimpleDateFormat(prop.getProperty("mail.dateformat"), Locale.UK).format(calendar.getTime());

        String endDate = new SimpleDateFormat(prop.getProperty("mail.dateformat"), Locale.UK).format(new Date());

        int cnt = 0;
        boolean verifyPass = true;
        PreparedStatement preStmt = null;
        String sqlCheck = "select count(1) from custom.cpyckv where file_name = ?   ";
        logger.info("verify FileName CPYCKV =" + sqlCheck);

        try {
            preStmt = conn.prepareStatement(sqlCheck);
            preStmt.setString(1, fileName);
            //preStmt.setString(2, startCurDate);
            //preStmt.setString(3, endDate); 
            ResultSet rs = preStmt.executeQuery();

            if (rs.next()) {
                cnt = rs.getInt(1);

            }
            //logger.info("cnt = " + cnt);
            preStmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getLocalizedMessage());
        } finally {
            try {
                preStmt.close();
            } catch (SQLException e) {
                logger.error(e.getLocalizedMessage());
            }
            try {
                conn.close();
            } catch (SQLException e) {
                logger.error(e.getLocalizedMessage());
            }
        }
        if (cnt <= 0) {
            verifyPass = false;
            logger.info("File not found : " + fileName);
        }
        return verifyPass;
    }

    public boolean verifyFileNamebeforeDelete(String fileName) {

        Connection conn = new DbManagement(prop).connection();
        Calendar calendar = Calendar.getInstance(Locale.UK);
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        PreparedStatement preStmt = null;
        String startCurDate = new SimpleDateFormat(prop.getProperty("mail.dateformat"), Locale.UK).format(calendar.getTime());

        String endDate = new SimpleDateFormat(prop.getProperty("mail.dateformat"), Locale.UK).format(new Date());

        //logger.info("startCurDate = " + startCurDate);
        //logger.info("endDate = " + endDate);
        //int cnt = 0;
        boolean verifyPass = true;
        int cntMsd = 0;
        int cntEd = 0;
        int cntCtxnrec = 0;
        int cntCbatrec = 0;

        String sqlCheck = " select "
                + " (select  count(1) from tbaadm.py_msd where batch_hdr_srl_num in (select hdr_srl_num from tbaadm.py_fhd  "
                + " where in_out_file_name in (?) and file_hdr_srl_num is not null)) as msd,  "
                + "  (select count(1) from tbaadm.py_ed  "
                + " where batch_header_srl_num in (select hdr_srl_num from tbaadm.py_fhd   "
                + " where in_out_file_name in (?) and file_hdr_srl_num is not null)) as ed,  "
                + "  (select count(1) from custom.ctxnrec where fp_batch_ref_num in (  "
                + " select fp_bat_ref_num from CUSTOM.cbatrec where batch_id in (  "
                + " select hdr_srl_num from tbaadm.py_fhd   "
                + " where in_out_file_name in (?) and file_hdr_srl_num is not null))) as ctxnrec,  "
                + " (select count(1) from CUSTOM.cbatrec where batch_id in (select hdr_srl_num from tbaadm.py_fhd   "
                + " where in_out_file_name in (?) and file_hdr_srl_num is not null)) as cbatrec "
                + " from dual ";

        try {
            preStmt = conn.prepareStatement(sqlCheck);
            preStmt.setString(1, fileName);
            preStmt.setString(2, fileName);
            preStmt.setString(3, fileName);
            preStmt.setString(4, fileName);
            ResultSet rs = preStmt.executeQuery();

            if (rs.next()) {
                cntMsd = rs.getInt(1);
                cntEd = rs.getInt(2);
                cntCtxnrec = rs.getInt(3);
                cntCbatrec = rs.getInt(4);

            }
            //logger.info("cnt = " + cnt);
            preStmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
            logger.error(e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getLocalizedMessage());
        } finally {
            try {
                preStmt.close();
            } catch (SQLException e) {
                logger.error(e.getLocalizedMessage());
            }
            try {
                conn.close();
            } catch (SQLException e) {
                logger.error(e.getLocalizedMessage());
            }
        }
        if (cntMsd > 0 && cntEd > 0 && cntCtxnrec > 0 && cntCbatrec > 0) {
            if (cntEd == cntCtxnrec) {
                logger.info("This file [" + fileName + "] was processed completed. Please recheck.");
                verifyPass = false;
            }
        }

        return verifyPass;
    }

    public static void clearFileFolder(String SRC_FOLDER) {

        File directory = new File(SRC_FOLDER);

        //make sure directory exists
        if (!directory.exists()) {
            directory.mkdirs();
            //System.out.println("Directory does not exist.");
            // System.exit(0);

        } else {
            //directory.mkdir();
            try {

                delete(directory);

            } catch (IOException e) {
                e.printStackTrace();
                System.exit(0);
            }
        }
        File directoryBK = new File(TmbUtility.getTempPoBKPath());

        //make sure directory exists
        if (!directoryBK.exists()) {
            directoryBK.mkdirs();
        }
        //System.out.println("Done");
    }

    public static void delete(File file)
            throws IOException {

        if (file.isDirectory()) {

            //directory is empty, then delete it
            if (file.list().length == 0) {

                file.delete();
              //  System.out.println("Directory is deleted : " + file.getAbsolutePath());

            } else {

                //list all the directory contents
                String files[] = file.list();

                for (String temp : files) {
                    //construct the file structure
                    File fileDelete = new File(file, temp);
                    if (fileDelete.isFile()) {
                        fileDelete.delete();
                    }
                    //recursive delete
                    // delete(fileDelete);
                }

                //check the directory again, if empty then delete it
                if (file.list().length == 0) {
                    file.delete();
                    System.out.println("Directory is deleted : "
                            + file.getAbsolutePath());
                }
            }

        } else {
            //if file, then delete it
            file.delete();
            System.out.println("File is deleted : " + file.getAbsolutePath());
        }
    }
    /*String sqlCheck = "SELECT SUM(cnt) from (                                                                               "
    + "    (SELECT count(1)as cnt from(                                                                                "
    + "        select IN_OUT_FILE_NAME, cp.UPLOAD_DATE,cp.SANITY_STATUS,cp.ERR_DESC                                    "
    + "        from tbaadm.PY_MSD MS, tbaadm.py_fhd fh,custom.cpyckv cp                                                "
    + "        WHERE ms.batch_hdr_srl_num = fh.hdr_Srl_num                                                             "
    + "        AND fh.file_hdr_srl_num is not null                                                                     "
    + "        AND cp.file_name = fh.IN_OUT_FILE_NAME                                                                  "
    + "        AND cp.file_name = ?               "
    + "        AND cp.err_desc is  null                                                                                "
    + "        AND b2k_id is  not null                                                                                 "
    + "        AND trunc(cp.upload_date)                                                                               "
    + "        between to_date(? ,'DD-MM-YYYY')                                                             "
    + "        AND to_date(? ,'DD-MM-YYYY')                                                                 "
    + "        AND fh.status ='R'                                                                                      "
    + "        AND cp.sanity_Status='S'                                                                                "
    + "        AND MS.STATUS IN ('P','J','R','E')                                                                      "
    + "        AND ms.bank_id = fh.bank_id                                                                             "
    + "        AND ms.bank_id = '011'                                                                                  "
    + "        group by IN_OUT_FILE_NAME,cp.UPLOAD_DATE,cp.SANITY_STATUS,cp.ERR_DESC                                   "
    + "        ))                                                                                                      "
    + "        union all                                                                                               "
    + "        (                                                                                                       "
    + "        SELECT count(1)as cnt                                                                                   "
    + "        FROM tbaadm.cbatrec bat LEFT JOIN tbaadm.py_fhd fhd ON ( bat.batch_id = fhd.hdr_srl_num )               "
    + "        WHERE fhd.in_out_file_name = ?     "
    + "        AND trunc(bat.rcre_time) = trunc(SYSDATE)                                                               "
    + "        AND fhd.file_hdr_srl_num IS NOT NULL                                                                    "
    + "        AND ABS(( ( SYSDATE - bat.rcre_time) * 24 * 60 )) > 15                                                  "
    + "         )     "
    + "        ) ";*/
}
