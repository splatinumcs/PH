package gen;

import obj.Pofile;
import obj.Tranfile;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import connect.DbManagement;
import tmb.com.config.TmbUtility;
import util.Constant;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import java.util.stream.Collectors;

public class CompareFiles {

    final static Logger logger = Logger.getLogger(CompareFiles.class);
    private Properties prop;
    public static String sqlCheckFileStatus
            = " SELECT count(1),FILE_NAME ,ROUND(ABS(((sysdate - UPLOAD_DATE) * 24 * 60 ))) as  difference_in_minutes,  'preupload' from custom.cpyckv "
            + " WHERE   trunc(UPLOAD_DATE)                                                                                                      "
            + " between to_date(? ,'DD-MM-YYYY')                                                                                     "
            + " AND to_date(? ,'DD-MM-YYYY')                                                                                         "
            + " AND  sanity_status ='S'                                                                                                         "
            + " AND bank_id = '011'                                                                                                             "
            + " AND ABS(((sysdate - UPLOAD_DATE) * 24 * 60 )) > 20                                                                              "
            + " AND not exists (select 1 from tbaadm.py_fhd                                                                                     "
            + " where  in_out_file_name = FILE_NAME                                                                                             "
            + " AND FILE_HDR_SRL_NUM is null AND bank_id = '011' )                                                                              "
            + " group by FILE_NAME,UPLOAD_DATE                                                                                                  "
            + " union all                                                                                                                       "
            + " SELECT count(1),IN_OUT_FILE_NAME ,ROUND(ABS(((sysdate - UPLOAD_DATE) * 24 * 60 ))) as  difference_in_minutes,'inprogress' from(         "
            + "   select IN_OUT_FILE_NAME, cp.UPLOAD_DATE,cp.SANITY_STATUS,cp.ERR_DESC                                                          "
            + "   from tbaadm.PY_MSD MS, tbaadm.py_fhd fh,custom.cpyckv cp                                                                      "
            + "   WHERE ms.batch_hdr_srl_num = fh.hdr_Srl_num                                                                                   "
            + "   AND fh.file_hdr_srl_num is not null                                                                                           "
            + "   AND cp.file_name = fh.IN_OUT_FILE_NAME                                                                                        "
            + "   AND ms.b2k_id is  null                                                                                                        "
            + "   AND trunc(cp.upload_date)                                                                                                     "
            + "   between to_date(? ,'DD-MM-YYYY')                                                                                   "
            + "   AND to_date(? ,'DD-MM-YYYY')                                                                                       "
            + "   AND fh.status ='R'                                                                                                            "
            + "   AND cp.sanity_Status='S'                                                                                                      "
            + "   AND MS.STATUS !='P'                                                                                                           "
            + "   AND cp.err_desc is  null                                                                                                      "
            + "   AND ms.bank_id = fh.bank_id                                                                                                   "
            + "   AND ms.bank_id = '011'                                                                                                        "
            + "   AND ABS(((sysdate - UPLOAD_DATE) * 24 * 60 )) > 20                                                                            "
            + "   AND ms.BATCH_HDR_SRL_NUM NOT IN (SELECT BATCH_HDR_SRL_NUM FROM TBAADM.PY_MSD                                                  "
            + "           WHERE STATUS ='P'                                                                                                     "
            + "           AND BANK_ID =  '011'                                                                                                  "
            + "           AND TRUNC(IN_OUT_DATE)                                                                                                "
            + "           BETWEEN TO_DATE(?,'DD-MM-YYYY')                                                                            "
            + "           AND TO_DATE(? ,'DD-MM-YYYY'))                                                                              "
            + "           and not exists (select * from tbaadm.py_fhd where status !='R'                                                        "
            + "           and   cp.file_name = IN_OUT_FILE_NAME)                                                                                "
            + "           group by IN_OUT_FILE_NAME,cp.UPLOAD_DATE,cp.SANITY_STATUS,cp.ERR_DESC                                                 "
            + "           order by cp.upload_date desc) group by IN_OUT_FILE_NAME,UPLOAD_DATE                                                   ";
    /*+ " union all                                                                                                                       "
            + "  select count(1),FILE_NAME ,ABS(((sysdate - upldDate) * 24 * 60 )) as  diff_minute,'rejected' from (                            "
            + "           SELECT FILE_NAME,UPLOAD_DATE as upldDate ,SANITY_STATUS,ERR_DESC                                                      "
            + "           from custom.cpyckv                                                                                                    "
            + "           WHERE                                                                                                 "
            + "            trunc(UPLOAD_DATE)                                                                                                "
            + "           between to_date(? ,'DD-MM-YYYY')                                                                           "
            + "           AND to_date(? ,'DD-MM-YYYY')                                                                               "
            + "           AND  (sanity_status ='F' or err_desc is not null)                                                                     "
            + "           AND bank_id = '011'                                                                                                   "
            + "                                                                                                                                 "
            + "           and not exists (select * from tbaadm.py_fhd                                                                           "
            + "                             where status!='R'                                                                                   "
            + "                             and in_out_file_name=file_name )                                                                    "
            + "                             UNION ALL                                                                                           "
            + "                             select in_out_file_name,IN_OUT_DATE as upldDate,STATUS, ERR_MSG                                     "
            + "                             from tbaadm.py_fhd p                                                                                "
            + "                             where status != 'R'                                                                                 "
            + "                             AND in_out_file_name                                                                                "
            + "                             LIKE concat(concat('%',''),'%')                                                                  "
            + "                             AND trunc(in_out_date)                                                                              "
            + "                             between to_date(?,'DD-MM-YYYY')                                                          "
            + "                             AND to_date(?,'DD-MM-YYYY')                                                              "
            + "                             AND bank_id = '011'                                                                                 "
            + "                             and ( (substr(hdr_srl_num,1,1)='B') or (substr(hdr_srl_num,1,1)='F'                                 "
            + "                             and not exists(select * from tbaadm.py_fhd                                                          "
            + "                             where substr(hdr_srl_num,1,1)='B'                                                                   "
            + "                             and in_out_file_name=p.in_out_file_name                                                             "
            + "                             and status != 'R'                                                                                   "
            + "                             and in_out_date=p.in_out_date and bank_id= '011')))                                                 "
            + "                             order by upldDate desc )                                                                            "
            + "                             where ABS(((sysdate - upldDate) * 24 * 60 )) > 20                                                   "
            + "                             group by FILE_NAME, upldDate                                                                        ";*/

    SimpleDateFormat dateFormat;

    String fileDBMissing = "";
    String fileDBError = "";
    String fileNotFound = "";
    String fileInprogress = "";
    String filePreupload = "";

    public CompareFiles(Properties prop, SimpleDateFormat dateFormat) {
        this.prop = prop;
        this.dateFormat = dateFormat;
    }

    public void copyFileFolder(File file) {

        logger.info("Copy file backup folder ");
        String dateStr = dateFormat.format(new Date());

        //logger.debug("From : " + file.getPath());
        Arrays.stream(file.listFiles()).filter(f -> dateFormat.format(f.lastModified()).equals(dateStr))
                .forEach(f -> {
                    try {
                        File nf = new File(prop.getProperty("file.share.path") + f.getName());
                        if (nf.exists()) {
                            //logger.debug("Duplicate File name : " + nf.getName());
                        } else {
                            FileUtils.copyFile(f, nf);
                            //logger.debug("Copy File name : " + nf.getName());
                        }

                    } catch (IOException e) {
                        logger.error(e);
                    }

                });

        logger.debug("To : " + prop.getProperty("file.share.path"));
        logger.info("Copy file complete!!");
    }

    public List<Pofile> compareLogsWithDb(File file, Connection conn, List<Tranfile> tranfiles) throws SQLException {

        Date date = new Date();
        String dateStr = dateFormat.format(date);
        PreparedStatement preStmt = null;

        fileDBMissing = "." + prop.getProperty("file.db.missing");
        fileDBError = "." + prop.getProperty("file.db.error");
        fileNotFound = "." + prop.getProperty("file.not.found");
        fileInprogress = "." + prop.getProperty("file.status.inproress");
        filePreupload = "." + prop.getProperty("file.status.preupload");

        try {
            preStmt = conn.prepareStatement(prop.getProperty("db.select"));
            logger.debug("PreparedStatement : " + prop.getProperty("db.select"));

            ResultSet rs = preStmt.executeQuery();
            logger.debug("PreparedStatement executeQuery complete!!");

            logger.info("Compare logs with database..");

            List<Pofile> dbPofiles = new ArrayList<>();
            List<Pofile> selectList = new ArrayList<>();
            while (rs.next()) {

                String fileName = rs.getString(Constant.DbCol.FILE_NAME);
                String sanityStatus = rs.getString(Constant.DbCol.SANITY_STATUS);
                String errDesc = rs.getString(Constant.DbCol.ERR_DESC);
                Date uploadDate = rs.getDate(Constant.DbCol.UPLOAD_DATE);

                Pofile pofile = new Pofile();

                pofile.setFileName(fileName);
                pofile.setSanityStatus(sanityStatus);
                pofile.setErrDesc(errDesc);
                pofile.setUploadDate(uploadDate);
                dbPofiles.add(pofile);

            }

            preStmt.close();

            //Add diff file
            Arrays.stream(file.listFiles())
                    .filter(f -> ((dateStr.equals(dateFormat.format(f.lastModified())))))
                    .forEach(fn -> {
                        logger.debug(" file name :  "+fn.getName());
                        if (fn.getName().startsWith("PAYREQ") && fn.getName().endsWith(".TXT")) {
                            Pofile pofile = containPofiles(dbPofiles, fn.getName());
                            Pofile pofile2 = containfilesTruck(tranfiles, fn.getName());
                            if (pofile == null) {
                                //Add file MISSING
                                Pofile newPofile = new Pofile();
                                newPofile.setFileName(fn.getName());
                                newPofile.setRemark(fileDBMissing);
                                newPofile.setSanityStatus("MISSING");
                                newPofile.setPofile(fn);

                                selectList.add(newPofile);
                            } else if (pofile.getSanityStatus() != null && pofile.getSanityStatus().equals("F")) {
                                //Add file REJECTED
                                pofile.setRemark(fileDBError);
                                pofile.setSanityStatus("REJECTED");
                                pofile.setPofile(fn);
                                selectList.add(pofile);
                            }
                            if (pofile2 != null) {
                                Pofile newPofile = new Pofile();
                                newPofile.setFileName(fn.getName());
                                newPofile.setRemark("." + pofile2.getSanityStatus());
                                newPofile.setSanityStatus(pofile2.getSanityStatus());
                                newPofile.setPofile(fn);
                                selectList.add(newPofile);
                            }
                        }

                    });
            //Add file not found
            /*dbPofiles.stream().forEach(p->{
				File f = containfiles(Arrays.asList(file.listFiles()),p.getFileName());
				if (f == null){
					if (p.getSanityStatus() == null || !p.getSanityStatus().equals("S")){
						p.setRemark(fileNotFound+fileDBError);
					}else {
						p.setRemark(fileNotFound);
					}
					selectList.add(p);
				}
			});*/

 /*   APPEND SUBFIX TO FILE_NAME_ORIGINAL*/
            Set<String> names = new HashSet<>();
            selectList.forEach(p -> {

                String name = p.getFileName();
                String originalName = name;
                for (int i = 1; !names.add(name); i++) {
                    name = originalName + "_" + i;
                }

                try {
                    File f = new File(file.getPath() + File.separator + name + p.getRemark());
                    if (p.getPofile() == null) {
                        f.createNewFile();
                    } else {
                        FileUtils.copyFile(p.getPofile(), f);
                    }

                    // logger.debug("Add file " + p.getRemark() + " : " + name);
                    p.setPofile(f);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            if (selectList.isEmpty()) {
                logger.info("No files Missing on Database");
            } else {
                logger.debug("Move logs to Result");
                logger.debug("Path " + Constant.Folder.RESULT + File.separator);
                return selectList;
            }

            //            logging(file,dbFiles);
            return selectList;

        } catch (SQLException e) {
            logger.error(e);
        } finally {
            preStmt.close();
        }

        return null;
    }

    public List<Tranfile> comparePartialCratePO(Connection conn) throws SQLException {

        logger.info("Compare cPartial Crate PO pending..");

        List<Tranfile> allTranfiles = new ArrayList<>();
        List<Tranfile> tranfiles = new ArrayList<>();

        PreparedStatement preStmt = null;

        //logger.debug("PreparedStatement : " + prop.getProperty("db.select.batch"));
        try {
            preStmt = conn.prepareStatement(prop.getProperty("db.select.batch"));
            ResultSet rs = preStmt.executeQuery();
            // logger.debug("PreparedStatement executeQuery complete!!");

            logger.info("Compare logs with database..");

            int i = 0;
            while (rs.next()) {
                Tranfile tranfile = new Tranfile();
                tranfile.setInOutFileName(rs.getString("in_out_file_name"));
                tranfile.setBatStatus("PARTIAL CREATE PO");
                tranfile.setTrandate(rs.getString("trandate"));
                tranfile.setCurdate(rs.getString("curdate"));
                tranfile.setCountMsd(countCon(conn, prop.getProperty("db.count.msd"), tranfile));
                tranfile.setDifferenceInMinutes(rs.getString("difference_in_minutes"));

                allTranfiles.add(tranfile);
            }

            preStmt.close();

            //logger.debug("PreparedStatement : " + prop.getProperty("db.count.msd"));
            //logger.debug("PreparedStatement : " + prop.getProperty("db.count.ed"));
            //  logger.debug("PreparedStatement : " + prop.getProperty("db.count.ctx"));
            allTranfiles.forEach(f -> {
                try {
                    int countMsd = countCon(conn, prop.getProperty("db.count.msd"), f);
                    int countEd = countCon(conn, prop.getProperty("db.count.ed"), f);
                    int countCtx = countCon(conn, prop.getProperty("db.count.ctx"), f);

                    logger.debug("Count compare " + f.getInOutFileName() + " "
                            + ":  Msd=" + countMsd + ",ED=" + countEd + ",Ctx=" + countCtx);

                    if ((countMsd != countEd) || (countEd != countCtx)) {
                        f.setCountCtx(countCtx);
                        f.setCountMsd(countMsd);
                        tranfiles.add(f);
                        logger.debug("Add File Pending : " + f.getInOutFileName());
                    }

                } catch (SQLException e) {
                    logger.error(e);
                }

            });

            if (tranfiles.isEmpty()) {
                logger.info("No Tranfile pending");
            } else {
                logger.info("Complete Tranfile pending!!");
            }

        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();
        } finally {
            preStmt.close();
        }

        return tranfiles;
    }

    public List<Tranfile> checkFileStuckDASHF(List<Tranfile> tranfilesMain) throws SQLException {

        logger.info("Check File Stuck DASHF..");
        //System.getProperty("user.dir") + "/config/config.properties";
        Connection conn = new DbManagement(prop).connection();
        List<Tranfile> allTranfiles = new ArrayList<>();
        Calendar calendar = Calendar.getInstance(Locale.US);
        //calendar.add(Calendar.DAY_OF_MONTH, -1);
        String startCurDate = TmbUtility.DD_MM_YYYY.format(calendar.getTime());

        String curDate = TmbUtility.DD_MM_YYYY.format(new Date());
        String curentDate = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.US).format(new Date());

        PreparedStatement preStmt = conn.prepareStatement(sqlCheckFileStatus);
        //logger.info(sqlCheckFileStatus);

        try {
            preStmt.setString(1, startCurDate);
            preStmt.setString(2, curDate);
            preStmt.setString(3, startCurDate);
            preStmt.setString(4, curDate);
            preStmt.setString(5, startCurDate);
            preStmt.setString(6, curDate);
            //preStmt.setString(7, startCurDate);
            //preStmt.setString(8, curDate);
            //preStmt.setString(9, startCurDate);
            //preStmt.setString(10, curDate);

            ResultSet rs = preStmt.executeQuery();
            // logger.debug("PreparedStatement executeQuery complete!!");

            //logger.info("Compare logs with database..");
            //int i = 0;
            while (rs.next()) {
                //logger.info("rs.getString(1) " + rs.getString(1));
                //logger.info("rs.getString(2) " + rs.getString(2));
                //logger.info("rs.getString(4) " + rs.getString(4));
                //  logger.info(" FILE STATUS = " + rs.getString(4) + " , Total = " + rs.getInt(1));
                Tranfile tranfile = new Tranfile();
                tranfile.setInOutFileName(rs.getString(2));
                tranfile.setBatStatus(rs.getString(4));
                tranfile.setTrandate(null);
                tranfile.setCurdate(curentDate);
                tranfile.setDifferenceInMinutes(rs.getString(3));
                int cMsd = countCon(conn, prop.getProperty("db.count.msd"), tranfile);
                //logger.debug("cMsd =" + cMsd);
                tranfile.setCountMsd(cMsd);
                //db.count.msd
                allTranfiles.add(tranfile);
            }

            preStmt.close();

            //logger.debug("PreparedStatement : " + prop.getProperty("db.count.msd"));
            //logger.debug("PreparedStatement : " + prop.getProperty("db.count.ed"));
            //logger.debug("PreparedStatement : " + prop.getProperty("db.count.ctx"));
            if (allTranfiles.isEmpty()) {
                //logger.info("No Tranfile pending");
            } else {
                logger.info("Complete Tranfile pending!!");
            }

        } finally {
            if (preStmt != null) {
                preStmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        if (allTranfiles != null && allTranfiles.size() > 0) {
            if (tranfilesMain == null || tranfilesMain.size() <= 0) {
                tranfilesMain = new ArrayList<>();
            }
            for (Tranfile tf : allTranfiles) {
                tranfilesMain.add(tf);
            }
        }

        return tranfilesMain;
    }

    public Pofile getDataShown(Connection conn, String fileName) throws SQLException {

        PreparedStatement countstmt = null;
        int count = 0;
        Pofile pofile = null;
        try {

            countstmt = conn.prepareStatement("select * from cpyckv where to_date(sysdate,'DD/MM/YYYY') = to_date(upload_date,'DD/MM/YYYY') and file_name = ? ");
            countstmt.setString(1, fileName);

            ResultSet rs = countstmt.executeQuery();
            if (rs.next()) {
                pofile = new Pofile();
                // String fileNameT = rs.getString(Constant.DbCol.FILE_NAME);
                String sanityStatus = rs.getString(Constant.DbCol.SANITY_STATUS);
                String errDesc = rs.getString(Constant.DbCol.ERR_DESC);
                Date uploadDate = rs.getDate(Constant.DbCol.UPLOAD_DATE);

                pofile.setFileName(fileName);
                pofile.setSanityStatus(sanityStatus);
                pofile.setErrDesc(errDesc);
                pofile.setUploadDate(uploadDate);

            }

        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();
        } finally {
            countstmt.close();
        }

        return pofile;
    }

    public int countCon(Connection conn, String sql, Tranfile f) throws SQLException {

        PreparedStatement countstmt = null;
        int count = 0;

        try {

            countstmt = conn.prepareStatement(sql);
            countstmt.setString(1, f.getInOutFileName());

            ResultSet rs = countstmt.executeQuery();
            while (rs.next()) {
                count = rs.getInt("count");
            }

        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();
        } finally {
            countstmt.close();
        }

        return count;
    }

    private Pofile containPofiles(List<Pofile> list, String id) {
        List<Pofile> pofile = list.stream().filter(p -> (p.getFileName().equals(id))).collect(Collectors.toList());
        return pofile.isEmpty() ? null : pofile.get(0);
    }

    private Pofile containfilesTruck(List<Tranfile> list, String id) {
        Pofile pofile = new Pofile();

        List<Tranfile> file = list.stream().filter(p -> (p.getInOutFileName().equals(id))).collect(Collectors.toList());
        if (!file.isEmpty() && file != null) {

            pofile = new Pofile();
            pofile.setFileName(file.get(0).getInOutFileName());
            pofile.setSanityStatus(file.get(0).getBatStatus());
            pofile.setErrDesc(file.get(0).getBatStatus());
            pofile.setUploadDate(new Date());
        } else {
            pofile = null;
        }

        return pofile;
    }
}
