/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tmb.com.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.util.Properties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory; 

/**
 *
 * @author N186
 */
public class ConnectDB {
private static final Log logger = LogFactory.getLog(ConnectDB.class); 
    /*public static void makeConnection(String DriverName) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/custom", "root", "password");
            //here sonoo is database name, root is username and password  
            Statement stmt = (Statement) con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from users");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        }

    }

    public static void makeConnectionSQLSERVER() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1529:PAYHUAT", "username", "password");
            //here sonoo is database name, root is username and password  
            Statement stmt = (Statement) con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from users");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        }

    }*/
    public static Connection makeConnectionOracle(Properties prop,String FlagDataBase) throws Exception {
        Connection con = null;
        logger.debug("makeConnectionOracle ==== "+FlagDataBase);
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
           /* StringBuilder urlCon = new StringBuilder("\"jdbc:oracle:thin:@");
            urlCon.append(prop.getProperty("database_server").trim());
            urlCon.append(":" + prop.getProperty("database_port").trim());
            urlCon.append(":" + prop.getProperty("database_servicename").trim()+"\"");
            urlCon.append(",\"" + prop.getProperty("database_user").trim() + "\",\"" + prop.getProperty("database_password").trim()+"\"");
            System.out.println(""+urlCon.toString());*/
            logger.debug("database_url_"+FlagDataBase);
            logger.debug("makeConnectionOracle == "+prop.getProperty("database_url_"+FlagDataBase).trim());
            con = DriverManager.getConnection(prop.getProperty("database_url_"+FlagDataBase).trim(), "custom", "custom");
            con.setAutoCommit(false);
            //here sonoo is database name, root is username and password  
            // Statement stmt = (Statement) con.createStatement();  
            // ResultSet rs=stmt.executeQuery("select * from users");  
            // while(rs.next())  
            //System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
            // con.close();  
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
            throw e;
        }
        return con;

    }

    public static void closeConnection(Connection conn) throws Exception {
        if (conn != null) {
            conn.close();
        }

    }

    public static void closeStatement(Statement stmt) throws Exception {
        if (stmt != null) {
            stmt.close();
        }

    }
    public static void closePreparedStatement(PreparedStatement stmt) throws Exception {
        if (stmt != null) {
            stmt.close();
        }

    }
    public static void closeResultSet(ResultSet rs) throws Exception {
        if (rs != null) {
            rs.close();
        }

    }
}
