/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tmb.com.config;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author 47758
 */
public class ApachePOIExcelRead {

    private static final String FILE_NAME = "D:\\Payment Hub Project\\PH_Phase 2.2\\Copy of TMBPH_MIS_AML_IFD_P2.2_V.0.3(SignOff).xlsx";

    /*public static void main(String[] args) {
        String[] arr = new String[50];
        try {

            FileInputStream excelFile = new FileInputStream(new File(FILE_NAME));
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet datatypeSheet = (Sheet) workbook.getSheetAt(2);
            Iterator<Row> iterator = datatypeSheet.iterator();
            int row = -1;
            while (iterator.hasNext()) {
                row++;

                //System.out.println("row == " + row);
                Row currentRow = iterator.next();
                if (row >= 8 && row <= 38) {
                    //System.out.println("in row == " + row);
                    Iterator<Cell> cellIterator = currentRow.iterator();
                    int col = -1;
                    while (cellIterator.hasNext()) {
                        col++;
                        Cell currentCell = cellIterator.next();
                        //getCellTypeEnum shown as deprecated for version 3.15
                        //getCellTypeEnum ill be renamed to getCellType starting from version 4.0
                        if (col == 4 || col == 5 || col == 11 || col == 12) {
                            String value = getValueCell(currentCell);
                            arr[col] = value;
                            //System.out.println("col == " + col + ", value = " + value);

                        }

                    }

                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }*/

    public static List<String[]> getSpecPPRFile(String fileName,int startRow,int endRow,int sheetNo) {
        List<String[]> list = new ArrayList<String[]>();
       

        try {
            fileName = (fileName == null || fileName.trim().equals("")) ? FILE_NAME : fileName;
            FileInputStream excelFile = new FileInputStream(new File(fileName));
            Workbook workbook = null;
            if(fileName.toLowerCase().endsWith("xlsx")){
                workbook = new XSSFWorkbook(excelFile);
            }else{
               workbook = new  HSSFWorkbook(excelFile);
            } 
            Sheet datatypeSheet = (Sheet) workbook.getSheetAt(sheetNo);
            Iterator<Row> iterator = datatypeSheet.iterator();
            int row = -1;
            System.out.println("SheetName == " + datatypeSheet.getSheetName());
            while (iterator.hasNext()) {
                row++;

                //System.out.println("row == " + row);
                Row currentRow = iterator.next();
                //221
                if (row >= startRow && row <= endRow) {
                    //System.out.println("in row == " + row);
                    Iterator<Cell> cellIterator = currentRow.iterator();
                    int col = -1;
                    String[] arr = new String[6];

                    while (cellIterator.hasNext()) {
                        col++;
                        Cell currentCell = cellIterator.next();
                        //getCellTypeEnum shown as deprecated for version 3.15
                        //getCellTypeEnum ill be renamed to getCellType starting from version 4.0
                        if (col >=0 && col <= 5) {
                            String value = getValueCell(currentCell);
                            //if (col == 1 && (value == null || value.trim().equals(""))) {
                               // break;
                            //}
                            arr[col] = value;
                           // System.out.print(" value = " + value + ",");

                        }

                    }
                   // System.out.println("");
                   // if (arr[1] != null && !arr[1].trim().equals("")) {
                        list.add(arr);
                    //}

                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<String[]> getSpecFile(String fileName) {
        List<String[]> list = new ArrayList<String[]>();

        try {
            fileName = (fileName == null || fileName.trim().equals("")) ? FILE_NAME : fileName;
            FileInputStream excelFile = new FileInputStream(new File(fileName));
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet datatypeSheet = (Sheet) workbook.getSheetAt(2);
            Iterator<Row> iterator = datatypeSheet.iterator();
            int row = -1;
            while (iterator.hasNext()) {
                row++;

                //System.out.println("row == " + row);
                Row currentRow = iterator.next();
                if (row >= 8 && row <= 38) {
                    //System.out.println("in row == " + row);
                    Iterator<Cell> cellIterator = currentRow.iterator();
                    int col = -1;
                    String[] arr = new String[25];
                    while (cellIterator.hasNext()) {
                        col++;
                        Cell currentCell = cellIterator.next();
                        //getCellTypeEnum shown as deprecated for version 3.15
                        //getCellTypeEnum ill be renamed to getCellType starting from version 4.0
                        if (col == 2 || col == 6 || col == 7 || col == 12 || col == 21) {
                            String value = getValueCell(currentCell);
                            arr[col] = value;
                            //System.out.println("col == " + col + ", value = " + value);

                        }

                    }
                    list.add(arr);
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static String getValueCell(Cell currentCell) {
        String value = "";
        if (currentCell.getCellTypeEnum() == CellType.STRING) {
            value = currentCell.getStringCellValue();
        } else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
            value = "" + (long) new BigDecimal(currentCell.getNumericCellValue()).intValue();
        } else if (currentCell.getCellTypeEnum() == CellType.FORMULA) {
            switch (currentCell.getCachedFormulaResultType()) {
                case Cell.CELL_TYPE_NUMERIC:
                    value = "" + (long) new BigDecimal(currentCell.getNumericCellValue()).intValue();
                    //System.out.println("value 1 ===" + value);
                    break;
                case Cell.CELL_TYPE_STRING:
                    if (currentCell.getRichStringCellValue() != null && !currentCell.getRichStringCellValue().toString().trim().equalsIgnoreCase("")
                            && checkIsNumber(currentCell.getRichStringCellValue().toString().trim())) {
                        //System.out.println("RichStringCell == "+currentCell.getRichStringCellValue().toString());
                        value = "" + Long.valueOf(currentCell.getRichStringCellValue().toString());
                    } else {
                        value = currentCell.getRichStringCellValue().toString();
                    }

                    //System.out.println("value 2 == " + value);
                    break;
            }

        }
        return value;
    }

    private static boolean checkIsNumber(String value) {
        boolean chk = false;
        try {
            if (value != null) {
                Long.valueOf(value.trim());
                chk = true;
            } else {
                chk = false;
            }
        } catch (Exception e) {
            chk = false;
        }
        return chk;
    }

}
