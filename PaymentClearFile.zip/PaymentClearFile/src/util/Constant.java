package util;

public final class Constant {


    public final class Part{
        public static final String GET  = "get";
        public static final String COMPARE  = "compare";
        public static final String DELETE  = "delete";
        public static final String TRANTRACKING_REPORT  = "TRANTRACKING_REPORT";
    }

    public final class Session{
        public static final String OPEN_CHANNEL = "sftp";
    }

    public final class Folder{
        public static final String Temp = "temp_file_node_";
        public static final String TempFilePO = "D:/app/staging/in/cib/TMB_FILE_PO/";
        public static final String TempFilePOBK = "D:/app/staging/in/cib/TMB_FILE_PO/BK/";
         public static final String LINUX_TempFilePO = "/app/staging/in/cib/TMB_FILE_PO/";
        public static final String LINUX_TempFilePOBK = "/app/staging/in/cib/TMB_FILE_PO/BK/";
        
        public static final String RESULT = "result";
    }

    public final class DbCol{
        public static final String UPLOAD_DATE = "UPLOAD_DATE";
        public static final String FILE_NAME = "FILE_NAME";
        public static final String SANITY_STATUS = "SANITY_STATUS";
        public static final String ERR_DESC = "ERR_DESC";
    }

    public final class TypeFile{
        public static final String ZIP = "zip";
        public static final String ERR = ".ERR";
        public static final String MSS = ".MSS";
    }

    public final class CharSet{
        public static final String UTF = "UTF-8";
        public static final String HTML_TYPE = "text/html; charset=utf-8";
    }

    public final class Cryto {
        public static final String ALGORITHM = "AES";
        public static final String KEY = "1Hbfh667adfDEJ78";
    }
}