/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import connect.DbManagement;
import connect.EmailService;
import connect.FileSFTP;
import gen.ClearTempFile;
import gen.CompareFiles;
import gen.Zipfile;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import obj.Pofile;
import obj.Tranfile;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;
import tmb.com.config.TmbUtility;
import util.Constant;

/**
 *
 * @author Administrator
 */
public class PaymentClearFile {

    private static Log logger = LogFactory.getLog(PaymentClearFile.class);

    public static String config = System.getProperty("user.dir") + "/config/config.properties";
    private static ClearTempFile clearTempFile = null;

    public static void main(String[] args) {
        //args = new String[1];
        //args[0] ="get"; 
        // args[0] = "delete";
        PropertyConfigurator.configure(System.getProperty("user.dir") + "/config/log4j.properties");
        logger = LogFactory.getLog(PaymentClearFile.class);

        if (args.length <= 0 || StringUtils.isEmpty(args[0])) {
            //usage();
            return;
        }

        Properties prop = new Properties();

        File share = null;

        try {
            if (StringUtils.isEmpty(config)) {
                config = System.getProperty("user.dir") + "/config/config.properties";
            }

            prop.load(new FileInputStream(config));
            //custom log file
            //  if (!StringUtils.isEmpty(prop.getProperty("log.config.file"))){
            // PropertyConfigurator.configure(prop.getProperty("log.config.file"));
            // }

            //logger.info("Load configuration file");
            // logger.debug("from " + config);
            SimpleDateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"), Locale.UK);
            CompareFiles compare = new CompareFiles(prop, dateFormat);

            // Get file backup node CPPP 2 
            if (args[0].equalsIgnoreCase(Constant.Part.GET)) {
                logger.info(" ########### copy data from filebackup ################ ");

                File file = new File(prop.getProperty("file.backup.path"));
                if (file.list().length <= 0) {
                    throw new Exception("No file in Backup");
                } else {
                    compare.copyFileFolder(file);
                }

            } else if (args[0].equalsIgnoreCase(Constant.Part.COMPARE)) {
                // Get file backup node CPPP 1 for  compare 

                Connection conn = null;

                try {

                    //Part Get
                    File bfile = new File(prop.getProperty("file.backup.path"));
                    //File bfile = new File(prop.getProperty("file.backup2.path"));
                    if (bfile.list().length <= 0) {
                        throw new Exception("No file in Backup");
                    } else {
                        compare.copyFileFolder(bfile);
                    }

                    //Part Compare
                    share = new File(prop.getProperty("file.share.path"));
                    if (!share.exists()) {
                        share.mkdirs();
                    }

                    if (share.list().length <= 0) {
                        logger.info("No files in logs");
                    }

                    conn = new DbManagement(prop).connection();
                    List<Pofile> fileList = compare.compareLogsWithDb(share, conn);

                    if (!fileList.isEmpty()) {
                        new Zipfile(fileList, prop);

                        try {
                            FileSFTP sftp = new FileSFTP(prop);
                            sftp.putFileToSftp();
                        } catch (Exception e) {
                            logger.error(e);
                        }
                    }

                    List<Tranfile> tranfiles = compare.compareTranfile(conn);
                    tranfiles = compare.checkFileStuckDASHF(tranfiles);
                    if (!fileList.isEmpty() || !tranfiles.isEmpty()) {
                        new EmailService(prop).sendEmail(tranfiles);
                    } else {
                        logger.info("No data to send email");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error(e);
                } finally {
                    String fileName = prop.getProperty("file.name.prefix")
                            + dateFormat.format(new Date()) + "." + Constant.TypeFile.ZIP;
                    new File(fileName).delete();
                    logger.debug("Remove local file");
                    FileUtils.cleanDirectory(share);
                    logger.debug("Clean Directory " + share.getAbsolutePath());
                    if (conn != null) {
                        conn.close();
                    }
                    //logger.info("Database Connection close");
                }
            } else if (args[0].equalsIgnoreCase(Constant.Part.DELETE)) {

                FileSFTP fileSFTP = new FileSFTP(prop);
                ClearTempFile.clearFileFolder(TmbUtility.getTempPoPath());
                logger.info("############# START PICKUP FILE FROM SFTP FOR DELETE FILE ###################");
                if (TmbUtility.isWindows()) {
                    fileSFTP.readFileForClearPO();
                } else {
                    fileSFTP.getFileFromSftp(); //PROD ,UAT
                }
                clearTempFile = new ClearTempFile(prop);

                clearTempFile.checkFileForClear();
                // File fLogs = new File(System.getProperty("user.dir") + "/LOG/logs.log");
                //if (fLogs.exists()) {
                //	Zipfile.ZipfileLogs(fLogs, prop);

                try {
                    FileSFTP sftp = new FileSFTP(prop);
                    sftp.putFileToSftpLogs();
                } catch (Exception e) {
                    logger.error(e);
                }
                //}
                // new EmailService(prop).sendEmailLogs(fLogs);

            }

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
        }

    }

    /*
    private static void usage() {
        System.out.println("Usage command");
        System.out.println("\tjava -Dconfig.file=${config.properties} -jar ${JobRec.jar} ${part}");
        System.out.println("\tUse -Dconfig.file=${config.properties} to get your config");
        System.out.println("\tUse -jar ${JobRec.jar} to get your jarfile to run");
        System.out.println("\tUse ${part} to get part of program (get|compare)");
    }*/
}
