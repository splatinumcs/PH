/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import connect.DbManagement;
import connect.EmailService;
import connect.FileSFTP;
import gen.ClearTempFile;
import gen.CompareFiles;
import gen.Zipfile;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import obj.DashbDataModel;
import obj.Pofile;
import obj.Tranfile;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;
import tmb.com.config.CSVManagementFile;
import tmb.com.config.TmbUtility;
import util.Constant;

/**
 *
 * @author Administrator
 */
public class PaymentClearFile {

    private static Log logger = LogFactory.getLog(PaymentClearFile.class);

    public static String config = System.getProperty("user.dir") + "/config/config.properties";
    private static ClearTempFile clearTempFile = null;

    public static void main(String[] args) {
        //args = new String[1];
        //args[0] ="get"; 
        // args[0] = "delete";
        PropertyConfigurator.configure(System.getProperty("user.dir") + "/config/log4j.properties");
        logger = LogFactory.getLog(PaymentClearFile.class);

        if (args.length <= 0 || StringUtils.isEmpty(args[0])) {
            //usage();
            return;
        }
        logger.debug("args == " + args.length);
        int hh = 0;
        for (String ss : args) {
            logger.debug("args == " + args[hh]);
            hh += 1;
        }
        if (args[0].equalsIgnoreCase(Constant.Part.COMPARE)) {
            PropertyConfigurator.configure(System.getProperty("user.dir") + "/config/log4jCompare.properties");
            logger = LogFactory.getLog(PaymentClearFile.class);
        } else {
            PropertyConfigurator.configure(System.getProperty("user.dir") + "/config/log4j.properties");
            logger = LogFactory.getLog(PaymentClearFile.class);
        }
        Properties prop = new Properties();

        File share = null;

        try {
            if (StringUtils.isEmpty(config)) {
                config = System.getProperty("user.dir") + "/config/config.properties";
            }

            logger.debug(config);
            prop.load(new FileInputStream(config));
            //custom log file
            //  if (!StringUtils.isEmpty(prop.getProperty("log.config.file"))){
            // PropertyConfigurator.configure(prop.getProperty("log.config.file"));
            // }
            TmbUtility.checkAndCreateFolders(prop.getProperty("file.share.path.report"));
            //logger.info("Load configuration file");
            // logger.debug("from " + config);
            SimpleDateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"), Locale.UK);
            CompareFiles compare = new CompareFiles(prop, dateFormat);

            // Get file backup node CPPP 2 
            if (args[0].equalsIgnoreCase(Constant.Part.GET)) {
                logger.info(" ########### copy data from filebackup ################ ");

                File file = new File(prop.getProperty("file.backup.path"));
                if (file.list().length <= 0) {
                    throw new Exception("No file in Backup");
                } else {
                    compare.copyFileFolder(file);
                }

            } else if (args[0].equalsIgnoreCase(Constant.Part.COMPARE)) {
                // Get file backup node CPPP 1 for  compare 

                Connection conn = null;
                clearTempFile = new ClearTempFile(prop);
                try {

                    //Part Get
                    File bfile = new File(prop.getProperty("file.backup.path"));
                    //File bfile = new File(prop.getProperty("file.backup2.path"));
                    if (bfile.list().length <= 0) {
                        throw new Exception("No file in Backup");
                    } else {
                        compare.copyFileFolder(bfile);
                    }

                    //Part Compare
                    share = new File(prop.getProperty("file.share.path"));
                    if (!share.exists()) {
                        share.mkdirs();
                    }

                    if (share.list().length <= 0) {
                        logger.info("No files in logs");
                    }

                    conn = new DbManagement(prop).connection();

                    List<Tranfile> tranfiles = compare.comparePartialCratePO(conn);
                    if (tranfiles != null) {
                        logger.info(" Partial Crate PO = " + tranfiles.size());
                    }
                    tranfiles = compare.checkFileStuckDASHF(tranfiles);
                    if (tranfiles != null) {
                        logger.info(" File Stuck DASHF = " + tranfiles.size());
                    }
                    List<Pofile> fileList = compare.compareLogsWithDb(share, conn, tranfiles);

                    if (tranfiles != null) {
                        logger.info(" Missing and  rejected of file  = " + tranfiles.size());
                    }

                    if (fileList != null && fileList.size() > 0) {
                        if (tranfiles == null) {
                            tranfiles = new ArrayList<>();
                        }
                        for (Pofile tf : fileList) {
                            if (TmbUtility.containFileName(tranfiles, tf.getFileName()) == false) {
                                Tranfile trf = new Tranfile();
                                trf.setBatStatus(tf.getSanityStatus());
                                if (!TmbUtility.isNull(tf.getErrDesc())) {
                                    trf.setBatStatus(tf.getSanityStatus() + " : " + TmbUtility.getEmptyString(tf.getErrDesc()));
                                }

                                trf.setInOutFileName(tf.getFileName());
                                //logger.debug(" rejected == " + tf.getFileName());
                                if (tf.getUploadDate() != null) {
                                    trf.setTrandate(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.US).format(tf.getUploadDate()));
                                    trf.setDifferenceInMinutes("" + TmbUtility.diffTime(tf.getUploadDate(), new Date()));
                                }
                                trf.setCurdate(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.US).format(new Date()));
                                if (trf.getCountMsd() == 0) {
                                    int cMsd = compare.countCon(conn, prop.getProperty("db.count.msd"), trf);
                                    if (cMsd == 0) {
                                        //logger.debug(" trf === " + (share.getAbsolutePath() + "/" + trf.getInOutFileName() + tf.getRemark()));
                                        cMsd = CSVManagementFile.readCountTextFile("TXN", share.getAbsolutePath() + "/" + trf.getInOutFileName() + tf.getRemark());
                                    }
                                    trf.setCountMsd(cMsd);
                                }
                                tranfiles.add(trf);
                            }

                        }

                        for (int i = 0; i < tranfiles.size(); i++) {
                            if (tranfiles.get(i).getTrandate() == null) {
                                Pofile p = compare.getDataShown(conn, tranfiles.get(i).getInOutFileName());
                                Tranfile tranfileTemp = tranfiles.get(i);
                                if (p != null && p.getUploadDate() != null) {

                                    tranfileTemp.setTrandate(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.US).format(p.getUploadDate()));

                                    tranfileTemp.setCurdate(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.US).format(new Date()));
                                    //tranfiles.set(i, tranfileTemp);
                                } else {
                                    tranfileTemp.setTrandate(TmbUtility.getDateTimeOfFile(tranfileTemp.getInOutFileName().trim()));
                                }
                                //logger.info(" share  path =" + share.getParent() + "/" + tranfileTemp.getInOutFileName());
                                //  if (tranfileTemp.getCountMsd() == 0) {
                                //    tranfileTemp.setCountMsd(CSVManagementFile.readCountTextFile("TXN", share.getParent() + "/" + tranfileTemp.getInOutFileName()));

                                //}
                                tranfiles.set(i, tranfileTemp);
                            }
                            //if (tranfiles.get(i).getCountMsd() == 0) {
                            //  tranfiles.get(i).setCountMsd(CSVManagementFile.readCountTextFile("TXN", share.getParent() + "/" + tranfiles.get(i).getInOutFileName()));

                            //}
                            if (prop != null
                                    && !TmbUtility.isNull(prop.getProperty("auto.delete.file"))
                                    && prop.getProperty("auto.delete.file").equalsIgnoreCase(Constant.ParamerConfig.AUTO_DELETE)
                                    && tranfiles.get(i).getBatStatus().indexOf("MIS") <= 0) {
                                logger.debug("#### Open mode auto delete file : " + prop.getProperty("auto.delete.file"));
                                boolean deleteCompleted = clearTempFile.automateClearFile(tranfiles.get(i).getInOutFileName());
                                //String  
                            }

                        }
                    }

                    if (!fileList.isEmpty()) {
                        new Zipfile(fileList, prop);

                        try {
                            FileSFTP sftp = new FileSFTP(prop);
                            sftp.putFileToSftp();
                        } catch (Exception e) {
                            logger.error(e);
                        }
                    }
                    List<DashbDataModel> dashbList = clearTempFile.getDataDASHB();
                    
                    if (!fileList.isEmpty() || !tranfiles.isEmpty() || !dashbList.isEmpty()) {
                        new EmailService(prop).sendEmail(tranfiles,dashbList);
                    } else {
                        logger.info("No data to send email");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error(e);
                } finally {
                    String fileName = prop.getProperty("file.name.prefix")
                            + dateFormat.format(new Date()) + "." + Constant.TypeFile.ZIP;
                    new File(fileName).delete();
                    logger.debug("Remove local file");
                    FileUtils.cleanDirectory(share);
                    logger.debug("Clean Directory " + share.getAbsolutePath());
                    if (conn != null) {
                        conn.close();
                    }
                    //logger.info("Database Connection close");
                }
            } else if (args[0].equalsIgnoreCase(Constant.Part.DELETE)) {
                ClearTempFile.clearFileFolder(TmbUtility.getTempPoPath());

                FileSFTP fileSFTP = new FileSFTP(prop);

                logger.info("############# START PICKUP FILE FROM SFTP FOR DELETE FILE ###################");
                //if (TmbUtility.isWindows()) {
                //  fileSFTP.readFileForClearPO();
                //} else {
                fileSFTP.getFileFromSftp(); //PROD ,UAT
                //}
                clearTempFile = new ClearTempFile(prop);

                clearTempFile.checkFileForClear();
                // File fLogs = new File(System.getProperty("user.dir") + "/LOG/logs.log");
                //if (fLogs.exists()) {
                //	Zipfile.ZipfileLogs(fLogs, prop);

                try {
                    //FileSFTP sftp = new FileSFTP(prop);
                    fileSFTP.putFileToSftpLogs();
                } catch (Exception e) {
                    logger.error(e);
                }
                //}
                // new EmailService(prop).sendEmailLogs(fLogs);

            } else if (args[0].equalsIgnoreCase(Constant.Part.TRANTRACKING_REPORT)) {

                FileUtils.cleanDirectory(new File(prop.getProperty("file.share.path.report")));

                DbManagement db = new DbManagement(prop);

                Connection conn = db.connection();

                StringBuilder sqlScripts = CSVManagementFile.readTextFileAppend(System.getProperty("user.dir") + "/config/scripts_trantracking.txt");

                List<String> dataList = db.inquiryTrantrackingReportDataStr(conn, sqlScripts.toString(), args);

                if (dataList != null && dataList.size() > 0) {
                    Date reportDate = new Date();
                    // logger.debug(" data size = " + dataList.size());
                    String sharePath = prop.getProperty("file.share.path.report") + "trantrackingReport_" + TmbUtility.formateDateYYYYMMDD(new Date()) + ".csv";
                    if (args != null && args.length >= 2 && args[1] != null) {
                        reportDate = TmbUtility.sdfYYYYMMDD.parse(args[1]);
                        sharePath = prop.getProperty("file.share.path.report") + "trantrackingReport_" + args[1] + ".csv";
                    } else {
                        sharePath = prop.getProperty("file.share.path.report") + "trantrackingReport_" + TmbUtility.formateDateYYYYMMDD(new Date()) + ".csv";
                    }
                    CSVManagementFile.fileWriter(null, null, dataList, sharePath);
                    //File file = new File("Trantracking_" + dateFormat.format(dateReport) + "." + Constant.TypeFile.ZIP);

                    File fileReport = new File(sharePath);
                    try {
                        if (fileReport.exists()) {

                            //Zipfile.ZipfileLogs(fileReport, "Trantracking_", prop, reportDate);
                            FileSFTP fileSFTP = new FileSFTP(prop);
                             fileSFTP.putFileToSftpLogs(sharePath);
                            //new EmailService(prop).sendEmailToUser(fileReport, reportDate);

                        }

                    } catch (Exception e) {
                        logger.error(e.getLocalizedMessage());
                        e.printStackTrace();
                    }

                }

            }

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
        }

    }

    /*
    private static void usage() {
        System.out.println("Usage command");
        System.out.println("\tjava -Dconfig.file=${config.properties} -jar ${JobRec.jar} ${part}");
        System.out.println("\tUse -Dconfig.file=${config.properties} to get your config");
        System.out.println("\tUse -jar ${JobRec.jar} to get your jarfile to run");
        System.out.println("\tUse ${part} to get part of program (get|compare)");
    }*/
}
