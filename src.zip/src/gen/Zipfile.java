package gen;

import obj.Pofile;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import util.Constant;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Zipfile {

    final static Logger logger = Logger.getLogger(Zipfile.class);

    public Zipfile(List<Pofile> list, Properties prop) {

//        byte[] buffer = new byte[1024];
        DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
        String dateStr = dateFormat.format(new Date());

        try {

            String out = prop.getProperty("file.name.prefix") + dateStr + "." + Constant.TypeFile.ZIP;
            FileOutputStream fos = new FileOutputStream(out);
            ZipOutputStream zos = new ZipOutputStream(fos);

            logger.info("Get Zip file");
            logger.debug("From Path " + list.get(0).getPofile().getParent());

            for (Pofile po : list) {

                File f = po.getPofile();

                String fileDate = dateFormat.format(f.lastModified());
                if (fileDate.equalsIgnoreCase(dateStr)) {

                    ZipEntry ze = new ZipEntry(f.getName());
                    logger.debug("Add ZipEntry : " + ze.getName());
                    zos.putNextEntry(ze);
                    //logger.debug("Add ZipEntry : " + ze.getName());
                    FileInputStream in = new FileInputStream(f.getAbsoluteFile());

                    IOUtils.write(IOUtils.toByteArray(in), zos);
                    in.close();
                }

            }

            zos.closeEntry();
            //remember close it
            zos.close();

            logger.info("Zip File Complete!!");
            logger.debug("Output to Zip : " + out + " Complete!!");

        } catch (IOException e) {
            logger.error(e);
            e.printStackTrace();
        }
    }

    public static void ZipfileLogs(File logs, Properties prop) {

//      byte[] buffer = new byte[1024];
        DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
        String dateStr = dateFormat.format(new Date());

        try {

            String out = prop.getProperty("file.name.prefix_logs") + dateStr + "." + Constant.TypeFile.ZIP;
            FileOutputStream fos = new FileOutputStream(out);
            ZipOutputStream zos = new ZipOutputStream(fos);

            logger.info("Get Zip file");
            logger.debug("From Path " + logs.getParent());

            //for (Pofile po : list) {
            //  File f = po.getPofile();
            //String fileDate = dateFormat.format(f.lastModified());
            //if (fileDate.equalsIgnoreCase(dateStr)) {
            ZipEntry ze = new ZipEntry(logs.getName());
            logger.debug("Add ZipEntry : " + ze.getName());
            zos.putNextEntry(ze);
            FileInputStream in = new FileInputStream(logs.getAbsoluteFile());

            IOUtils.write(IOUtils.toByteArray(in), zos);
            in.close();
            //}

            //  }
            zos.closeEntry();
            //remember close it
            zos.close();

            logger.info("Zip File Complete!!");
            logger.debug("Output to Zip : " + out + " Complete!!");

        } catch (IOException e) {
            logger.error(e);
            e.printStackTrace();
        }
    }

    public static void ZipfileLogs(File logs, String prefixFolder, Properties prop, Date dateReport) {

//      byte[] buffer = new byte[1024];
        DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
        String dateStr = dateReport == null ? dateFormat.format(new Date()) : dateFormat.format(dateReport);

        try {

            String out = prefixFolder + dateStr + "." + Constant.TypeFile.ZIP;
            FileOutputStream fos = new FileOutputStream(out);
            ZipOutputStream zos = new ZipOutputStream(fos);

            logger.info("Get Zip file");
            logger.debug("From Path " + logs.getParent());

            //for (Pofile po : list) {
            //  File f = po.getPofile();
            //String fileDate = dateFormat.format(f.lastModified());
            //if (fileDate.equalsIgnoreCase(dateStr)) {
            ZipEntry ze = new ZipEntry(logs.getName());
            logger.debug("Add ZipEntry : " + ze.getName());
            zos.putNextEntry(ze);
            FileInputStream in = new FileInputStream(logs.getAbsoluteFile());

            IOUtils.write(IOUtils.toByteArray(in), zos);
            in.close();
            //}

            //  }
            zos.closeEntry();
            //remember close it
            zos.close();

            logger.info("Zip File Complete!!");
            logger.debug("Output to Zip : " + out + " Complete!!");

        } catch (IOException e) {
            logger.error(e);
            e.printStackTrace();
        }
    }

}
