package com.tmb.business;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.util.List;
import java.util.Properties;

import obj.CheuqeMainDataModel;

import org.apache.log4j.Logger;

import tmb.com.config.CSVManagementFile;
import connect.DbManagement;
import connect.FileSFTP;

public class MonitorCheuqeUpdatedaily {
	final static Logger logger = Logger.getLogger(PutFileSFTP.class);
	private Properties prop;
	private FileSFTP fileSFTP = null;
	public   String config = System.getProperty("user.dir") + "/config/config.properties";
	private   CheuqeMainDataModel cheuqeUpdatePaid =null ; //RPMDYYMMDD.R01   
	private   CheuqeMainDataModel customExpiredNonCheque =null ; //RXMDyymmdd.R01
	private   CheuqeMainDataModel issuanceStatusUpdateCorpCheque =null ; //RXCQyymmdd.R01
	private   CheuqeMainDataModel cheuqeIssuanceStatusUpdateNonCorp =null ; //RSMDyymmdd.R01
	private   CheuqeMainDataModel corpChequeStatusPaidCbs  =null ;  //RSCQyymmdd.R01
	private   CheuqeMainDataModel resultIssuanceCorpChqBatch =null ; //RVCQyymmdd.R01

	private   int countChqPaid = 0;
	private   int countChqPaidDB = 0;
	private   int countChqPaidOther = 0;

	private final String STATUS_CODE_CRP_PAID = "PA";
	private final String STATUS_CODE_CRP_EXPIRED = "EX";
	private final String STATUS_CODE_CRP_SUCCESS = "S";
	private final String STATUS_CODE_CRP_CENCELED = "CA";
	private final String STATUS_CODE_CRP_ISSUED = "IS";
	private final String STATUS_CODE_CRP_RELEASESD = "RL";

	private final String STATUS_CODE_PAID = "P";
	private final String STATUS_CODE_EXPIRED = "EX";
	private final String STATUS_CODE_SUCCESS = "S";
	private final String STATUS_CODE_CENCELED = "C";
	private final String STATUS_CODE_XX = "P";

	private final String DATA_LINE_DETAIL = "D";

	public MonitorCheuqeUpdatedaily(Properties prop) {
		
		this.prop = prop; 
	}
	public void process(){
		prop = new Properties(); 
		fileSFTP = new FileSFTP(prop); 
		
		try {

			logger.debug(config);
			prop.load(new FileInputStream(config));
		}catch(Exception e){

		}
		String fileName = "D:/app/CHQ/CHQ/RPMD190927.R01";
		cheuqeUpdatePaid = new CheuqeMainDataModel();
		List<String> dataList = CSVManagementFile.readTextFile(fileName);

		Connection conn  = new DbManagement(prop).connection();

		if(!dataList.isEmpty() && dataList.size()>.0){
			//cheuqeUpdatePaid
		}

		dataList.stream().filter(ftl -> !ftl.isEmpty() && ftl.startsWith(DATA_LINE_DETAIL)  )
		.forEach(df -> {
			//System.out.println(""+df);
			System.out.println(" cheuqe no.=|"+df.substring(8, 17).trim()+"| status =|"+df.substring(175, 176).trim()+"| paid date =|"+df.substring(38, 44).trim()+"|");
			if(df.substring(175, 176).trim().equalsIgnoreCase(STATUS_CODE_PAID)){
				countChqPaid++; 

			}else{
				countChqPaidOther++;
			}
		});

		cheuqeUpdatePaid.setTotalFile(countChqPaid);
		cheuqeUpdatePaid.setStatusOth(countChqPaidOther);
		cheuqeUpdatePaid.setCheuqeType(fileName);

		System.out.println("countChqPaid= "+countChqPaid+" , countChqOther= "+countChqPaidOther);

	}
}
