package com.tmb.business;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;







import obj.Tranfile;

import org.apache.log4j.Logger;






import tmb.com.config.ConnectDB;
import connect.DbManagement; 

public class CLearTempDataNoti {
	final static Logger logger = Logger.getLogger(CLearTempDataNoti.class);
	private Properties prop;  

	public CLearTempDataNoti(Properties prop) {

		this.prop = prop; 
	}
	public void process(){
		//prop = new Properties();  
		Connection conn = new DbManagement(prop).connectionAlert();
		try {

			clearDataTemp(conn);
		}catch(Exception e){

		}


	}
	public int clearDataTemp(Connection conn) throws SQLException {

		logger.info("Clear Data Temp Starting..");

		int  rows = 0;

		PreparedStatement preStmt = null;
		List<String> tableList = new ArrayList<String>();
		tableList.add(" delete from alertuser.Pudt_s ");
		tableList.add(" delete from alertuser.s_ahst ");
		tableList.add(" delete from alertuser.Pitbl ");
		tableList.add(" delete from alertuser.jstbl ");

		try {
			for(String script : tableList){
				logger.info("script = "+script);
				preStmt = conn.prepareStatement(script);
				rows += preStmt.executeUpdate();
			} 
			conn.commit();
			logger.info("Updated Total of rows : "+rows);
			logger.info("Clear Data Temp End ..");
		}catch(Exception ex){
			conn.rollback();
			logger.error("error : "+ex.getLocalizedMessage());
			logger.error("Clear Data Temp Error ..");
		}finally{
			if(preStmt !=null){
				try {
					ConnectDB.closePreparedStatement(preStmt);
				} catch (Exception e) {
					logger.error("error PreparedStatement : "+e.getLocalizedMessage());
				}
			}if(conn !=null){
				try {
					ConnectDB.closeConnection(conn);
				} catch (Exception e) {
					logger.error("error Connection : "+e.getLocalizedMessage());
				}
			}

		}
		return rows;
	}

}
