package com.tmb.business;

import java.text.SimpleDateFormat;
import java.util.Properties;

import org.apache.log4j.Logger;

public class CheckTransactionResponse {
	final static Logger logger = Logger.getLogger(CheckTransactionResponse.class);
	private Properties prop;
	private SimpleDateFormat dateFormat;
	
	public CheckTransactionResponse(Properties prop, SimpleDateFormat dateFormat) {
		this.prop = prop;
		this.dateFormat = dateFormat;
	}

	
	
}
