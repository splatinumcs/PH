package connect;

import obj.Tranfile;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import util.Constant;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.DataSource;

import java.io.*;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import obj.DashbDataModel;
import tmb.com.config.TmbUtility;

public class EmailService {

    final static org.apache.log4j.Logger logger = Logger.getLogger(EmailService.class);

    private Properties prop;

    public EmailService(Properties prop) {

        this.prop = prop;

    }

    public void sendEmailToUser(File pathFile, Date dateReport) {

        logger.info("Connecting to smtp sever");
        Session session = Session.getDefaultInstance(prop,
                new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(prop.getProperty("mail.user"),
                        prop.getProperty("mail.pass"));
            }
        });
        logger.debug("host : " + prop.getProperty("mail.smtp.host"));
        logger.debug("port : " + prop.getProperty("mail.smtp.port"));

        session.setDebug(Boolean.parseBoolean(prop.getProperty("mail.debug")));
        dateReport = dateReport == null ? new Date() : dateReport;
        // Part two is attachment
        DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
        File file = new File("Trantracking_" + dateFormat.format(dateReport) + "." + Constant.TypeFile.ZIP);
        logger.debug(file.getAbsoluteFile());
        logger.debug(file.getName());

        try {
            logger.info("Connection complete !!");

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(prop.getProperty("mail.sender")));
            if (!StringUtils.isEmpty(prop.getProperty("mailUser.to"))) {
                message.addRecipients(MimeMessage.RecipientType.TO,
                        splitEmailList(prop.getProperty("mailUser.to")));
            }
            if (!StringUtils.isEmpty(prop.getProperty("mailUser.cc"))) {
                message.addRecipients(MimeMessage.RecipientType.CC,
                        splitEmailList(prop.getProperty("mailUser.cc")));
            }
            if (!StringUtils.isEmpty(prop.getProperty("mailUser.bcc"))) {
                message.addRecipients(MimeMessage.RecipientType.BCC,
                        splitEmailList(prop.getProperty("mailUser.bcc")));
            }

            message.setSubject(replaceDataFormat(prop.getProperty("mail.subject.trantacking")));

            // Create the message part
            BodyPart messageBodyPart = new MimeBodyPart();
            // Now set the actual message
            //InputStream in = new FileInputStream(new File(System.getProperty("user.dir") + "/config/" + prop.getProperty("mail.message.html.file")));
            //String content = replaceDataFormat(IOUtils.toString(in, Charset.forName(Constant.CharSet.UTF)), tranfiles);
            String content = prop.getProperty("mail.message.trantacking");

            messageBodyPart.setContent(content, Constant.CharSet.UTF);

            // Create a multipar message
            Multipart multipart = new MimeMultipart();
            // Set text message part
            multipart.addBodyPart(messageBodyPart);

            if (file.exists()) {
                messageBodyPart = new MimeBodyPart();
                DataSource source = new FileDataSource(file.getAbsolutePath());
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(file.getName());
                multipart.addBodyPart(messageBodyPart);
            }

            // Send the complete message parts
            message.setContent(multipart);

            Transport.send(message);

            logger.info("Send email complete");

        } catch (MessagingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void sendEmail(List<Tranfile> tranfiles, List<DashbDataModel> dashbList) throws FileNotFoundException {

        logger.info("Connecting to smtp sever");
        Session session = Session.getDefaultInstance(prop,
                new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(prop.getProperty("mail.user"),
                        prop.getProperty("mail.pass"));
            }
        });
        logger.debug("host : " + prop.getProperty("mail.smtp.host"));
        logger.debug("port : " + prop.getProperty("mail.smtp.port"));

        session.setDebug(Boolean.parseBoolean(prop.getProperty("mail.debug")));

        try {
            logger.info("Connection complete !!");

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(prop.getProperty("mail.sender")));
            if (!StringUtils.isEmpty(prop.getProperty("mail.to"))) {
                message.addRecipients(MimeMessage.RecipientType.TO,
                        splitEmailList(prop.getProperty("mail.to")));
            }
            if (!StringUtils.isEmpty(prop.getProperty("mail.cc"))) {
                message.addRecipients(MimeMessage.RecipientType.CC,
                        splitEmailList(prop.getProperty("mail.cc")));
            }
            if (!StringUtils.isEmpty(prop.getProperty("mail.bcc"))) {
                message.addRecipients(MimeMessage.RecipientType.BCC,
                        splitEmailList(prop.getProperty("mail.bcc")));
            }

            message.setSubject(replaceDataFormat(prop.getProperty("mail.subject")));

            // Create the message part
            BodyPart messageBodyPart = new MimeBodyPart();
            // Now set the actual message
            InputStream in = new FileInputStream(new File(System.getProperty("user.dir") + "/config/" + prop.getProperty("mail.message.html.file")));
            String content = replaceDataFormat(IOUtils.toString(in, Charset.forName(Constant.CharSet.UTF)), tranfiles);
            content = replaceDataFormatDASHB(content, dashbList);
            messageBodyPart.setContent(content, Constant.CharSet.HTML_TYPE);

            // Create a multipar message
            Multipart multipart = new MimeMultipart();
            // Set text message part
            multipart.addBodyPart(messageBodyPart);

            // Part two is attachment
            DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
            File file = new File(prop.getProperty("file.name.prefix")
                    + dateFormat.format(new Date()) + "." + Constant.TypeFile.ZIP);

            if (file.exists()) {
                messageBodyPart = new MimeBodyPart();
                DataSource source = new FileDataSource(file.getAbsolutePath());
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(file.getName());
                multipart.addBodyPart(messageBodyPart);
            }

            // Send the complete message parts
            message.setContent(multipart);

            Transport.send(message);

            logger.info("Send email complete");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendEmailLogs(File fLogs, String args[]) throws FileNotFoundException {

        logger.info("Connecting to smtp sever");
        Session session = Session.getDefaultInstance(prop,
                new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(prop.getProperty("mail.user"),
                        prop.getProperty("mail.pass"));
            }
        });
        logger.debug("host : " + prop.getProperty("mail.smtp.host"));
        logger.debug("port : " + prop.getProperty("mail.smtp.port"));

        session.setDebug(Boolean.parseBoolean(prop.getProperty("mail.debug")));

        try {
            logger.info("Connection complete !!");

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(prop.getProperty("mail.sender")));
            if (!StringUtils.isEmpty(prop.getProperty("mail.to"))) {
                message.addRecipients(MimeMessage.RecipientType.TO,
                        splitEmailList(prop.getProperty("mail.to")));
            }
            if (!StringUtils.isEmpty(prop.getProperty("mail.cc"))) {
                message.addRecipients(MimeMessage.RecipientType.CC,
                        splitEmailList(prop.getProperty("mail.cc")));
            }
            if (!StringUtils.isEmpty(prop.getProperty("mail.bcc"))) {
                message.addRecipients(MimeMessage.RecipientType.BCC,
                        splitEmailList(prop.getProperty("mail.bcc")));
            }

            message.setSubject(replaceDataFormat(prop.getProperty("mail.subject.trantracking")));

            // Create the message part
            BodyPart messageBodyPart = new MimeBodyPart();
            // Now set the actual message
            // InputStream in = new FileInputStream(new File(System.getProperty("user.dir") + "/config/" + prop.getProperty("mail.message.html.file")));
            // String content = replaceDataFormat(IOUtils.toString(in, Charset.forName(Constant.CharSet.UTF)), tranfiles);
            messageBodyPart.setContent("Logs file ", Constant.CharSet.UTF);

            // Create a multipar message
            Multipart multipart = new MimeMultipart();
            // Set text message part
            multipart.addBodyPart(messageBodyPart);

            // Part two is attachment
            DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
            File file = new File(prop.getProperty("file.name.prefix_logs")
                    + dateFormat.format(new Date()) + "." + Constant.TypeFile.ZIP);

            if (file.exists()) {
                messageBodyPart = new MimeBodyPart();
                DataSource source = new FileDataSource(file.getAbsolutePath());
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(file.getName());
                multipart.addBodyPart(messageBodyPart);
            }

            // Send the complete message parts
            message.setContent(multipart);

            Transport.send(message);

            logger.info("Send email complete");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }

    private static InternetAddress[] splitEmailList(String email) {
        List<InternetAddress> emList = new ArrayList<>();
        InternetAddress cc[] = null;
        if (!StringUtils.isEmpty(email)) {
            String sp[] = email.split(",");
            if (sp != null && sp.length > 0) {
                for (String em : sp) {
                    if (!StringUtils.isEmpty((em))) {
                        try {
                            InternetAddress ipAddress = new InternetAddress(em);
                            emList.add(ipAddress);
                        } catch (AddressException ex) {
                            try {
                                throw ex;
                            } catch (AddressException e) {
                                logger.error(e);
                            }
                        }
                    }

                }

            }
            if (emList != null && emList.size() > 0) {
                cc = new InternetAddress[emList.size()];
                int idx = 0;
                for (InternetAddress em : emList) {
                    cc[idx] = em;
                    idx++;
                }
            }
        }
        return cc;
    }

    private String replaceDataFormat(String str) {

        String pattern = prop.getProperty("mail.dateformat");
        SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
        return str.replace(pattern, dateFormat.format(new Date()));
    }

    private String replaceDataFormat(String str, List<Tranfile> list) {

        String data = replaceDataFormat(str);
        String table = "";
        if (list.isEmpty()) {
            table = "<TR>"
                    + "<TD colspan=7 align=\"center\">No data found</TD>"
                    + "</TR>";
        } else {
            for (Tranfile f : list) {
                table += "<TR>"
                        + "<TD>" + f.getInOutFileName() + "</TD>"
                        + "<TD  align=\"center\">" + TmbUtility.getEmptyString(f.getTrandate()) + "</TD>"
                        + "<TD align=\"center\">" + TmbUtility.getEmptyString(f.getCurdate()) + "</TD>"
                        + "<TD align=\"center\">" + TmbUtility.getEmptyString(f.getDifferenceInMinutes()) + "</TD>"
                        + "<TD align=\"center\">" + f.getCountCtx() + "</TD>"
                        + "<TD align=\"center\">" + f.getCountMsd() + "</TD>"
                        + "<TD align=\"center\">" + TmbUtility.getEmptyString(f.getBatStatus()) + "</TD>"
                        + "</TR>";
            }
        }

        data = data.replace(":TABLE_DATA", table);
        data = data.replace(":TOTAL_DATA", list.size() + "");

        return data;
    }

    private String replaceDataFormatDASHB(String str, List<DashbDataModel> list) {

        String data = str;
        String tableDetail = "";
        String table = "";
        HashMap<String, Integer> dashbMap = new HashMap();

        int totalDetail = 0;
        if (list.isEmpty()) {
            tableDetail = "<TR>"
                    + "<TD colspan=4 align=\"center\">No data found</TD>"
                    + "</TR>";
        } else {
            for (DashbDataModel f : list) {
                tableDetail += "<TR>"
                        + "<TD align=\"center\">" + f.getProductCode() + "</TD>"
                        + "<TD align=\"center\">" + f.getTotalOfFile() + "</TD>"
                        + "<TD align=\"center\">" + TmbUtility.getEmptyString(f.getBatStatus()) + "</TD>"
                        + "<TD align=\"center\">" + TmbUtility.getEmptyString(f.getDebitDate()) + "</TD>"
                        + "</TR>";
                if (dashbMap.get(f.getProductCode()) == null) {
                    dashbMap.put(f.getProductCode(), f.getTotalOfFile());
                } else {
                    int cnt = dashbMap.get(f.getProductCode()).intValue();
                    dashbMap.put(f.getProductCode(), (f.getTotalOfFile() + cnt));
                }
                totalDetail += f.getTotalOfFile();
            }
        }

        data = data.replace(":TABLE_DATA_DASHB", tableDetail);
        data = data.replace(":TOTAL_DATA_DASHB", totalDetail + "");

        if (dashbMap.isEmpty()) {
            table = "<TR>"
                    + "<TD colspan=2 align=\"center\">No data found</TD>"
                    + "</TR>";
        } else {
            for (Map.Entry m : dashbMap.entrySet()) {
                if (m.getKey() != null) {
                    table += "<TR>"
                            + "<TD align=\"center\">" + m.getKey() + "</TD>"
                            + "<TD align=\"center\">" + m.getValue() + "</TD>"
                            + "</TR>";
                }

            }
        }
        data = data.replace(":TABLE_DATA_DASHB_DETAIL", table);
        data = data.replace(":TOTAL_DATA_DASHB_DETAIL", totalDetail + "");

        return data;
    }

}
