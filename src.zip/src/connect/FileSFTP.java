package connect;

import com.jcraft.jsch.*;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import util.Constant;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;

import main.AESCrypt;

import org.apache.commons.io.IOUtils;

import tmb.com.config.TmbUtility;

/**
 * @author javagists.com
 */
public class FileSFTP {

    final static org.apache.log4j.Logger logger = Logger.getLogger(FileSFTP.class);
    public static SimpleDateFormat sftpDf = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
    private Properties prop;

    public FileSFTP(Properties prop) {
        this.prop = prop;
    }

    public String[] getFileFromSftp() {

        DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
        String dateStr = dateFormat.format(new Date());

        Session session = null;
        try {

            session = getSession();
            ChannelSftp sftpChannel = getChanel(session);
            logger.debug("getFileFromSftp linux server Download file..");
            sftpChannel.cd(prop.getProperty("sftp.download.path").trim());
            logger.debug(sftpChannel.pwd());
            Vector<ChannelSftp.LsEntry> list = sftpChannel.ls(prop.getProperty("sftp.file_po"));
            logger.debug("Download from " + prop.getProperty("sftp.download.path"));
            logger.debug("sftp.file_po== " + prop.getProperty("sftp.file_po"));
            //logger.debug("To "+Constant.Folder.Temp+node+File.separator);

            //logger.debug("File name : " + entry.getFilename() + " date = " + date + " dateStr " + dateStr);
            logger.debug("list SFTP  : " + list.size());
            for (ChannelSftp.LsEntry entry : list) {
                try {
                    logger.debug("list getMtimeString  : " + entry.getAttrs().getMtimeString());
                    Date date = sftpDf.parse(entry.getAttrs().getMtimeString());
                    logger.debug("File name : " + entry.getFilename() + " date = " + date + " dateStr " + dateStr);
                    if (dateFormat.format(date).equals(dateStr)) {
                        sftpChannel.get(entry.getFilename(),
                                TmbUtility.getTempPoPath() + File.separator + entry.getFilename());
                        logger.debug("File name : " + entry.getFilename());
                        sftpChannel.rm(entry.getFilename());
                        logger.info("Download file complete!!");
                        break;
                    }

                } catch (ParseException e) {
                    logger.error(e);
                }
            }

            sftpChannel.exit();

        } catch (JSchException e) {
            e.printStackTrace();
            logger.error(e);
        } catch (SftpException e) {
            e.printStackTrace();
            logger.error(e);
        } finally {
            logger.info("Disconnect from SFTP");
            logger.debug(session.getHost());
            session.disconnect();
        }
        //TmbUtility.getO
        String[] files = new File(TmbUtility.getTempPoPath()).list();
        Arrays.sort(files);

        return files;
    }

    public String[] getFileFromSftpParam(String sftpDownloadPath, String localPath, String fileNameSpecific, boolean FlagDelete) {

        DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
        //Locale.ENGLISH
        SimpleDateFormat sftpDfTemp = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
        String dateStr = dateFormat.format(new Date());
        Session session = null;
        try {

            session = getSession();
            ChannelSftp sftpChannel = getChanel(session);
            sftpChannel.cd(sftpDownloadPath.trim());
            Vector<ChannelSftp.LsEntry> list = sftpChannel.ls(fileNameSpecific);
            logger.debug("list SFTP  : " + list.size());
            logger.debug("localPath  : " + localPath);
            logger.debug("  sftpDf  : " + sftpDfTemp.toPattern());

            for (ChannelSftp.LsEntry entry : list) {
                try {
                    logger.debug("list getMtimeString  : " + entry.getAttrs().getMtimeString());

                    Date date = sftpDfTemp.parse(entry.getAttrs().getMtimeString());
                    logger.debug("File name : " + entry.getFilename() + " date = " + date + " dateStr " + dateStr);
                    if (dateFormat.format(date).equals(dateStr)) {
                        sftpChannel.get(entry.getFilename(), localPath + File.separator + entry.getFilename());
                        logger.debug("File name : " + entry.getFilename());
                        if (FlagDelete) {
                            sftpChannel.rm(entry.getFilename());
                        }
                        logger.info("Download file complete!!");
                        break;
                    }

                } catch (ParseException e) {
                    logger.error(e);
                    logger.error(e.getLocalizedMessage());
                }
            }

            sftpChannel.exit();

        } catch (JSchException e) {
            e.printStackTrace();
            logger.error(e);
        } catch (SftpException e) {
            e.printStackTrace();
            logger.error(e);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
            logger.debug(e.getLocalizedMessage());
        } finally {
            logger.info("Disconnect from SFTP");
            logger.debug(session.getHost());
            session.disconnect();
        }
        //TmbUtility.getO
        String[] files = new File(localPath).list();
        Arrays.sort(files);

        return files;
    }

    public void readFileForClearPO() {

        Session session = null;
        Channel channel = null;
        ChannelSftp channelSftp = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        //SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        //SimpleDateFormat sdfFile = new SimpleDateFormat("yyyyMMdd", Locale.US);
        String SELECT_DATE = sdf.format(new Date());

        File fSrc = new File(TmbUtility.getTempPoPath());

        try {
            JSch jsch = new JSch();
            session = jsch.getSession(prop.getProperty("sftp.user"), prop.getProperty("sftp.host"), 22);
            session.setPassword(AESCrypt.decrypt((prop.getProperty("sftp.password"))));
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();
            channel = session.openChannel("sftp");
            channel.connect();
            channelSftp = (ChannelSftp) channel;
            channelSftp.cd(prop.getProperty("sftp.download.path"));
            //*.TXT >> PMH_FAH_E_20180509_001.asc
            Vector<ChannelSftp.LsEntry> list = channelSftp.ls(prop.getProperty("sftp.file_po"));

            for (ChannelSftp.LsEntry entry : list) {
                SftpATTRS attrs = entry.getAttrs();
                Date dateModify = new Date(attrs.getMTime() * 1000L);
                if (sdf.format(dateModify).equalsIgnoreCase(SELECT_DATE)) {
                    logger.debug(entry.getFilename());
                    channelSftp.get(entry.getFilename(), TmbUtility.getTempPoPath() + File.separator + entry.getFilename());
                    channelSftp.rm(entry.getFilename());
                    break;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (session != null) {
                session.disconnect();
            }
        }

        String[] files = new File(TmbUtility.getTempPoPath()).list();

        for (String ss : files) {
            logger.info(fSrc.getAbsolutePath() + File.separator + ss);
        }

    }

    private Session getSessionByPassword() throws JSchException {
        try {
            JSch jsch = new JSch();

            Session session = jsch.getSession(prop.getProperty("sftp.user"), prop.getProperty("sftp.host"), Integer.valueOf(prop.getProperty("sftp.port")));

            session.setPassword(AESCrypt.decrypt((prop.getProperty("sftp.password"))));

            Properties config = new java.util.Properties();

            //config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            //session.setPassword(prop.getProperty("sftp.password"));

            session.connect();

            //logger.info("Connection to SFTP host");
            //logger.debug("host : " + session.getHost());
            return session;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    private Session getSession() throws JSchException {

        if (TmbUtility.isWindows()) {
            return getSessionByPassword();
        } else {
            JSch jsch = new JSch();

            jsch.addIdentity(prop.getProperty("sftp.ssh.keyfile"),
                    prop.getProperty("sftp.ssh.passphrase"));

            Session session = jsch.getSession(prop.getProperty("sftp.user"),
                    prop.getProperty("sftp.host"), Integer.valueOf(prop.getProperty("sftp.port")));
            Properties config = new java.util.Properties();

            config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);

            session.connect();
            return session;
        }

    }

    private ChannelSftp getChanel(Session session) throws JSchException {

        //logger.debug("Session openChannel " + Constant.Session.OPEN_CHANNEL);
        Channel channel = session.openChannel(Constant.Session.OPEN_CHANNEL);
        channel.connect();
        ChannelSftp sftpChannel = (ChannelSftp) channel;
        //logger.debug("OpenChannel complete!!");
        return sftpChannel;
    }

    public void putFileToSftp() {

        DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
        String fileName = prop.getProperty("file.name.prefix")
                + dateFormat.format(new Date()) + "." + Constant.TypeFile.ZIP;

        Session session = null;
        try {

            session = getSession();
            ChannelSftp sftpChannel = getChanel(session);
            //logger.info("Upload file..");
            sftpChannel.put(fileName, prop.getProperty("sftp.upload.path") + fileName);
            //logger.debug("Upload To " + prop.getProperty("sftp.upload.path") + fileName);
            //logger.info("Upload file complete!!");
            sftpChannel.exit();

        } catch (JSchException e) {
            e.printStackTrace();
            logger.error(e);
        } catch (SftpException e) {
            e.printStackTrace();
            logger.error(e);
        } finally {
            //logger.info("Disconnect from SFTP");
            logger.debug(session.getHost());
            session.disconnect();
        }

    }

    public void putFileToSftpLogs() throws IOException {

        DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
        //  String fileName = prop.getProperty("file.name.prefix_logs")
        //        + dateFormat.format(new Date()) + "." + Constant.TypeFile.ZIP;
        File fLogs = new File(System.getProperty("user.dir") + "/LOG/logs.log");
        String fileNameLogs = prop.getProperty("file.name.prefix_logs") + dateFormat.format(new Date()) + "_" + new Date().getTime();
        Session session = null;
        try {

            session = getSession();
            ChannelSftp sftpChannel = getChanel(session);
            logger.info("Upload logs file. to SFTP ");
            FileInputStream in;
            try {
                in = new FileInputStream(fLogs.getAbsoluteFile());
                sftpChannel.put(in, prop.getProperty("sftp.download.path") + fLogs.getName());
                in.close();
            } catch (FileNotFoundException ex) {
                java.util.logging.Logger.getLogger(FileSFTP.class.getName()).log(Level.SEVERE, null, ex);
            }

            logger.debug("Upload To " + prop.getProperty("sftp.download.path") + fLogs.getName());
            logger.info("Upload file complete!!");
            sftpChannel.exit();

        } catch (JSchException e) {
            e.printStackTrace();
            logger.error(e);
        } catch (SftpException e) {
            e.printStackTrace();
            logger.error(e);
        } finally {
            //logger.info("Disconnect from SFTP");
            //logger.debug(session.getHost());
            session.disconnect();
        }

    }

    public void putFileToSftpLogs(String pathFile) throws IOException {

        DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
        //  String fileName = prop.getProperty("file.name.prefix_logs")
        //        + dateFormat.format(new Date()) + "." + Constant.TypeFile.ZIP;
        File fLogs = new File(pathFile);
        //String fileNameLogs =  pathFile+dateFormat.format(new Date())+"_"+new Date().getTime();
        Session session = null;
        try {

            session = getSession();
            ChannelSftp sftpChannel = getChanel(session);
            logger.info("Upload logs file. to SFTP ");
            FileInputStream in;
            try {
                in = new FileInputStream(fLogs.getAbsoluteFile());
                sftpChannel.put(in, prop.getProperty("sftp.upload.path") + fLogs.getName());
                in.close();
            } catch (FileNotFoundException ex) {
                java.util.logging.Logger.getLogger(FileSFTP.class.getName()).log(Level.SEVERE, null, ex);
            }

            logger.debug("Upload To " + prop.getProperty("sftp.upload.path") + fLogs.getName());
            logger.info("Upload file complete!!");
            sftpChannel.exit();

        } catch (JSchException e) {
            e.printStackTrace();
            logger.error(e);
        } catch (SftpException e) {
            e.printStackTrace();
            logger.error(e);
        } finally {
            //logger.info("Disconnect from SFTP");
            //logger.debug(session.getHost());
            session.disconnect();
        }

    }

    public String[] getFileFromSftpCIBRecon() {

        DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
        String dateStr = dateFormat.format(new Date());

        Session session = null;
        try {

            session = getSession();
            ChannelSftp sftpChannel = getChanel(session);

            sftpChannel.cd(prop.getProperty("sftp.dowload.path.reconcile.cib"));

            logger.debug("Dowload.path : " + prop.getProperty("sftp.dowload.path.reconcile.cib"));

            Vector<ChannelSftp.LsEntry> list = sftpChannel.ls(prop.getProperty("sftp.file.reconcile.cib"));

            logger.debug("Type of File  : " + prop.getProperty("sftp.file.reconcile.cib"));

            SimpleDateFormat sftpDf = new SimpleDateFormat("yyyyMMdd", Locale.UK);

            TmbUtility.checkAndCreateFolders(prop.getProperty("server.path.reconcile"));

            logger.debug("sftp.file.reconcile.cib : " + prop.getProperty("sftp.file.reconcile.cib"));

            if (list != null) {
                for (ChannelSftp.LsEntry entry : list) {
                    try {

                        Date dateModify = new Date(entry.getAttrs().getMTime() * 1000L);
                        String dateMTime = sftpDf.format(dateModify);

                        logger.debug(dateStr + " <> dateMTime " + dateMTime);

                        if (dateStr.equals(dateMTime)) {
                            sftpChannel.get(entry.getFilename(), prop.getProperty("server.path.reconcile") + entry.getFilename());
                            logger.debug("File name : " + entry.getFilename());
                            //sftpChannel.rm(entry.getFilename());
                            //logger.info("Download file complete!!");
                            // break;
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error(e);
                    }
                }
            }

            sftpChannel.exit();

        } catch (JSchException e) {
            e.printStackTrace();
            logger.error(e);
        } catch (SftpException e) {
            e.printStackTrace();
            logger.error(e);
        } finally {
            logger.info("Disconnect from SFTP");
            logger.debug(session.getHost());
            session.disconnect();
        }
        //TmbUtility.getO
        String[] files = new File(prop.getProperty("server.path.reconcile")).list();
        if (files != null) {
            Arrays.sort(files);
        }

        return files;
    }

    public boolean putResponseFileToSftp(String srcFile, String sftpUploadPath) throws IOException {

        File srcResFile = new File(srcFile);
        Session session = null;
        boolean statusUpload = false;
        try {

            session = getSession();
            ChannelSftp sftpChannel = getChanel(session);
            logger.debug("Upload response file. to SFTP ");
            FileInputStream in;
            try {
                if (srcResFile.exists()) {
                    logger.debug("srcResFile.getAbsoluteFile()= " + srcResFile.getAbsoluteFile());
                    in = new FileInputStream(srcResFile.getAbsoluteFile());
                    //sftpChannel.cd(sftpUploadPath);
                    sftpChannel.put(in, sftpUploadPath + "/" + srcResFile.getName());
                    logger.debug("srcResFile.getAbsoluteFilename= " + sftpUploadPath + "/" + srcResFile.getName());
                    in.close();
                    statusUpload = true;
                    logger.debug("Upload To " + sftpUploadPath + "/" + srcResFile.getName());
                    logger.debug("Upload file complete!!");

                } else {
                    statusUpload = false;
                     logger.debug("Upload file failed file not found!!");
                }

            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
                logger.error(ex.getLocalizedMessage());
                 logger.debug("Upload file failed file not found!!");
            }
            sftpChannel.exit();
            //statusUpload = true;
        } catch (JSchException e) {
            e.printStackTrace();
            logger.error(e.getLocalizedMessage());
            statusUpload = false;
        } catch (SftpException e) {
            e.printStackTrace();
            logger.error(e.getLocalizedMessage());
            statusUpload = false;
             logger.debug("Upload file failed Sftp Exception!!");
        } finally {
            //logger.info("Disconnect from SFTP");
            //logger.debug(session.getHost());
            session.disconnect();
        }
        logger.debug("Upload file status Upload= "+statusUpload);
        return statusUpload;

    }

}
