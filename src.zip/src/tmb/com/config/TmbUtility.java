/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tmb.com.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import obj.Pofile;
import obj.Tranfile;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import util.Constant;

/**
 *
 * @author N186
 */
public class TmbUtility {

    private static Log logger = LogFactory.getLog(TmbUtility.class);

    public static SimpleDateFormat DD_MM_YYYY = new SimpleDateFormat("dd-MM-yyyy", Locale.UK);

    public static SimpleDateFormat sdfYYYYMMDD = new SimpleDateFormat("yyyyMMdd", Locale.US);
    public static SimpleDateFormat sdfDDMMYYYY = new SimpleDateFormat("ddMMyyyy", Locale.US);
    public static SimpleDateFormat sdfYYYYMMDDHHmmss = new SimpleDateFormat("yyyyMMdd HHmmss", Locale.US);
    public static SimpleDateFormat sdfDDMMYYYYHHmmss = new SimpleDateFormat("ddMMyyyy HHmmss", Locale.US);

    private static String OS = System.getProperty("os.name").toLowerCase();

    public static boolean isWindows() {

        return (OS.indexOf("win") >= 0);

    }

    public static String getDecimalDouble(double amt, DecimalFormat df) {
        if (df == null) {
            df = new DecimalFormat("0.00");
        }

        return df.format(amt);

    }

    public static String getTempPoPath() {

        return isWindows() ? Constant.Folder.TempFilePO : Constant.Folder.LINUX_TempFilePO;

    }

    public static String getTempPoBKPath() {

        return isWindows() ? Constant.Folder.TempFilePOBK : Constant.Folder.LINUX_TempFilePOBK;

    }

    public static String addAfterString(String src, String add, int size) {
        // String vv = "";
        StringBuilder stringBuilder = new StringBuilder(src);
        if (isNull(src)) {
            stringBuilder = new StringBuilder("");
            int srcSize = isNull(src) ? 0 : src.length();
            //System.out.print(src + " isNull =" + isNull(src));
            size = (size - srcSize);
            // System.out.print(src + " size =" + size + " ,src =" + src.length());
            if (size > 0) {
                for (int row = 0; row < size; row++) {
                    //System.out.print("##");
                    stringBuilder.append(add);
                }
            }
        } else {
            int srcSize = isNull(src) ? 0 : src.length();
            //System.out.print(src + " isNull =" + isNull(src));
            size = (size - srcSize);
            //System.out.print(src + " size =" + size + " ,src =" + src.length());
            if (size > 0) {
                for (int row = 0; row < size; row++) {
                    // System.out.print("##");
                    stringBuilder.append(add);
                }
            }
        }

        // System.out.print(" after =" + stringBuilder.toString().length());
        return stringBuilder.toString();
    }

    public static String getEmptyString(String src) {
        String vv = "";
        if (!isNull(src) && !src.equals("null")) {
            vv = src;
        } else {
            vv = "";
        }
        return vv;
    }

    public static String addString(String add, int size) {
        return addString("", add, size);
    }

    public static String addString(String src, String add, int size) {
        // String vv = "";
        int srcSize = isNull(src) ? 0 : size(src);
        StringBuilder stringBuilder = new StringBuilder(src);
        size = (size - srcSize);
        for (int row = 0; row < size; row++) {
            stringBuilder.append(add);
        }
        return stringBuilder.toString();
    }

    public static String addBeforeString(String src, String add, int size) {
        // String vv = "";
        int srcSize = isNull(src) ? 0 : size(src);
        StringBuilder stringBuilder = new StringBuilder();
        size = (size - srcSize);
        for (int row = 0; row < size; row++) {
            stringBuilder.append(add);
        }
        stringBuilder.append(src);
        return stringBuilder.toString();
    }

    public static boolean isNull(Object object) {
        boolean check = false;
        if (object == null) {
            return true;
        } else {
            if (object instanceof String) {
                String str = String.valueOf(object);
                if (str == null || str.isEmpty()) {
                    return true;
                } else if (str.trim().equals("")) {
                    return true;
                }
            } else if (object instanceof Date) {
                if (object == null) {
                    return true;
                }
            } else if (object instanceof Collection) {
                if (object == null) {
                    return true;
                } else if (((Collection) object).isEmpty()) {
                    return true;
                } else if (((Collection) object).size() <= 0) {
                    return true;
                }
            } else if (object instanceof HashMap) {
                if (object == null) {
                    return true;
                } else if (((HashMap) object).isEmpty()) {
                    return true;
                } else if (((HashMap) object).size() <= 0) {
                    return true;
                }
            }
        }
        return check;
    }

    public static int size(Object object) {
        int size = 0;
        if (!isNull(object)) {
            if (object instanceof String) {
                return String.valueOf(object).length();
            } else if (object instanceof Collection) {
                if (object == null) {
                    return 0;
                } else if (!((Collection) object).isEmpty()) {
                    return ((Collection) object).size();
                }
            } else if (object instanceof HashMap) {
                if (object == null) {
                    return 0;
                } else if (!((HashMap) object).isEmpty()) {
                    return ((HashMap) object).size();
                }
            }
        } else {
            return size;
        }
        return size;
    }

    public static String decimalFormateNumber(long src, DecimalFormat decimalFormat) {
        String strValue = decimalFormat.format(src);
        return strValue;

    }

    public static String formateDateYYYYMMDD(Date valueDate) {
        String strValue = "";
        if (!isNull(valueDate)) {
            strValue = sdfYYYYMMDD.format(valueDate);
        }
        return strValue;
    }

    public static String formateDateDDMMYYYY(Date valueDate) {
        String strValue = "";
        if (!isNull(valueDate)) {
            strValue = sdfDDMMYYYY.format(valueDate);
        }
        return strValue;
    }

    public static String formateDateDDMMYYYYhhmmss(Date valueDate) {
        String strValue = "";
        if (!isNull(valueDate)) {
            strValue = sdfDDMMYYYYHHmmss.format(valueDate);
        }
        return strValue;
    }

    public static String formateDateYYYYMMDDhhmmss(Date valueDate) {
        String strValue = "";
        if (!isNull(valueDate)) {
            strValue = sdfYYYYMMDDHHmmss.format(valueDate);
        }
        return strValue;
    }

    public static String getCurrentDateSimpleDateFormat(SimpleDateFormat sdf) {
        String strValue = "";
        strValue = sdf.format(new Date());
        return strValue;
    }

    public static String formateDateBySimpleDateFormat(Date valueDate, SimpleDateFormat sdf) {
        String strValue = "";
        if (!isNull(valueDate)) {
            strValue = sdf.format(valueDate);
        }
        return strValue;
    }

    public static Date convertStringtoDate(String strDate, SimpleDateFormat sdf) {
        Date date = null;
        if ((!isNull(strDate)) && sdf != null) {
            try {
                date = sdf.parse(strDate);
            } catch (ParseException ex) {
                Logger.getLogger(TmbUtility.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return date;
    }

    public static int convertStrToInt(String value) {
        int num = 0;
        if (!isNull(value)) {
            try {
                num = Integer.parseInt(value);
            } catch (Exception e) {
                logger.error(e.getLocalizedMessage());
            }

        }
        return num;
    }

    public static double convertStrToDouble(String value) {
        double num = 0;
        if (!isNull(value)) {
            try {
                num = Double.parseDouble(value);
            } catch (Exception e) {
                logger.error(e.getLocalizedMessage());
            }

        }
        return num;
    }

    public static String convertIntToStr(String value) {
        String num = "";
        if (!isNull(value)) {
            try {
                num = String.valueOf(num);
            } catch (Exception e) {
                logger.error(e.getLocalizedMessage());
            }

        }
        return num;
    }

    public static int diffTime(Date start, Date curDate) {

        Calendar calendar1 = Calendar.getInstance(Locale.US);
        Calendar calendar2 = Calendar.getInstance(Locale.US);
        calendar1.setTime(start);
        calendar2.setTime(curDate);
        long milliseconds1 = calendar1.getTimeInMillis();
        long milliseconds2 = calendar2.getTimeInMillis();
        long diff = milliseconds2 - milliseconds1;
        long diffSeconds = diff / 1000;
        long diffMinutes = diff / (60 * 1000);
        long diffHours = diff / (60 * 60 * 1000);
        long diffDays = diff / (24 * 60 * 60 * 1000);
        //System.out.println("\nThe Date Different Example");

        System.out.print("Time in days: " + diffDays + " days." + diffHours + " hours. " + diffMinutes + " minutes." + diffSeconds + " seconds.  " + diff + " milliseconds.");

        return (int) diffMinutes;
    }

    public static String diffTimeStr(Date start, Date curDate) {
        String diffStr = "";
        Calendar calendar1 = Calendar.getInstance(Locale.US);
        Calendar calendar2 = Calendar.getInstance(Locale.US);
        calendar1.setTime(start);
        calendar2.setTime(curDate);
        long milliseconds1 = calendar1.getTimeInMillis();
        long milliseconds2 = calendar2.getTimeInMillis();
        long diff = milliseconds2 - milliseconds1;
        long diffSeconds = diff / 1000;
        long diffMinutes = diff / (60 * 1000);
        long diffHours = diff / (60 * 60 * 1000);
        long diffDays = diff / (24 * 60 * 60 * 1000);
        //System.out.println("\nThe Date Different Example");

        diffStr = "Time in days: " + diffDays + " days." + diffHours + " hours. " + diffMinutes + " minutes." + diffSeconds + " seconds.  " + diff + " millisecs.";

        return diffStr;
    }

    public static boolean containFileName(List<Tranfile> list, String filename) {
        List<Tranfile> pofile = list.stream().filter(p -> (p.getInOutFileName().equals(filename))).collect(Collectors.toList());
        return pofile.isEmpty() ? false : true;
    }

    public static String getDateTimeOfFile(String fileName) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss", Locale.US);
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.US);
        String dateTime = sdf2.format(new Date());
        try {
            String str[] = fileName.split("_");
            if (str != null && str.length > 2) {
                Date date = sdf.parse(str[str.length - 2]);
                dateTime = sdf2.format(date);
            }
        } catch (ParseException e) {

            logger.debug(e.getLocalizedMessage());
            e.printStackTrace();

        } catch (Exception e) {

            logger.debug(e.getLocalizedMessage());
            e.printStackTrace();

        }
        return dateTime;
    }

    public static void checkAndCreateFolders(String pathFolder) {
        File fsc = new File(pathFolder);

        if (!fsc.exists()) {
            fsc.mkdirs();
            logger.debug("create folder is successful >> " + fsc);
        }

    }

    public static String appendFrontSrt(String column) {
        return isNull(column) ? "" : "\'" + column;
    }

    public static HashMap<String, String> convertStringArrayToHash(String data[]) {
        HashMap<String, String> hashMap = new HashMap<>();

        if (!isNull(data)) {
            boolean chk = false;
            for (String prefixFile : data) {
                if (!isNull(prefixFile)) {
                    hashMap.put(prefixFile, prefixFile);
                    chk = true;
                }

            }
            if (chk) {
                return hashMap;
            }
        }
        return null;
    }

}
