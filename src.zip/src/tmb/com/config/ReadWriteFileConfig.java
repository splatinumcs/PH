/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tmb.com.config;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

/**
 *
 * @author 47758
 */
public class ReadWriteFileConfig {

    static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ReadWriteFileConfig.class);

    public static void writeFileProperties(String pathFilename, String keyword, String value) {
        Properties prop = new Properties();
        FileInputStream configStream = null;
        FileOutputStream output =  null;
        try {

            configStream = new FileInputStream(pathFilename);
            prop.load(configStream);

            // set the properties value
            prop.setProperty(keyword, value); 

            output = new FileOutputStream(pathFilename);
            prop.store(output, "This description goes to the header of a file");
           

        } catch (IOException io) {
            io.printStackTrace();
        } finally {
            if (configStream != null) {
                try {
                    configStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } if (output != null) {
                try {
                    output.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }

    }

    public static Properties readFileProperties(String pathFile, String filename) {
        Properties prop = new Properties();
        InputStream input = null;

        try {

            input = new FileInputStream(pathFile + "\\" + filename);

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            // System.out.println(prop.getProperty("database_server"));
            //System.out.println(prop.getProperty("database_port"));
            //System.out.println(prop.getProperty("database_servicename"));
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            /*if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }*/
        }
        return prop;
    }

    public static Properties readFileProperties() {
        Properties prop = new Properties();
        InputStream input = null;

        try {

            input = new FileInputStream(System.getProperty("user.dir") + "/config/pathconfig.properties");

            // load a properties file
            prop.load(input);
            if (prop != null
                    && prop.getProperty("SELECT_DATE") != null) {
                // get the property value and print it out
                logger.debug("SELECT_DATE >> " + prop.getProperty("SELECT_DATE"));
            }

        } catch (IOException ex) {
            ex.printStackTrace();
            logger.error(ex.getLocalizedMessage());
        } finally {
            /*if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }*/
        }
        return prop;
    }
}
