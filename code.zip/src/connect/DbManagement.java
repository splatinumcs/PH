package connect;

import obj.Tranfile;

import org.apache.log4j.Logger;

import sun.misc.BASE64Decoder;
import util.Constant;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import java.security.Key;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import obj.TrantrackingReport;
import tmb.com.config.ConnectDB;
import tmb.com.config.TmbUtility;

public class DbManagement {

    final static Logger logger = Logger.getLogger(DbManagement.class);

    private Properties prop;

    public DbManagement(Properties prop) {
        this.prop = prop;
    }

    public Connection connection() {

        // logger.info("Oracle JDBC Connection");
        try {

            Class.forName("oracle.jdbc.driver.OracleDriver");

        } catch (ClassNotFoundException e) {

            logger.error("Where is your Oracle JDBC Driver?");
            e.printStackTrace();
            return null;

        }

//        logger.debug("Oracle JDBC Driver Registered!");
        Connection connection = null;

        try {

            //  logger.debug(String.format("Connecting to %s", prop.getProperty("db.oracle.url")));
            connection = DriverManager.getConnection(
                    prop.getProperty("db.oracle.url"),
                    prop.getProperty("db.oracle.user"),
                    decrypt(prop.getProperty("db.oracle.pass")));
            //logger.debug(" url = "+prop.getProperty("db.oracle.url"));
            connection.setAutoCommit(false);

        } catch (SQLException e) {
            logger.error("Connection Failed! Check output console");
            e.printStackTrace();
            
            return null;

        } catch (Exception e) {
            e.printStackTrace();
        }

        if (connection != null) {
            // logger.info("Connection database complete!!");
            return connection;
        } else {
            logger.error("Failed to make connection");
        }
        return null;
    }

    public String decrypt(String value) throws Exception {
        Key key = generateKey();
        Cipher cipher = Cipher.getInstance(Constant.Cryto.ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decryptedValue64 = new BASE64Decoder().decodeBuffer(value);
        byte[] decryptedByteValue = cipher.doFinal(decryptedValue64);
        String decryptedValue = new String(decryptedByteValue, "utf-8");
        return decryptedValue;

    }

    private Key generateKey() throws Exception {
        Key key = new SecretKeySpec(Constant.Cryto.KEY.getBytes(), Constant.Cryto.ALGORITHM);
        return key;
    }

    public static int countCon(Connection conn, String sql, String filename) throws SQLException {

        PreparedStatement countstmt = null;
        int count = 0;

        try {

            countstmt = conn.prepareStatement(sql);
            countstmt.setString(1, filename);

            ResultSet rs = countstmt.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }

        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();
        } finally {
            countstmt.close();
        }

        return count;
    }

    public List<String> inquiryTrantrackingReportDataStr(Connection conn, String scripts, String args[]) throws SQLException {

        //logger.info("Compare Tranfile pending..");
        String tranDate = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        //String  tranDate =   new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());

        List<String> allTranfiles = new ArrayList<>();
        //String head = ""PAYSYS_ID","ENTRY_SRL_NUM","REQ_EXEC_DATE","RESERVE_REF_NUM","DR_ACCT","BAT_STATUS","INST_AMT","CHRG_AMT","FP_BATCH_REF_NUM","FP_TRAN_REF_NUM","NAME","BATCH_ID","TRAN_DATE","EVENT_ID","X","'SUCCESS'","DRCR";
        //TrantrackingReport tranfile = new TrantrackingReport(); 
        allTranfiles.add(new TrantrackingReport().head());
        //logger.info(" debug = " + args.length);
        ResultSet rs = null;
        if (args != null && args.length >= 2 && !TmbUtility.isNull(args[1])) {
            tranDate = args[1];//"20190620";
        }
        scripts = scripts.replace("#PARAM_TRANDATE", tranDate);
        PreparedStatement preStmt = conn.prepareStatement(scripts);
        //logger.debug("PreparedStatement : " + scripts);
        try {

            rs = preStmt.executeQuery();
          //  logger.debug("PreparedStatement executeQuery complete!!");
           // logger.info("Compare logs with database..");

            while (rs.next()) {
                TrantrackingReport tranfile = new TrantrackingReport();
                tranfile.setPaysys(rs.getString(1));
                tranfile.setEntrySrlNum(rs.getString(2));
                tranfile.setRecExecDate(rs.getDate(3));
                tranfile.setReserveRevNum(rs.getString(4));
                tranfile.setDrAcct(rs.getString(5));
                tranfile.setBatStatus(rs.getString(6));
                tranfile.setInstAmt(rs.getDouble(7));
                tranfile.setChrgAmt(rs.getDouble(8));
                tranfile.setFpBatchRefNum(rs.getString(9));
                tranfile.setFpTranRefNum(rs.getString(10));
                tranfile.setName(rs.getString(11));
                tranfile.setBatchId(rs.getString(12));
                tranfile.setTranDate(rs.getDate(13));
                tranfile.setEventId(rs.getString(14));
                tranfile.setX(rs.getString(15));
                tranfile.setStatus(rs.getString(16));
                tranfile.setDrCr(rs.getString(17));
                //String data1 = tranfile.toDataLine();
                allTranfiles.add(tranfile.toDataLine());
            }

            if (allTranfiles.isEmpty()) {
                logger.info("No Tranfile pending");
            } else {
                logger.info("Complete Tranfile pending!!");
            }

        } finally {
            if (rs != null) {
                try {
                    ConnectDB.closeResultSet(rs);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            if (preStmt != null) {
                try {
                    ConnectDB.closePreparedStatement(preStmt);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    ConnectDB.closeConnection(conn);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        return allTranfiles;
    }

    private String appendData(TrantrackingReport tranfile) {
        StringBuilder stemp = new StringBuilder();
        stemp.append(tranfile.toString());

        return stemp.toString();

    }

    public List<TrantrackingReport> inquiryTrantrackingReportData(Connection conn, String scripts, String args[]) throws SQLException {

        logger.info("Compare Tranfile pending..");
        String tranDate = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        //String  tranDate =   new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());

        List<TrantrackingReport> allTranfiles = new ArrayList<>();
        logger.info(" tranDate= " + tranDate);
        ResultSet rs = null;
        if (args != null && args.length > 1) {
            tranDate = args[1];//"20190620";
        }

        scripts = scripts.replace("#PARAM_TRANDATE", tranDate);
        PreparedStatement preStmt = conn.prepareStatement(scripts);
        logger.debug("PreparedStatement : " + scripts);
        try {

            rs = preStmt.executeQuery();
            logger.debug("PreparedStatement executeQuery complete!!");
            logger.info("Compare logs with database..");

            while (rs.next()) {
                TrantrackingReport tranfile = new TrantrackingReport();
                tranfile.setPaysys(rs.getString(1));
                tranfile.setEntrySrlNum(rs.getString(2));
                tranfile.setRecExecDate(rs.getDate(3));
                tranfile.setReserveRevNum(rs.getString(4));
                tranfile.setDrAcct(rs.getString(5));
                tranfile.setBatStatus(rs.getString(6));
                tranfile.setInstAmt(rs.getDouble(7));
                tranfile.setChrgAmt(rs.getDouble(8));
                tranfile.setFpBatchRefNum(rs.getString(9));
                tranfile.setFpTranRefNum(rs.getString(10));
                tranfile.setName(rs.getString(11));
                tranfile.setBatchId(rs.getString(12));
                tranfile.setTranDate(rs.getDate(13));
                tranfile.setEventId(rs.getString(14));
                tranfile.setX(rs.getString(15));
                tranfile.setStatus(rs.getString(16));
                tranfile.setDrCr(rs.getString(17));
                allTranfiles.add(tranfile);
            }

            if (allTranfiles.isEmpty()) {
                logger.info("No Tranfile pending");
            } else {
                logger.info("Complete Tranfile pending!!");
            }

        } finally {
            if (rs != null) {
                try {
                    ConnectDB.closeResultSet(rs);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            if (preStmt != null) {
                try {
                    ConnectDB.closePreparedStatement(preStmt);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    ConnectDB.closeConnection(conn);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        return allTranfiles;
    }

}
