package com.tmb.business;

import gen.CompareFiles;

import java.io.File;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import obj.Pofile;
import tmb.com.config.TmbUtility;
import connect.FileSFTP;

public class ReconcileFileFromCib {

	final static Logger logger = Logger.getLogger(ReconcileFileFromCib.class);
	private Properties prop;
	private SimpleDateFormat dateFormat;

	public ReconcileFileFromCib(Properties prop, SimpleDateFormat dateFormat) {
		this.prop = prop;
		this.dateFormat = dateFormat;
	}

	public List<Pofile> reconcileCIBWithPH(File backupFile) throws SQLException {

		FileSFTP fileSFTP = new FileSFTP(prop);

		String[] reconFile = fileSFTP.getFileFromSftpCIBRecon();
		if(!TmbUtility.isNull(reconFile)){
			for(String lstitem : reconFile){ 
				 
				logger.info("List item: " + lstitem);
			} 
		}



		return null;


	}

}
