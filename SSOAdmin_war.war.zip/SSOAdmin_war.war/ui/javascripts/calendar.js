
var ieDialogArgs = "";
arr2 = new Array();
dateField = "";
var browser_name = navigator.appName;

function setTodayCur()
{
	var now   = new Date();
	var day   = now.getDate();
	var month = now.getMonth();
	var year  = now.getFullYear();
	if (year < 100)
	{
		year += 1900;
	}
	document.calControl.month.selectedIndex = month;
        document.calControl.year.value = year;
	this.focusDay=day;
	displayCalendar(day, month, year);
}


function setToday(ieArgs)
{ 
	var now   = new Date();
	var day   = now.getDate();
	var month = now.getMonth();
	var year  = now.getFullYear();
	var isMMDD = false;

	if (year < 100)
	{
		year += 1900;
	}
	document.calControl.year.value=year;
	ieDialogArgs = ieArgs;
	var bodDateLoc = ""; 
	if(browser_name == "Microsoft Internet Explorer")
	{
		bodDateLoc= ieArgs['bodDate'];
		isMMDD = ieArgs['isMMDD'];
		
	}
	else{
		bodDateLoc=window.opener.currDate;
		isMMDD=window.opener.isMMDD;
	}
	
	if(bodDateLoc != '')
	{
		var locBod = bodDateLoc;
		var hyphen = locBod.indexOf('-');
		day = locBod.substring(0, hyphen);
		locBod = bodDateLoc.substring(hyphen + 1);
		hyphen = locBod.indexOf('-');
		month = locBod.substring(0,hyphen);
		year = locBod.substring(hyphen + 1);

		if(isMMDD){  //Swap day and month
			var swapVar = day;
			day = month;
			month = swapVar;
		}
		month = parseInt(month,10) - 1;
	}

	this.focusDay = parseInt(day,10);

	document.calControl.month.selectedIndex = month;
   /* if(LocalYear == "Y") {
        var loc_year = "";
        loc_year = parseInt(year);
        loc_year = loc_year + parseInt(NumLocYears);
        loc_year = loc_year.toString();
        document.calControl.year.value = loc_year;

    }
    else {*/
        document.calControl.year.value = year;
		displayCalendar(day, month, year);

  //  }
	
}
function isDigits(year)
{
	var intLen,intIndex,ch;
	intLen=year.length;
    for (intIndex=0; intIndex<intLen; intIndex++)
	{
		ch=year.charAt(intIndex);
		if (!(ch >= '0' && ch <= '9'))
		{
			alert("Year cannot have alphabets!");
			document.calControl.year.select();
			document.calControl.year.focus();
			return false;
		}

       	}
	return true;
}
function isFourDigitYear(year)
{
	if (year.length != 4)
	{
		alert("Sorry, the year must be four digits in length.");
		document.calControl.year.select();
		document.calControl.year.focus();
	}
	else
	{
		return true;
	}
}

function selectDate()
{
	var year  = document.calControl.year.value;
	var resetYear=new Date().getFullYear();

	if (isFourDigitYear(year) && isDigits(year))
	{
		var day   = 0;
		var month = document.calControl.month.selectedIndex;
		displayCalendar(day, month, year);
	}
	else
	document.calControl.year=resetYear;
}

function setPreviousYear()
{
	var year  = document.calControl.year.value;
	
	if (isFourDigitYear(year))
	{
		var day   = 0;
		var month = document.calControl.month.selectedIndex;
        	year--;
		document.calControl.year.value = year;
       /* if(LocalYear == "Y")
        {
            var loc_year = "";
            loc_year = parseInt(year);
            loc_year = loc_year - parseInt(NumLocYears);
            year = loc_year.toString();
        }*/
        	displayCalendar(day, month, year);
	}
}

function setPreviousMonth()
{
	var year  = document.calControl.year.value;
	if (isFourDigitYear(year))
	{
        	var day   = 0;
        	var month = document.calControl.month.selectedIndex;
        	if (month == 0)
	        {
            		month = 11;
			if (year > 1000)
			{
               			year--;
				document.calControl.year.value = year;
			}
       		}
       		else
		{
			month--;
		}
		document.calControl.month.selectedIndex = month;
      /*  if(LocalYear == "Y")
        {
            var loc_year = "";
            loc_year = parseInt(year);
            loc_year = loc_year - parseInt(NumLocYears);
            year = loc_year.toString();
        }*/
		displayCalendar(day, month, year);
	}
}

function setNextMonth()
{
	var year  = document.calControl.year.value;
	if (isFourDigitYear(year))
	{
		var day   = 0;
		var month = document.calControl.month.selectedIndex;
		if (month == 11)
		{
			month = 0;
			year++;
			document.calControl.year.value = year;
		}
		else
		{
			month++;
		}
		document.calControl.month.selectedIndex = month;
       /* if(LocalYear == "Y")
        {
            var loc_year = "";
            loc_year = parseInt(year);
            loc_year = loc_year - parseInt(NumLocYears);
            year = loc_year.toString();
        }*/
		displayCalendar(day, month, year);
	}
}

function setNextYear()
{
	var year  = document.calControl.year.value;
	if (isFourDigitYear(year))
	{
		var day   = 0;
		var month = document.calControl.month.selectedIndex;
		year++;
		document.calControl.year.value = year;
       /* if(LocalYear == "Y")
        {
            var loc_year = "";
            loc_year = parseInt(year);
            loc_year = loc_year - parseInt(NumLocYears);
            year = loc_year.toString();
        }*/
		displayCalendar(day, month, year);
	}
}

function displayCalendar(day, month, year)
{
	day     = parseInt(day,10);
	month   = parseInt(month,10);
	year    = parseInt(year,10);

	var i   = 0;
	var now = new Date();
	if (day == 0)
	{
		var nowDay = now.getDate();
	}
	else
	{
		var nowDay = day;
	}
	var days = getDaysInMonth(month+1,year);
	var firstOfMonth = new Date (year, month, 1);
	var startingPos  = firstOfMonth.getDay();

	days += startingPos;
	/* Finacle 9.0 Change: Start */
	for (i = 0; i < startingPos; i++)
	{	
		document.calButtons.elements[i].value = "";
		document.calButtons.elements[i].className = "calendarbutton";
	}
	for (i = startingPos; i < startingPos+9; i++)
	{
		document.calButtons.elements[i].value =i-startingPos+1+'  ';
		document.calButtons.elements[i].className = "calendarbutton";
	}
	for (i = startingPos+9; i < days; i++)
	{
		
		document.calButtons.elements[i].value = i-startingPos+1;
		document.calButtons.elements[i].className = "calendarbutton";
	}
	for (i=days; i<42; i++)
	{	
		document.calButtons.elements[i].value = "";
		document.calButtons.elements[i].className = "calendarbutton";
	}
	document.calButtons.elements[focusDay+startingPos-1].className = "calendarselectedbutton";

	/* Finacle 9.0 Change: End */
}

function getDaysInMonth(month,year)
{
	var days;
	if (	month==1 || month==3 || month==5 ||
		month==7 || month==8 ||month==10 || month==12)
	days=31;
	else if (month==4 || month==6 || month==9 || month==11)
		days=30;
	else if (month==2)
	{
		if (isLeapYear(year))
		{
			days=29;
		}
		else
		{
			days=28;
		}
	}
	return (days);
}

function isLeapYear (Year)
{
	if (((Year % 4)==0) && ((Year % 100)!=0) || ((Year % 400)==0))
	{
		return (true);
	}
	else
	{
		return (false);
	}
}


function returnDate(inDay)
{ 
	
	var newday = inDay;
	var month = (document.calControl.month.selectedIndex)+1;
	var year  = document.calControl.year.value;
	var moninmm;
	// Finacle follows "DD-MM-YYYY" format of date.
	var arr = new Array('01','02','03','04','05','06','07','08','09','10','11','12');
   
	for(var index = 1;index <= 12;index++)
	{
		if(month == index)
		{
			moninmm = arr[index-1];
		}
	}

	if ((""+month).length == 1)
	{
		month="0"+month;
	}

	if (parseInt(newday,10) < 10)
	{
		newday="0"+parseInt(newday,10);
	}

	if (newday != "")
	{
		var doc="";
		var textFldNameLoc ="";
		var isMMDD = false;
		if("Microsoft Internet Explorer" == browser_name)
		{
			var args = ieDialogArgs;
			doc = args['doc'];
			textFldNameLoc = args['textFldName'];
			isMMDD = args['isMMDD'];
		}
		else
		{
			doc = window.opener.document;
			textFldNameLoc =  window.opener.textFldName;
			isMMDD=window.opener.isMMDD;
		}
		
		dateField = newday +"-"+ moninmm + "-" + year;
		if(isMMDD) dateField = moninmm +"-"+ newday + "-" + year;
		doc.forms[2].elements[textFldNameLoc].value = dateField;
		window.close();
	}
}

if("Microsoft Internet Explorer" == browser_name) {
	if(ieDialogArgs['langCode'] == "ARABIC") {
		document.write('<HTML dir=RTL></HTML>');
	}
}
else {
	if(window.opener.gLangCode == "ARABIC") {
		document.write('<HTML dir=RTL></HTML>');
	}
}

//</script>
