//-----------------------------------------------------
// script to be used by SSO core html/jsp pages
// individual applications integrated in to sso are assumed
// to have their own script files
//
//
// author preethi
//
//-----------------------------------------------------

var timerID = null;
var allowedDeskTopIdleTime = 1800000;
var checkInterval = 60000;
var timeoutWarningTime = 60000;
var currDate = new Date();
var prevEventDate = new Date();
var rb;
var doc;
var sess;
var userID;
var langCode;
var resourceArr = new Array();
var browser_name = navigator.appName;
var defApplication = null;
var loggedOut = false;
var ssoLocked = 0;
var isTwoFactorAuthReq = "";
var currEntity = "";
var homeEntity = "";
var previousEntity = "";
var prevDeskTopTimeZone = "";
var defTimeZone = "";
var tzOffset = 0;
var calendarFormat = "";
var calDesc = "";
var isGlobalAdmin = "";
var GREG_CAL = 'G';
var GREG_CAL_DES = 'Gregorian';
var selectedResID = 'none';
var loginData = "";
var logoutData = "";
var failedLoginData = "";
var entityArray = new Array();
var entityResArray = new Array();
var entityResRefArray = new Array();
var appInputArr = new Array();
var currentResList = new Array();
var previousResList = new Array();
var entityDefResMap = new Array();
var tzArray = new Array();
var adminURL = "";
var ERR_LCL_PARAM_NOT_FOUND = 1042;
var ERR_LCL_PARAM_IN_RANGE = 1051;
var ERR_LCL_PARAM_IN_BUFFER = 1052;
var ERR_LCL_PARAM_OUT_OF_RANGE = 1053;
var ERR_LIC_SERVER = -9999;
var LOCK_TIME_OUT = 212;
var MAX_PWD_ATTEMPTS = 49;
var tik_enable = 'N';
var isAuthVal = "false";
var calListLen;

if (!Array.prototype.indexOf)
{
	Array.prototype.indexOf = function(elt /*, from*/)
	{
		var len = this.length;

		var from = Number(arguments[1]) || 0;
		from = (from < 0) ? Math.ceil(from) : Math.floor(from);
		
		if (from < 0)
			from += len;

		for (; from < len; from++)
		{
			if (from in this && this[from] === elt)
				return from;
		}
		return -1;
	};
}

if(!Array.prototype.add)
{
	Array.prototype.add = function (element) {
		if(this.indexOf(element) == -1)
			this.push(element);
		return this;
	};
}

if (!Array.prototype.pushAll)
{
	Array.prototype.pushAll = function(newArr, exceptArr)
	{
        var exists = false;
        if(null != newArr)
        {
            for(var  i = 0 ; i < newArr.length ; i++)
            {
                exists = false;
                if(null != exceptArr)
                {
                    for(var j = 0 ; j < exceptArr.length ; j++)
                    {
                        if(exceptArr[j] == newArr[i])
                        {
                            exists = true;
                            break;
                        }
                    }
                }

                if(!exists)
                {
                    this.add(newArr[i]);
                }
            }
        }
        return this;
    };
}

//set the resource bundle to proper language specific resbundle
function setSSOResourceBundle(SSOJSResourceBundle)
{
	rb = SSOJSResourceBundle;
}	

// show the status message given in the status bar of the window
function showStatus(statusMsg)
{
	window.status = statusMsg;
}

//sets the idle time value for desktop
function setAllowedIdleTime(idleTime)
{
	if(idleTime != 0) allowedDeskTopIdleTime = idleTime * 60 * 1000;
}

//sets the default desktop application
function setDefaultApplication(appID)
{
	defApplication = appID;
}

//show default application
function showDefaultApplication()
{
	refreshTicker();
	if(!defApplication || null == defApplication ||
        defApplication == 'null' || undefined == defApplication ||
        "undefined" == defApplication)
	{
		setSelectedValue("appSelect", 'none');
		showFrame("DeskTop", null);
		document.dskAppForm.appSelect.focus();
	}
	else
	{	
		setSelectedValue("appSelect", defApplication);
		alert(rb.REDIRECT_DEF_APP);
		showApplication(defApplication, resourceArr[defApplication].resDisplayText, 
			resourceArr[defApplication].url);
	}
		
}

// to set the attributes of desktop for that particular logged in user
// These attributes could be used by other applications
function setDeskTopAttributes(doc, sess, userID, langCode, resArr)
{
	doc = doc;
	sess = sess;
	userID = userID;
	langCode = langCode;
	resourceArr = resArr;	
}

//used by rest of the applications
function getSessionID()
{
	return sess;
}

function getUserID()
{
	return userID;
}

function getLangCode()
{
	return langCode;
}

// display the application window
function showApplication(appID, windowName, startURL)
{
	var doc = window.parent.appletFrame.document;
	
	var serviceToken = "";
	var frameStr = null;
	if(sess == null || sess == "")
	{
		alert(SSOJSResourceBundle.ERR_INVALID_SESSION);
		return;
	}
	try{
		if(checkExists(appID) == 'N')
		{
			frameStr = "<iframe name='"+ appID + "' src='"+ startURL +
				"' width=100% height=100%></iframe>";
			showFrame(appID, frameStr);
			setDelayedStartApp(appID);
			return;
		}
		else if(window.frames[appID].getLoggedStatus && 
				(window.frames[appID].getLoggedStatus() != 1))
		{
			setDelayedStartApp(appID);
		}
		else {
			//Change the calendar dropdown to the present supported calendar type
			//of the application which will be in focus
			if(calListLen > 1 && (calendarFormat != resourceArr[appID].currCal)){
				setSelectedValue("calSelect", resourceArr[appID].currCal);
				calDesc = resourceArr[appID].currCalDesc;
			}
		}
		showFrame(appID, frameStr);
	}
	catch(exc)
	{
		alert(SSOJSResourceBundle.ERR_NO_APPLN + exc.message);
	}
	return;
}

var delayedStartappID;
var loopCount = 0;

function setDelayedStartApp(appId)
{
	if(0 != loopCount)
	{
		alert(SSOJSResourceBundle.ERR_DESKTOP_BUSY);
	}
	else
	{
		delayedStartappID = appId;
		loopCount = 1;
		window.setTimeout("delayedStartApp()", 500);
	}
}

function delayedStartApp()
{
	if(typeof window.frames[delayedStartappID] !== 'undefined' && typeof window.frames[delayedStartappID].login !== 'undefined' &&
	   typeof window.frames[delayedStartappID] !== 'unknown' && typeof window.frames[delayedStartappID].login !== 'unknown')
	//Below line is commented to avoid permission denied error.  
	//if(window.frames[delayedStartappID].login)
	{
		loopCount = 0;		
		srvcTok = getSvcToken(delayedStartappID);
		
		if(null == srvcTok || "" == srvcTok)
		{
			alert(rb.ERR_GET_SRVC_TOK+delayedStartappID);
			loopCount = 0;
			return;
		}
		//Set the calendar in appInput Array to the global calendar value
		//if application supports the calendar type
		//else, set the appInput Array calendar value to Gregorian
		
		//Below line is commented to avoid permission denied error.  
		//if(window.frames[delayedStartappID].isValidCal && 
		//				window.frames[delayedStartappID].isValidCal(calendarFormat))
		if(typeof window.frames[delayedStartappID].isValidCal !== 'undefined' && typeof window.frames[delayedStartappID].isValidCal !== 'unknown' &&
					window.frames[delayedStartappID].isValidCal(calendarFormat))				
		{
			appInputArr['calendarFormat'] = calendarFormat;
			appInputArr['calDesc'] = calDesc;
		}
		else{ 
			appInputArr['calendarFormat'] = GREG_CAL;
			appInputArr['calDesc'] = GREG_CAL_DES;
			//Set the calendar dropdown to the supported calendar type of the
			//selected resource, if required
			if(calListLen > 1 && (calendarFormat != GREG_CAL)){
				setSelectedValue("calSelect", GREG_CAL);
				calDesc = GREG_CAL_DES;
			}
		}
		
		//Set the timezone in appInputArr to the global timezone in all applications
		appInputArr['timezoneName'] = defTimeZone;
		appInputArr['timezoneOffset'] = tzArray[defTimeZone];		
		
		window.frames[delayedStartappID].login(srvcTok, userID, sess, langCode, currEntity, appInputArr);
	
		//Set the cal value in Resource array for the application accordingly
		resourceArr[delayedStartappID].currCal = appInputArr['calendarFormat'];
		resourceArr[delayedStartappID].currCalDesc = appInputArr['calDesc'];
	}
	else
	{
		if(loopCount > 20)
		{
			alert(delayedStartappID + ": "+ SSOJSResourceBundle.ERR_NO_LOGIN);
			loopCount = 0;
			return;
		}
		else
		{
			window.setTimeout("delayedStartApp()", 2000);
			loopCount++;
			return;
		}
	}
}

// to show the frame corresponding to the appID passed in.
// Also change the contents to the displayStr if not null.
function showFrame(appID, displayStr)
{
	
	var currZIndex = 0;
	var divs = cbeGetElementsByTagName('DIV');
	for(var i = 0; i < divs.length; i++)
	{	
		with(divs[i].cbe)
		{
			if(visibility() == 1)
			{
				currZIndex = zIndex();
				hide();
			}
		}

	}
	with(divs[appID].cbe)
	{	
		zIndex(currZIndex + 10);
		show();
	}

	if(displayStr != null) divs[appID].innerHTML = displayStr;
	if(window.frames[appID]) window.frames[appID].focus();
	return;
}

// This function called from SSO keep alive thread on keep alive failure
// Internally calls logout with a timeout
// Introduced to achieve decoupling as directly calling logout() 
// from thread causes browser to hang.
function delayedLogout(mode, langCode)
{
	functionName = "logout('"+mode+"','"+langCode+"')";
	window.setTimeout(functionName,3000);
}

//logout the user, takes in the mode of logout, n if normal
// and t if forced logout due to timeout.
function logout(mode, langCode)
{
	if(loggedOut) return;
	if (mode != "F" && !confirm(rb.CONFIRM_LOG_OUT) )
	{
		return;
	}
	window.clearTimeout(timerID);

	var currentFrame = null;
	var doc = window.parent.appletFrame.document;

	var noOfFrames = window.frames.length;
	for(var i = 0; i < noOfFrames; i++)
	{
		currentFrame = window.frames[i];
		try{
			if(currentFrame.getLoggedStatus && currentFrame.getLoggedStatus() == 1)
			{
				if(currentFrame.logout) currentFrame.logout(mode);
			}
		}
		catch(ex) { continue; } 
	}
	
    clearAjaxResponseArr();

	if(doc.ClientApp.logout(sess, mode) != 0)
	{
		alert(doc.ClientApp.getErrorMessage());
	}
	
	loggedOut = true;
	window.parent.loginFrame.location.replace("ui/"+langCode+"/Logout.jsp?LCLANG="+langCode);
}

// logout the user for lock, takes in the mode of logout, 
// n if normal and f if forced logout due to timeout.
function lockLogout(mode, langCode)
{
	if(loggedOut) return;
	if (mode != "F" && !confirm(rb.CONFIRM_LOG_OUT) )
	{
		return;
	}
	window.clearTimeout(timerID);

	var currentFrame = null;
	var doc = window.parent.appletFrame.document;

	var noOfFrames = window.frames.length;
	for(var i = 0; i < noOfFrames; i++)
	{
		currentFrame = window.frames[i];
		try{
			if(currentFrame.getLoggedStatus && currentFrame.getLoggedStatus() == 1)
			{
				if(currentFrame.logout) currentFrame.logout(mode);
			}
		}
		catch(ex) { continue; }
	}
}

var idleWarningRet;
// check whether the desktop has been idle for more than the set limit
function isIdle()
{	
	var appletObj = window.parent.appletFrame.document.ClientApp;
	currDate = new Date();
	var currTime = Date.parse(currDate.toString());
	var prevTime = Date.parse(prevEventDate.toString());
	if(ssoLocked == 0 && currTime - prevTime >= (allowedDeskTopIdleTime-timeoutWarningTime))
	{
		var noOfFrames = window.frames.length;
		for(var i = 0; i < noOfFrames; i++)
		{
			currentFrame = window.frames[i];

			//if at least one application is not idle for this much time
			// do not logout.
			try {
				if(currentFrame.getLoggedStatus &&
				    currentFrame.getLoggedStatus() == 1) 
				{
					if(currentFrame.getIdleTime && 
						currentFrame.getIdleTime() <= (allowedDeskTopIdleTime-timeoutWarningTime))
					{
						timerID  = window.setTimeout("isIdle()", checkInterval);
						return;
					}
				}
				
			}
			catch(ex) 
			{ 
				var appName = "SSODeskTop";
				var methodName = "isIdle";
				if(currentFrame && currentFrame.name)
				{
					appName = currentFrame.name;
					methodName = "getIdleTime";
				}
				appletObj.logTime(appName, methodName, ex.message);
				continue; 
			}
		}
		if("Microsoft Internet Explorer" == browser_name)  {
		   		
			idleWarningRet = window.showModalDialog("ui/"+langCode+"/WarnTimeout.jsp?LCLANG=" + langCode, "", "dialogWidth:23;dialogHeight:8;status=no;toolbar=no;menubar=no;help=no;resizable=no");
		}else{
			var topPos=screen.availHeight/2-29;
			var leftPos=screen.availWidth/2-148;
			idleWarningRet = window.showModalDialog("ui/"+langCode+"/WarnTimeout.jsp?LCLANG=" + langCode, "", "dialogWidth: 297;dialogHeight:58;dialogLeft:"+leftPos+";dialogTop:"+topPos+";resizable: no;scroll: no;center: yes;help: no;resizable: no");
       		}
		
		checkIdleAndLogout();
	}
	else
	{
		timerID  = window.setTimeout("isIdle()", checkInterval);
	}
}


// Checks whether idle timeout has happened and
// logs the user out, else resets the idle timer
function checkIdleAndLogout()
{
	if(idleWarningRet == 'false')
	{
		logout("F", langCode);
		alert(rb.ERR_TIME_OUT);
	}
	else
	{
		resetTimer();
		timerID  = window.setTimeout("isIdle()", checkInterval);
	}
}

//check whether the application already exists in the array given
function checkExists(appID)
{
	var noOfFrames = window.frames.length;
	for(var i = 0; i < noOfFrames; i++)
	{
		currentFrame = window.frames[i];
		try{
			if(currentFrame.name == appID)
			{
				return 'Y';
			}
		}
		catch(ex)
		{
			//continue in the loop, since exception in getting name
			//implies the frame was not created properly
			continue;
		}
	}
	return 'N';
}


var delayedInvokeContextappID;
var invokeContextLoopCount = 0;
var delayedInvokeContextData;
var delayedInvokeMenu;

function setDelayedInvokeApplWithContext(appId, contextData, menu)
{
	if(0 != invokeContextLoopCount)
	{
		alert(SSOJSResourceBundle.ERR_DESKTOP_BUSY);
	}
	else
	{
		delayedInvokeContextappID = appId;
		invokeContextLoopCount = 1;
		delayedInvokeContextData = contextData;
		delayedInvokeMenu = menu;
		window.setTimeout("delayedInvokeApplWithContext()", 500);
	}
}

function delayedInvokeApplWithContext()
{
	var doc = window.frames[delayedInvokeContextappID];
	if(doc.getLoggedStatus && (doc.getLoggedStatus() == 1) && doc.invokeActionWithContext)
	{
		doc.invokeActionWithContext(delayedInvokeContextData, delayedInvokeMenu);
		delayedInvokeContextData = null;
		delayedInvokeMenu = null;
		invokeContextLoopCount = 0;
	}
	else
	{

		if(invokeContextLoopCount > 40)
		{
			invokeContextLoopCount = 0;
			delayedInvokeContextData = null;
			delayedInvokeMenu = null;
			alert(delayedInvokeContextappID + ": "+ SSOJSResourceBundle.ERR_NO_CONTEXT_INTEG);
			return;
		}
		else
		{
			invokeContextLoopCount++;
			window.setTimeout("delayedInvokeApplWithContext()", 500);
			return;
		}
	}
}

//invoke the given application with the given context data and menu option
function invokeApplicationContext(appID, contextData, menu)
{
    var count = 0;
    var resList = entityResArray[currEntity];

    var tempResArr = new Array(0);
    for(var i = 0; i < resList.length; i++)
    {    	
        if(resList[i].indexOf(appID) != -1)
        {
            tempResArr[count++] = resList[i];            
        }
    }
    if(tempResArr.length == 0) {
        alert(SSOJSResourceBundle.ERR_NO_RES);
        return;
    }
    var selectedResource = tempResArr[0];
    if(tempResArr.length > 1){
        for(var i = 1; i < tempResArr.length; i++)
        {
            if(isUserLoggedInToApp(tempResArr[i])) {
                selectedResource = tempResArr[i];
                break;
            }
        }
    }
	setSelectedValue("appSelect", selectedResource);
    showApplication(resourceArr[selectedResource].name, 
			resourceArr[selectedResource].resDisplayText, resourceArr[selectedResource].url);
    setDelayedInvokeApplWithContext(selectedResource, contextData, menu);
    return;            
}
//authorizer validation, to be used by applications.
var authorizerToken = new Array();
var authTokenUser = null;

function validateAuthorizer(title)
{
	
   	return validateAuthorizerCommon(null, title);
}

function validateAuthorizerWithWnd(wndRef, title)
{
	return validateAuthorizerCommon(wndRef, title);
}
function validateAuthorizerCommon(wndRef, title)
{
	
	noOfArg = arguments.length;
	
	var doc = window.parent.appletFrame.document;
	
	authTokenUser = null;

	isAuthVal = "true";

	winref = window;
	idFlag = 'N';
	
	if((null != wndRef) && ( typeof wndRef !='string')){
		winref = wndRef;
	}
	if((null != wndRef) && (typeof wndRef =='string')){
		authTokenUser = wndRef;
		idFlag = 'Y';
	
	}

	if("Microsoft Internet Explorer" == browser_name) {
		var argArr = new Array();
		argArr['doc'] = doc;
		argArr['lang'] = langCode;
		argArr['user'] = userID;
		argArr['idleTime'] = allowedDeskTopIdleTime;
		if(idFlag =='Y'){
			window.showModalDialog(cdBaseURL+"?CALLTYPE=GET_AUTHORIZER_PAGE&APP_USER_ID="+ authTokenUser+"&LCLANG="+langCode+"&TITLE="+title, argArr,"dialogWidth:626px;dialogHeight:400px;status=no;toolbar=no;menubar=no;resizable=no;scroll=no");
		}else{
			authTokenUser = winref.showModalDialog(cdBaseURL+"?CALLTYPE=GET_AUTHORIZER_PAGE&LCLANG="+langCode+"&TITLE="+title, argArr, "dialogWidth:626px;dialogHeight:400px;status=no;toolbar=no;menubar=no;resizable=no;scroll=no");
   		}
   	} 
   	else {
   		var topPos = screen.availHeight/2 - 189;
	   	var leftPos = screen.availWidth/2 - 313;
	   	if(idFlag =='Y'){
	   		window.showModalDialog(cdBaseURL+"?CALLTYPE=GET_AUTHORIZER_PAGE&APP_USER_ID="+ authTokenUser+"&LCLANG="+langCode+"&TITLE="+title, '', "dialogWidth:625px;dialogHeight:377px;dialogTop: "+topPos+"px;dialogLeft: "+leftPos+"px;status: no;toolbar: no;menubar: no;resizable: no;scroll: no");
		}else{
	   		authTokenUser = window.showModalDialog(cdBaseURL+"?CALLTYPE=GET_AUTHORIZER_PAGE&LCLANG="+langCode+"&TITLE="+title, '', "dialogWidth:626px;dialogHeight:377px;dialogTop: "+topPos+"px;dialogLeft: "+leftPos+"px;status: no;toolbar: no;menubar: no;resizable: no;scroll: no");
   		}
   	}
   	if(null == authTokenUser) return null;
	var appletObj = doc.ClientApp;
	if(isValidTwoFactorAuthWithWnd(wndRef, appletObj, authTokenUser,langCode, "true")){
		authorizerToken['user'] = authTokenUser;
		authorizerToken['token'] = appletObj.getAuthorizerToken();
	}
   	return authorizerToken;
} 

function validateAuthorizerWithID(user,title)
{
	return validateAuthorizerCommon(user, title);
	
}
//to invoke the desktop icon from application
function invokeApp(appID)
{
	if(typeof window.frames[appID].getLoggedStatus !== 'undefined' && typeof window.frames[appID].getLoggedStatus !== 'unknown' && 
			  window.frames[appID].getLoggedStatus() != 1)
	{
		serviceToken = getSvcToken(appID);
		if(null == serviceToken || "" == serviceToken)
		{
			alert(rb.ERR_GET_SRVC_TOK+appID);			
			return;
		}
		if(window.frames[appID].login)
		{
			if(typeof window.frames[appID].isValidCal !== 'undefined' && typeof window.frames[appID].isValidCal !== 'unknown' && 
				window.frames[appID].isValidCal(calendarFormat))
					  appInputArr['calendarFormat'] = calendarFormat;
			else{
				  appInputArr['calendarFormat'] = GREG_CAL;
			 }
				    		
			//Set the timezone in appInputArr to the global timezone in all applications
			appInputArr['timezoneName'] = defTimeZone;
	    	appInputArr['timezoneOffset'] = tzArray[defTimeZone];
			window.frames[appID].login(serviceToken, userID, sess, langCode,currEntity, appInputArr);
		}
		else
		{
			alert(appID + ": "+ SSOJSResourceBundle.ERR_NO_LOGIN);
		}
	}
}


//set the synchronization status icon
//TODO:revisit this
// this is called from SSO applet to set the linked/delinked icon
// The same is also triggered based on a timer which checks for local/central status
function setSynchronized(status)
{
	if(status == 0)
	{
		cbeGetElementsByTagName('SPAN')['synchSpan'].innerHTML = linked;
	}
	else
	{
		cbeGetElementsByTagName('SPAN')['synchSpan'].innerHTML = delinked;
	}
}

//synchronize the sessions with center
function performSynch()
{
	window.parent.appletFrame.document.ClientApp.performSynch(sess);
}

function isUserLoggedInToApp(appID)
{
	if(cbeGetElementsByTagName('DIV')[appID] && 
		cbeGetElementsByTagName('DIV')[appID].innerHTML == "&nbsp;") 
	{
		return false;
	}	
	if(window.frames[appID] && window.frames[appID].getLoggedStatus &&
			(window.frames[appID].getLoggedStatus() == 1))
	{
		return true;
	}
	return false;
}
//encrypt the string given for this user
function encryptStr(anyStr)
{
	return doc.ClientApp.encrypt(anyStr);
}
//get the arguments required for authorizer login
function getAuthorizerArgs()
{
    var argArrAuth = new Array();
    argArrAuth['doc'] = doc;
    argArrAuth['loginDoc'] = window.parent.loginFrame.document;
    argArrAuth['lang'] = langCode;
    argArrAuth['user'] = userID;
    argArrAuth['idleTime'] = allowedDeskTopIdleTime;
    return argArrAuth;
}

//select the drop-down and go to respective application
function goToApp() 
{
	var prevResource = selectedResID;
	prevEventDate = new Date();
	pgIndex = document.dskAppForm.appSelect.selectedIndex;	
	selectedResID = document.dskAppForm.appSelect.options[pgIndex].value;
	if(selectedResID == 'none'){
		alert(rb.ERR_NO_APP_SELECTED);
		setSelectedValue("appSelect", prevResource);
	}
	
	else if(confirm(rb.CONFIRM_APP_CHG_MSG)) {
			showApplication(selectedResID,resourceArr[selectedResID].resDisplayText,
				resourceArr[selectedResID].url);				
	}
	
	else{
		setSelectedValue("appSelect", prevResource);
	}
}

//automatically start the application
function autoStartApp(appID)
{	
    if(window.frames[appID] !== 'undefined' && window.frames[appID] !== 'unknown' && window.frames[appID].getLoggedStatus !== 'undefined' &&
	   window.frames[appID].getLoggedStatus !== 'unknown' && (window.frames[appID].getLoggedStatus() != 1))
    {
        if (window.frames[appID].login)
        {
            srvcTok = getSvcToken(appID);
            if(null == srvcTok || "" == srvcTok)
			{
                alert(rb.ERR_GET_SRVC_TOK+appID);
                return;
            }
            if(window.frames[appID].isValidCal !== 'undefined' && window.frames[appID].isValidCal !== 'unknown' && 
				window.frames[appID].isValidCal(calendarFormat))
	    			appInputArr['calendarFormat'] = calendarFormat;
	    	else{
	    		appInputArr['calendarFormat'] = GREG_CAL;
	    	}		
	    	//Set the timezone in appInputArr to the global timezone in all applications
	    	appInputArr['timezoneName'] = defTimeZone;
	    	appInputArr['timezoneOffset'] = tzArray[defTimeZone];
        	window.frames[appID].login(srvcTok, userID, sess, langCode,currEntity, appInputArr);
        	return true;
        }
    }
    return false;
}
//invoke the given method is the specified application
function invokeApplicationMethod(appID, methodName, dataStr)
{
    var count = 0;
    var tempResArr = new Array(0);
    var resList = entityResArray[currEntity];
    
    for(var i = 0; i < resList.length; i++)
    {
        if(resList[i].indexOf(appID) != -1)
        {
            tempResArr[count++] = resList[i];
        }
    }
    if(tempResArr.length == 0) {
        alert(SSOJSResourceBundle.ERR_NO_RES);
        return "";
    }
    var selectedResource = tempResArr[0];

    if(tempResArr.length > 0){
        for(var i = 0; i < tempResArr.length; i++)
        {
            if(isUserLoggedInToApp(tempResArr[i])) {
                return invokeMethodInFrame(tempResArr[i],methodName,dataStr);
            }
        }
    }
    
    startAppFrame(selectedResource, resourceArr[selectedResource].url);
    var doc = window.parent.appletFrame.document;
    if(doc.ClientApp.startApp(selectedResource,40) == true)
	{    	
        return invokeMethodInFrame(selectedResource, methodName, dataStr);
    }
    return "";
}        
        
function invokeMethodInFrame(appID, methodName, dataStr)
{
    try{
        return window.frames[appID].eval(''+methodName+'("'+dataStr+'")');
    }
    catch(e){
        return "";
    }
}

function startAppFrame(appID, startURL)
{
	
    var divs = cbeGetElementsByTagName('DIV');
    if(divs[appID] && divs[appID].innerHTML == "&nbsp;") {
        divs[appID].innerHTML = "<iframe name='"+ appID + "' src='"+ startURL +"' width=100% height=100%></iframe>";
    }
    return;
}
function setEntityInfo(entityArr, entityResArr , entityResRef)
{
	entityArray = entityArr;
	entityResArray = entityResArr;
	entityResRefArray = entityResRef;
}

function setEntityDefResMap(entityDefResArray)
{
	entityDefResMap = entityDefResArray;
}

function setDefaultUserAttributes(strTimeZoneName, tzOffsetVal, defaultCalendar, defCalDesc, entityID, tfEnabled, isGlblAdm)
{
	//set the global timezone to the default user time zone
	defTimeZone = strTimeZoneName;
	//store the previous desktop timezone
	prevDeskTopTimeZone = defTimeZone;
	tzOffset = tzOffsetVal;
	//Set user's default calendar value in global calendar to start with
	calendarFormat = defaultCalendar;
	calDesc = defCalDesc;
	homeEntity = entityID;
	currEntity = entityID;
	isTwoFactorAuthReq = tfEnabled;
	isGlobalAdmin = isGlblAdm;
}

function setAppInputArr()
{
	
	appInputArr['homeEntity'] = homeEntity;
	appInputArr['homeEntityAlias'] = entityArr[homeEntity];
	appInputArr['contextEntity'] = currEntity;
	appInputArr['contextEntityAlias'] = entityArr[currEntity];
	appInputArr['timezoneName'] = defTimeZone;
	appInputArr['timezoneOffset'] = tzOffset;
	appInputArr['calendarFormat'] = calendarFormat;
	appInputArr['isGlobalAdmin'] = isGlobalAdmin;
    if(resourceArr['SSOAdmin'])
        appInputArr['isSSOAdmin'] = 'Y';
    else
        appInputArr['isSSOAdmin'] = 'N';
}

function getTwoFactorAuthReq()
{
	return isTwoFactorAuthReq;
}

//Function to select a particular value from a drop down
function setSelectedValue(selectFld, selectValue){
	
	if (selectFld == "appSelect")
		selectedResID = selectValue;
	else if (selectFld == "calSelect")
		calendarFormat = selectValue;
	for(i = 0; i < document.dskAppForm.elements[selectFld].options.length ; i++){

		if(document.dskAppForm.elements[selectFld].options[i].value == selectValue){
			document.dskAppForm.elements[selectFld].options[i].selected = true;
		}
	}
}

//Function to return the client IP as fetched by applet
function getClientIP()
{
	var appletObj = window.parent.appletFrame.document.ClientApp;
	var clientIP = appletObj.getClientIP();
	return clientIP;
}

//Function to change the login, logout times displayed on desktop
//on timezone switch
function changeLoginInformation()
{
	var loginTimeSpan = "";
	var logoutTimeSpan = "";
	var failedLoginTimeSpan = "";
	//If Login Data exists , span is modified
	if(document.getElementById('loginTimeSpan') && (loginTimeSpan = 
		document.getElementById('loginTimeSpan').innerHTML) != "") {
			document.getElementById('loginTimeSpan').innerHTML = 
				window.parent.appletFrame.document.ClientApp.getNewTimeString
					(tzArray[prevDeskTopTimeZone],tzOffset,loginTimeSpan);
	}
	//If logout data exists , span is modified
	if(document.getElementById('logoutTimeSpan') && (logoutTimeSpan = 
		document.getElementById('logoutTimeSpan').innerHTML) != "") {
			document.getElementById('logoutTimeSpan').innerHTML = 
				window.parent.appletFrame.document.ClientApp.getNewTimeString
					(tzArray[prevDeskTopTimeZone],tzOffset,logoutTimeSpan);	
	}
	//If previous failed login information exists , span is modified
	if(document.getElementById('failedLoginTimeSpan') && 
		(failedLoginTimeSpan = document.getElementById('failedLoginTimeSpan')
			.innerHTML) != "") {
				document.getElementById('failedLoginTimeSpan').innerHTML = 
					window.parent.appletFrame.document.ClientApp.getNewTimeString
						(tzArray[prevDeskTopTimeZone],tzOffset,failedLoginTimeSpan);	
	}
}

//Function implemented to change the currently selected timezone
function changeTimeZone()
{
	var url='SSODeskTopServlet?SSO_COMMAND=tzList';
	openModalWindow(url, 'tzList');
	if((modal_dlg_ret == undefined) || (defTimeZone == modal_dlg_ret[0])){
		 return;         
	}
	var tzArr = modal_dlg_ret;
	if(confirm(rb.CONFIRM_TZ_CHG_MSG)) {
		//Retrieve the currently selected timezone
		defTimeZone = tzArr[0];
		tzArray[defTimeZone] = tzArr[1];
        tzArray[defTimeZone+"Desc"]=tzArr[2];
		if(document.getElementById('TZSpan')){
			document.getElementById('TZSpan').innerHTML = defTimeZone;
		}
		document.images['TZDetails'].alt=rb.SSO_CHG_LBL + tzArray[defTimeZone+"Desc"];
		document.images['TZDetails'].title=rb.SSO_CHG_LBL + tzArray[defTimeZone+"Desc"];
		tzOffset = tzArray[defTimeZone];
		
		//switch timezones in all logged in applications	
		currentResList = entityResRefArray[currEntity];
		for(i = 0;  i < currentResList.length; i++){
			app = currentResList[i];
			if(isUserLoggedInToApp(app)){
				window.setTimeout("switchTZInApp('"+app+"')",100);
			}
		}
		//if logged into any application call refreshScreen() of that application
		if(selectedResID != 'none')
		{
			if(typeof window.frames[selectedResID].refreshScreen !== 'undefined' && 
								typeof window.frames[selectedResID].refreshScreen !== 'unknown') 
				window.setTimeout("window.frames['"+selectedResID+"'].refreshScreen()",100);						
		}
		else
		{
			//if on desktop change the login information 
			//to the currently selected timezone
			changeLoginInformation();
			prevDeskTopTimeZone = defTimeZone;
		}
		prevEventDate = new Date();
	} //End If - Confirm switch
}

//Function to switch timezones in individual applications
function switchTZInApp(appID)
{	

	if(!window.frames[appID].switchTimeZone) {
		return;	
	}
	window.parent.appletFrame.document.ClientApp.
		logTime(appID, "switchTimeZone", "Enter switchTimeZone");
	
	try{
		window.frames[appID].switchTimeZone(defTimeZone,tzOffset);
		window.parent.appletFrame.document.ClientApp.
			logTime(appID, "switchTimeZone", "Exit switchTimeZone");
	}
	catch(e){
		window.parent.appletFrame.document.ClientApp.
			logTime(appID, "switchTimeZone", "Exception in switchTimeZone");
	}
	return;
}

function getSvcToken(appID)
{
	var appEntityID = currEntity;

	if(arguments.length == 2)
	{
		appEntityID = arguments[1];
	}
	return window.parent.appletFrame.document.ClientApp.getServiceToken(sess, appID, appEntityID);
}

function getResDelSvcTokens(appIDList, delUser, resetDel, entityID)
{
	return window.parent.appletFrame.document.ClientApp.getResDelServiceTokens(resetDel, delUser, sess, appIDList, entityID);
}

var cdBaseURL = "SSOServlet";
function setCodeBase(codeBaseURL)
{           
     var test = codeBaseURL;
     if(test.indexOf("SSOServlet") != -1)
          cdBaseURL = codeBaseURL.substr(0,test.indexOf("SSOServlet"))+cdBaseURL;
            
}

function openModalWindow(sURL, name) {
	if("Microsoft Internet Explorer" == browser_name) {
	     	  modal_dlg_ret = window.showModalDialog(sURL, name, "dialogWidth:40;dialogHeight:24;status=no;toolbar=no;menubar=no;resizable=yes");
    	 }
   	 else {
   		  topPos = screen.availHeight/2 - 165;
   		  leftPos = screen.availWidth/2 - 310;
   	  	  modal_dlg_ret = window.showModalDialog(sURL, name, "dialogWidth: 620;dialogHeight: 330;dialogTop: "+topPos+";dialogLeft: "+leftPos+";status: no;toolbar: no;menubar: no;resizable: yes");
       	}
}

function refreshTicker()
{
	if( tik_enable == 'Y')
		showTicker();
}
function getAdminURL()
{
	return adminURL;
}
function trimString(str) {
    if(null == str) return "";
    return str.replace(/^\s*/, "").replace(/\s*$/, "");
}

function resetTimer()
{
	prevEventDate = new Date();
	startTimerInApps();
}

function startTimerInApps()
{
	var noOfFrames = window.frames.length;

	for(var i = 0; i < noOfFrames; i++)
	{
		currentFrame = window.frames[i];
		try{
			if(currentFrame.getLoggedStatus && 
				currentFrame.getLoggedStatus() == 1)
			{
				if(currentFrame.startIdleCheckTimer) 
					currentFrame.startIdleCheckTimer();
			}
		}
		catch(ex) { continue; }
	}
}

// Starting User Reset/Delete

var httpReqArr = new Array();
var respArr = new Array();
var resList = new Array();

//delete session for user given from applications.
function deleteUserSessionFromApps(deluser, resArray, homeEntResArray, ssoData, isRetry, retryApp)
{
    if(!isRetry)
    {
        httpReqArr = new Array(); // multiple user reset
        respArr = new Array();
    }

    var appURL = "";
	var hEntity = "";
	var ssoApps = new Array("SSOAdmin");

    if(isGlobalAdmin == "Y")
	{
        resList.pushAll(resArray, ssoApps);
	}
	else
    {
		resList.pushAll(homeEntResArray, ssoApps);
		hEntity = homeEntity;
    }
	
	var allSvcTok = null;
    var svcToks = new Array();
	var data = null;
	var appIDList = "";
    if(!isRetry)
    {
        for(var i = 0; i < resList.length; i++)
        {
            appID = resList[i];

            if("" == appIDList)
                appIDList = resList[i];
            else
                appIDList = appIDList + "," + resList[i];
        }
    }
    else
    {
        appIDList = retryApp;
    }
		
	if(appIDList != "" && resList.length > 0)
    {
        allSvcTok = getResDelSvcTokens(appIDList, deluser, "R", hEntity);
   	
        if(null == allSvcTok || "" == allSvcTok)
        {
            var errMsg = window.parent.appletFrame.document.ClientApp.getErrorMessage();
            if(null == errMsg || "" == errMsg)
            {
                errMsg = rb.ERR_SRVC_TOK_RETRIEVAL + " " + delUser;
            }
            alert(errMsg);
            return false;
        }

        var retSvcToks = parseSvcTok(allSvcTok);
	
        svcToks = retSvcToks[0];
        errors = retSvcToks[1];
    }

    if(resList.indexOf("SSO") == -1)
	{
		resList.push("SSO");
	}
    
    for(var i = 0; i < resList.length; i++)
    {
		appID = resList[i];

        if(!isRetry || appID == retryApp)
		{
            if(appID != "SSO")
            {
                svcTok = svcToks[appID];

                if((null == svcTok) || ("" == svcTok))
                {
                    respArr[appID] = new ajaxResObj(deluser,appID,errors[resList[i]], "",-1, 0);
                    continue;
                }

                data = "&CALLTYPE=R&USER_ID="+deluser+"&SERVICE_TOKEN="+ svcTok+
                        "&SESSION_ID="+sess+"&LANG_CODE="+langCode+
                            "&LOGGED_IN_USER_ID="+userID;
				appURL = resourceArr[appID].url
            }
            else
            {
                data = ssoData;
                appURL = getAdminURL();
            }

            window.parent.appletFrame.document.ClientApp.logTime(appID,
                "deleteUserSessionFromApps","Call Application Start URL");

            callResURL(i, appID, appURL, data, deluser);
            if(appID == retryApp)   break;
        }
    }   
    window.parent.appletFrame.document.ClientApp.logTime("SSO",
			"deleteUserSessionFromApps","Completed");
    
    return true;
}

function parseSvcTok(allServiceTokens)
{
	var serviceToks = new Array();
	var errorCodes = new Array();
	var data = new Array();
	data = allServiceTokens.split("&");
	for(var i = 0 ; i < data.length ; i++)
	{
		if(data[i].indexOf("ERROR_CODE") == -1)
		{
			nameValue = data[i].split("=");
			serviceToks[nameValue[0]] = nameValue[1];
		}
		else
		{
			nameValue = data[i].split("=");
			resName = nameValue[0].substring(0, nameValue[0].indexOf("ERROR_CODE")-1);
			errorCodes[resName] = nameValue[1]; 
		}
	}

    var retArr = new Array (serviceToks, errorCodes);
	return retArr;
}

function callResURL(index,appID, url,data,user)
{
	var errorData = new Array();
	var appResponse = "";

	if("Microsoft Internet Explorer" == browser_name)
	{	// IE
		if (window.ActiveXObject) { 
			try {
				httpReqArr[appID] = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) 
			{
				try {
					httpReqArr[appID] = new ActiveXObject("Microsoft.XMLHTTP");	
				} catch (e) {	
					window.parent.appletFrame.document.ClientApp.logTime("appID",
						"callResURL", "Exception in accessing "+appID);
				}
			}
		}
	}
	else
	{   // Mozilla, Safari,...
		if (window.XMLHttpRequest)
		{ 
			httpReqArr[appID] = new XMLHttpRequest();
			if (httpReqArr[appID].overrideMimeType) {
				httpReqArr[appID].overrideMimeType('text/xml');
			}
		} 
	}
	
	if (!httpReqArr[appID]) {
		window.parent.appletFrame.document.ClientApp.logTime(appID, "callResURL",
			"Could not process call for "+appID);	
		return false;
	}
	httpReqArr[appID].onreadystatechange = function() {	
		
		if (httpReqArr[appID].readyState == 4) {			
			if (httpReqArr[appID].status == 200) {
				window.parent.appletFrame.document.ClientApp.logTime(appID, "callResURL",
					"Response received");	
				appResponse = httpReqArr[appID].responseText;
				if(null == appResponse || "" == appResponse || 
				  (appResponse.indexOf("ERROR_CODE") == -1 && appResponse.indexOf("ERROR_MSG") == -1))
				{
					respArr[appID] = new ajaxResObj(user,appID, 218, "",httpReqArr[appID].status,0);
					return;
				}
				errorDetails = appResponse.substr(appResponse.indexOf("ERROR_"));
				errorData = errorDetails.split("&");
				//errorData = appResponse.split("&");
				if(!errorData)
                {
                    respArr[appID] = new ajaxResObj(user,appID, 218, "",httpReqArr[appID].status,0);
                    return;
                }
                else if(errorData.length > 1)
				{
					errData = errorData[0].split("=")[0];
					if(errData.indexOf("ERROR_CODE") == -1)
					{
						errCode = errorData[1].split("=")[1];
						errMsg = errorData[0].split("=")[1];
					}
					else
					{
						errCode = errorData[0].split("=")[1];
						errMsg = errorData[1].split("=")[1];
					}
				}
				else
				{
					errMsg = "";
					errCode = errorData[0].split("=")[1]; 
				}

                window.parent.appletFrame.document.ClientApp.logTime(appID, "callResURL",
					"Response received : Error Code = ["+errCode+"] : Error Message = ["+errMsg+"]");

				if(0 == errCode)
                {
					respArr[appID] = new ajaxResObj(user, appID, errCode, "", -1, 0);
                }
				else {
					if(0 != errMsg.length)
					{
						errMsg = replaceAll(errMsg," ","^^");
					}
					respArr[appID] = new ajaxResObj(user, appID, errCode, errMsg, -1,1);
				}
			} else {
				window.parent.appletFrame.document.ClientApp.logTime("appID",
					"callResURL","Error in getting response: "+httpReqArr[appID].status);	
				respArr[appID] = new ajaxResObj(user,appID, 218, "",httpReqArr[appID].status,0);
				
			}
		}
		else respArr[appID] = new ajaxResObj(user, appID, -2, "", -1,1);
	}
	
    // To avoid response caching
    var currDate = new Date();
    var currTime = Date.parse(currDate.toString());
    data += "&REQ_TIME_STAMP="+currTime;
    
    try {
	    if(url.indexOf("?") == -1)
	    {
			httpReqArr[appID].open('GET', url+"?"+data,true);
	    }
	    else 
	    {
			httpReqArr[appID].open('GET', url+"&"+data,true);
	    }
    	    httpReqArr[appID].send(null);	
    }
    catch(e) 
    {
    	respArr[appID] = new ajaxResObj(user,appID, -1, rb.ERR_APP_ACCESS+appID+" : "+e.message,-1,0);
    	window.parent.appletFrame.document.ClientApp.logTime(appID, "callResURL", rb.ERR_APP_ACCESS + ": Error Code = [-1] : Error Message = ["+e.message+"]");
    }
}

function ajaxResObj(user,resID,errCode,errMsg,status,ssoError)
{
	this.userID = user;
	this.appID = resID;
	this.errorCode = errCode;
	this.errorMsg = errMsg;
	this.statusCode = status;
	this.ssoError = ssoError;
}
function getAjaxResponseArr()
{	
	return respArr;
}

function getResListForUser()
{
    return resList;
}

function getSuccessFailureResForUser(user)
{
    var successArray = new Array();
    var failedArray = new Array();

    if(null != user && "undefined" != user && "" != user && undefined != user)
    {
        for(var l = 0 ; l < resList.length ; l++)
        {
            if(respArr[resList[l]].userID == user)
            {
                if(respArr[resList[l]].errorCode == 0)
                {
                    successArray.push(resList[l]);
                }
                else
                {
                    failedArray.push(resList[l]);
                }
            }
        }
    }
    var retArray = new Array(successArray, failedArray);
    return retArray;
}

function clearAjaxResponseArr()
{
    httpReqArr = new Array();
    respArr = new Array();
    resList = new Array();
}

//delete an user from all applications/resources
function deleteUserFromApps(deluser, resArray, homeEntResArray, ssoData, isRetry, retryApp)
{
    if(!isRetry)
    {
        httpReqArr = new Array();
        respArr = new Array();
    }

    var appURL = "";
	var hEntity = "";
    var ssoApps = new Array("SSOAdmin");
    
    if( resArray != undefined && null != resArray && resArray.length > 0)
    {
        for(var i = 0 ; i < resArray.length ; i++)
        {
            if(resourceArr[resArray[i]] && "off" == resourceArr[resArray[i]].hasProfile)
            {
                ssoApps.push(resArray[i]);               
            }
        }
    }
    else
    {
    	if(null != homeEntResArray){
    		for(var i = 0 ; i < homeEntResArray.length ; i++)
            {
                if(resourceArr[homeEntResArray[i]] && "off" == resourceArr[homeEntResArray[i]].hasProfile)
                {
                    ssoApps.push(homeEntResArray[i]);
                }
            }
    	}
    }

    if(isGlobalAdmin == "Y")
	{
        resList.pushAll(resArray, ssoApps);
	}
	else
    {
		resList.pushAll(homeEntResArray, ssoApps);
		hEntity = homeEntity;
    }
    
	var allSvcTok = null;
    var svcToks = new Array();
	var data = null;
	var appIDList = "";
    
    if(!isRetry)
    {
        for(var i = 0; i < resList.length; i++)
        {
            appID = resList[i];

            if("" == appIDList)
                appIDList = resList[i];
            else
                appIDList = appIDList + "," + resList[i];
        }
    }
    else
    {
        appIDList = retryApp;
    }

	if(appIDList != "" && resList.length > 0)
    {
        allSvcTok = getResDelSvcTokens(appIDList, deluser, "D", hEntity);

        if(null == allSvcTok || "" == allSvcTok)
        {
            var errMsg = window.parent.appletFrame.document.ClientApp.getErrorMessage();
            if(null == errMsg || "" == errMsg)
            {
                errMsg = rb.ERR_SRVC_TOK_RETRIEVAL + " " + delUser;
            }
            alert(errMsg);
            return false;
        }

        var retSvcToks = parseSvcTok(allSvcTok);

        svcToks = retSvcToks[0];
        errors = retSvcToks[1];
    }

    if(resList.indexOf("SSO") == -1) 
	{
		resList.push("SSO");
	}

    for(var i = 0; i < resList.length; i++)
    {
		appID = resList[i];

        if(!isRetry || appID == retryApp)
		{
            if(appID != "SSO")
            {
                svcTok = svcToks[appID];

                if((null == svcTok) || ("" == svcTok))
                {
                    respArr[appID] = new ajaxResObj(deluser,appID,errors[resList[i]], "",-1, 0);
                    continue;
                }

                appURL = resourceArr[appID].url;

                data = "&CALLTYPE=D&USER_ID="+deluser+"&SERVICE_TOKEN="+ svcTok+
                            "&SESSION_ID="+sess+"&LANG_CODE="+langCode+
                                "&LOGGED_IN_USER_ID="+userID;
            }
            else
            {
                appURL = getAdminURL();
                data = ssoData;
            }

            window.parent.appletFrame.document.ClientApp.logTime(appID,
                "deleteUserFromApps","Call Application Start URL");
            callResURL(i, appID, appURL, data, deluser);
            if(appID == retryApp)   break;
        }
    }
    window.parent.appletFrame.document.ClientApp.logTime("SSO",
			"deleteUserFromApps","Completed");
    return true;
}

function replaceAll( str, from, to )
{
     var dayIndex = str.indexOf( from );
     while ( dayIndex > -1 ) {
         str = str.replace( from, to );
         dayIndex = str.indexOf( from );
     }
     return str;
}

function hasResProfile(resID)
{
    if(resourceArr[resID])
    {
        if(resourceArr[resID].hasProfile)
        {
            if(resourceArr[resID].hasProfile == "on")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return true;
    }
}

function chkIfSSOAdmin()
{
    if(resourceArr['SSOAdmin'])
        return true;
    return false;
}

//brings up modal dialog on click of changeCreds icon 
function openChangeCredsWindow(reqString,argArr) {
	var dialogProps = 'dialogWidth:800px;dialogHeight:600px;status:No;help:No;resizable:No;scroll:Yes';
	stopTimerInApps();
	// To avoid response caching
    var currDate = new Date();
    var currTime = Date.parse(currDate.toString());
	reqString+="&REQ_TIME_STAMP="+currTime;
	window.showModalDialog(reqString,argArr,dialogProps);
	resetTimer();
}

function resetTimer()
{
	prevEventDate = new Date();
	startTimerInApps();
}

function stopTimerInApps()
{
	var noOfFrames = window.frames.length;

	for(var i = 0; i < noOfFrames; i++)
	{
		currentFrame = window.frames[i];
		try{
			if(currentFrame.getLoggedStatus && 
				currentFrame.getLoggedStatus() == 1)
			{
				if(currentFrame.stopIdleCheckTimer) 
					currentFrame.stopIdleCheckTimer();
			}
		}
		catch(ex) { continue; }
	}
}

function startTimerInApps()
{
	var noOfFrames = window.frames.length;

	for(var i = 0; i < noOfFrames; i++)
	{
		currentFrame = window.frames[i];
		try{
			if(currentFrame.getLoggedStatus && 
				currentFrame.getLoggedStatus() == 1)
			{
				if(currentFrame.startIdleCheckTimer) 
					currentFrame.startIdleCheckTimer();
			}
		}
		catch(ex) { continue; }
	}
}
