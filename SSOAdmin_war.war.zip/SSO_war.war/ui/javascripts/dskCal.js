//Function to change the selected calendar
function changeCalendar()
{
    if(confirm(rb.CONFIRM_CAL_CHG_MSG)) { //Ask user confirmation

	var calIndex = document.dskAppForm.calSelect.selectedIndex;
	var selectedCal = document.dskAppForm.calSelect.options[calIndex].value;
	var selCalDesc = document.dskAppForm.calSelect.options[calIndex].innerHTML;
	
	//If some resource is already selected perform switch calendar
	if (selectedResID != 'none') 
	{ 	
		if(isUserLoggedInToApp(selectedResID)){
			resourceArr[selectedResID].currCal = GREG_CAL;
			resourceArr[selectedResID].currCalDesc = GREG_CAL_DES;
			var switchCalArr = null;				
			//if the selected application supports switch calendar and if it
			//supports the selected calendar type perform switch
			if(window.frames[selectedResID].switchCalendar)
				switchCalArr = window.frames[selectedResID].switchCalendar(selectedCal);
			if(switchCalArr == null ||  
					(switchCalArr[0] == false && 
				(!switchCalArr[1] || switchCalArr[1] == null || 
				 switchCalArr[1] == ""))){
				alert(resourceArr[selectedResID].resDisplayText+
						rb.ERR_CAL_NOT_SUPPORTED_PREFIX+
						selCalDesc+
						rb.ERR_CAL_NOT_SUPPORTED_SUFFIX);

				setSelectedValue("calSelect", calendarFormat);
				return;
			}

			if(switchCalArr[0] == true)
			{
				resourceArr[selectedResID].currCal = selectedCal; 
				resourceArr[selectedResID].currCalDesc = selCalDesc;
				calDesc = selCalDesc;
				calendarFormat = selectedCal;
				
				//Check whether other logged in applications support the
				//selected calendar type. If yes, then switch their calendar type
				currentResList = entityResRefArray[currEntity];
				for(i = 0;  i < currentResList.length; i++){
					otherApp = currentResList[i];		
					if(isUserLoggedInToApp(otherApp) && otherApp != selectedResID){
						window.setTimeout("switchCalendarInApp('"+otherApp+"', '"+calendarFormat+"', '"+calDesc + "')",100);
					}
				}

				if(window.frames[selectedResID].refreshScreen)
					window.setTimeout("window.frames['"+selectedResID+"'].refreshScreen()",100);				
			}
			else 
			{
				alert(resourceArr[selectedResID].resDisplayText+":"+switchCalArr[1]);
			}
		} //End If - isUserLoggedIn
	} //End If - selectedResID check
	else{
		calendarFormat = selectedCal;
		calDesc = selCalDesc;
	    }
	prevEventDate = new Date();
     } //End If - Confirm switch
		
     //Set the calendar dropdown according to the supported calendar value of
     //the currently selected application
     setSelectedValue("calSelect", calendarFormat);
}

function switchCalendarInApp(appID, cal , calDesc)
{	//Set the app currCal to GREG_CAL, it's re-assigned 
	//only if application supports the switched one. 
	resourceArr[appID].currCal = GREG_CAL; 
	if(!window.frames[appID].switchCalendar) {
		return;	//GREG_CAL already set
	}
	window.parent.appletFrame.document.ClientApp.logTime(appID, "switchCalendar", "Enter switchCalendar");
	var retVal = window.frames[appID].switchCalendar(cal);
	try{
		if(retVal[0] == true){
			resourceArr[appID].currCal = cal;
			resourceArr[appID].currCalDesc = calDesc;
			window.parent.appletFrame.document.ClientApp.logTime(appID, "switchCalendar", "Exit switchCalendar");
		}
		else{
			if(retVal[1] && retVal[1] != null && retVal[1] != "")
				alert(resourceArr[appID].resDisplayText+":"+retVal[1]);
			else
				alert(resourceArr[selectedResID].resDisplayText+
							rb.ERR_CAL_NOT_SUPPORTED_PREFIX+
							cal+
							rb.ERR_CAL_NOT_SUPPORTED_SUFFIX);
		}
		window.parent.appletFrame.document.ClientApp.logTime(appID, "switchCalendar", "Exit switchCalendar");
		//GREG_CAL already set
	}
	catch(e){
		window.parent.appletFrame.document.ClientApp.logTime(appID, "switchCalendar", "Exception in switchCalendar");
		//GREG_CAL already set
	}
	return;
}