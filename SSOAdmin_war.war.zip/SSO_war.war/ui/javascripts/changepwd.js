var resBundle;
var oldPass = "";
var newPass = "";
var oldPin = "";
var newPin = "";

function setJSResourceBundle(SSOJSResourceBundle)
{
	resBundle = SSOJSResourceBundle;
}

function showDetailsDiv()
{
	var divs = cbeGetElementsByTagName("DIV");
	if(document.changeCredsForm.functionSelect.value == 'M'){
		disableCriteriaSection();
		divs["pwdDiv"].cbe.hide();
		divs["bothDiv"].cbe.hide();
		divs["mpinDiv"].cbe.show();
		document.changeCredsForm.mPinOld.focus();
	}
	else if(document.changeCredsForm.functionSelect.value == 'P'){
		disableCriteriaSection();
		divs["mpinDiv"].cbe.hide();
		divs["bothDiv"].cbe.hide();
		divs["pwdDiv"].cbe.show();
		document.changeCredsForm.oldPass.focus();
	}
	else if(document.changeCredsForm.functionSelect.value == 'B'){
		disableCriteriaSection();
		divs["mpinDiv"].cbe.hide();
		divs["pwdDiv"].cbe.hide();
		divs["bothDiv"].cbe.show();
		document.changeCredsForm.oldPassBoth.focus();
	}
}

function clearDivFields(){

	if(document.changeCredsForm.functionSelect.value == 'M'){
		document.changeCredsForm.mPinOld.value = "";
		document.changeCredsForm.mPinNew.value = "";
		document.changeCredsForm.confirmPin.value = "";
		document.changeCredsForm.mPinOld.focus();
	}
	else if(document.changeCredsForm.functionSelect.value == 'P'){
		document.changeCredsForm.oldPass.value = "";
		document.changeCredsForm.newPass.value = "";
		document.changeCredsForm.confirmPass.value = "";
		document.changeCredsForm.oldPass.focus();
	}
	else if(document.changeCredsForm.functionSelect.value == 'B'){
		document.changeCredsForm.mPinOldBoth.value = "";
		document.changeCredsForm.mPinNewBoth.value = "";
		document.changeCredsForm.confirmPinBoth.value = "";
		document.changeCredsForm.oldPassBoth.value = "";
		document.changeCredsForm.newPassBoth.value = "";
		document.changeCredsForm.confirmPassBoth.value = "";
		document.changeCredsForm.oldPassBoth.focus();
	}
	document.changeCredsForm.REQ_TYPE.value="";
}

function setFocusOnSkip()
{
	document.getElementById("header_link").focus();
}

function verifyMPinDetails()
{
	oldPin = document.changeCredsForm.mPinOld.value;
	newPin = document.changeCredsForm.mPinNew.value;
	var confirmPin = document.changeCredsForm.confirmPin.value;

	if(confirmPin != newPin)
	{
		alert(resBundle.ERR_MISMATCH_PIN);
		return false;
	}
	else if(newPin == oldPin)
	{
		alert(resBundle.ERR_GIVE_DIFF_PIN);
		return false;
	}
	document.changeCredsForm.REQ_TYPE.value="TWOFACTOR_CHANGE_MPIN";

}

function verifyPwdDetails()
{
	oldPass = document.changeCredsForm.oldPass.value;
	newPass = document.changeCredsForm.newPass.value;
	var confirmPass = document.changeCredsForm.confirmPass.value;
	
	if(confirmPass != newPass)
	{
		alert(resBundle.ERR_MISMATCH_PASSWORD);
		return false;
	}
	else if(newPass == oldPass)
	{
		alert(resBundle.ERR_GIVE_DIFF_PASSWORD);
		return false;
	}
	document.changeCredsForm.REQ_TYPE.value="CHANGE_PWD";
}

function verifyBothPwdAndMPin()
{
	oldPass = document.changeCredsForm.oldPassBoth.value;
	newPass = document.changeCredsForm.newPassBoth.value;
	var confirmPass = document.changeCredsForm.confirmPassBoth.value;
	oldPin = document.changeCredsForm.mPinOldBoth.value;
	newPin = document.changeCredsForm.mPinNewBoth.value;
	confirmPin = document.changeCredsForm.confirmPinBoth.value;
	
	if(confirmPass != newPass)
	{
		alert(resBundle.ERR_MISMATCH_PASSWORD);
		return false;
	}
	else if(newPass == oldPass)
	{
		alert(resBundle.ERR_GIVE_DIFF_PASSWORD);
		return false;
	}

	else if(confirmPin != newPin)
	{
		alert(resBundle.ERR_MISMATCH_PIN);
		return false;
	}
	else if(newPin == oldPin)
	{
		alert(resBundle.ERR_GIVE_DIFF_PIN);
		return false;
	}
	
	document.changeCredsForm.REQ_TYPE.value="CHANGE_PWD_AND_MPIN";
}

function doCancel(type)
{
	
	document.changeCredsForm.functionSelect.disabled = false;
	document.changeCredsForm.goBtn.disabled = false;
	document.changeCredsForm.clearBtn.disabled = false;
	
	if(type == "mPin"){
		document.changeCredsForm.mPinOld.value = "";
		document.changeCredsForm.mPinNew.value = "";
		document.changeCredsForm.confirmPin.value = "";
		
	}else if(type == "pwd"){
		document.changeCredsForm.oldPass.value = "";
		document.changeCredsForm.newPass.value = "";
		document.changeCredsForm.confirmPass.value = "";
	}else{
		document.changeCredsForm.mPinOldBoth.value = "";
		document.changeCredsForm.mPinNewBoth.value = "";
		document.changeCredsForm.confirmPinBoth.value = "";
		document.changeCredsForm.oldPassBoth.value = "";
		document.changeCredsForm.newPassBoth.value = "";
		document.changeCredsForm.confirmPassBoth.value = "";
	}
	clearDropDown();
}

function showHelp()
{
	var divs = cbeGetElementsByTagName("DIV");
	var helpFile = eval("SSOJSResourceBundle.CHG_CRED_HELP");
	if(divs["pwdDiv"].cbe.visibility() == 1)
		helpFile = eval("SSOJSResourceBundle.CHG_PWD_HELP")
	else if(divs["bothDiv"].cbe.visibility() == 1)
		helpFile = eval("SSOJSResourceBundle.BOTH_PWD_MPIN_HELP")
	else if(divs["mpinDiv"].cbe.visibility() == 1)
		helpFile = eval("SSOJSResourceBundle.CHG_MPIN_HELP")
	window.open(helpFile,'ssoHelpFrame');
	return;
}

function clearDropDown()
{
	document.changeCredsForm.functionSelect.options[0].selected = true;
	var divs = cbeGetElementsByTagName("DIV");
	divs["pwdDiv"].cbe.hide();
	divs["bothDiv"].cbe.hide();
	divs["mpinDiv"].cbe.hide();
}

function validateDetails(type){
	if(type == "mPin"){
		if(replaceAll(document.changeCredsForm.mPinOld.value," ","") == ""){
			alert(SSOJSResourceBundle.ERR_OLD_PIN);
			document.changeCredsForm.mPinOld.value = "";
			document.changeCredsForm.mPinOld.focus();
			return false;
		}else if(replaceAll(document.changeCredsForm.mPinNew.value," ","") == ""){
			alert(SSOJSResourceBundle.ERR_NEW_PIN);
			document.changeCredsForm.mPinNew.value = "";
			document.changeCredsForm.mPinNew.focus();
			return false;
		}else if(replaceAll(document.changeCredsForm.confirmPin.value," ","") == ""){
			alert(SSOJSResourceBundle.ERR_CONFIRM_PIN);
			document.changeCredsForm.confirmPin.value = "";
			document.changeCredsForm.confirmPin.focus();
			return false;
		}
		verifyMPinDetails();
	}else if(type == "pwd"){
		if(replaceAll(document.changeCredsForm.oldPass.value," ","") == ""){
			alert(SSOJSResourceBundle.ERR_OLD_PASSWORD);
			document.changeCredsForm.oldPass.value = "";
			document.changeCredsForm.oldPass.focus();
			return false;
		}else if(replaceAll(document.changeCredsForm.newPass.value," ","") == ""){
			alert(SSOJSResourceBundle.ERR_NEW_PASSWORD);
			document.changeCredsForm.newPass.value = "";
			document.changeCredsForm.newPass.focus();
			return false;
		}else if(replaceAll(document.changeCredsForm.confirmPass.value," ","") == ""){
			alert(SSOJSResourceBundle.ERR_CONFIRM_PASSWORD);
			document.changeCredsForm.confirmPass.value = "";
			document.changeCredsForm.confirmPass.focus();
			return false;
		}
		verifyPwdDetails();
	}else{
		if(replaceAll(document.changeCredsForm.oldPassBoth.value," ","") == ""){
			alert(SSOJSResourceBundle.ERR_OLD_PASSWORD);
			document.changeCredsForm.oldPassBoth.value = "";
			document.changeCredsForm.oldPassBoth.focus();
			return false;
		}else if(replaceAll(document.changeCredsForm.newPassBoth.value," ","") == ""){
            	alert(SSOJSResourceBundle.ERR_NEW_PASSWORD);
            	document.changeCredsForm.newPassBoth.value = "";
            	document.changeCredsForm.newPassBoth.focus();
            	return false;
        }else if(replaceAll(document.changeCredsForm.confirmPassBoth.value," ","") == ""){
			alert(SSOJSResourceBundle.ERR_CONFIRM_PASSWORD);
			document.changeCredsForm.confirmPassBoth.value = "";
			document.changeCredsForm.confirmPassBoth.focus();
			return false;
		}else if(replaceAll(document.changeCredsForm.mPinOldBoth.value," ","") == ""){
			alert(SSOJSResourceBundle.ERR_OLD_PIN);
			document.changeCredsForm.mPinOldBoth.value = "";
			document.changeCredsForm.mPinOldBoth.focus();
			return false;
		}else if(replaceAll(document.changeCredsForm.mPinNewBoth.value," ","") == ""){
				alert(SSOJSResourceBundle.ERR_NEW_PIN);
				document.changeCredsForm.mPinNewBoth.value = "";
				document.changeCredsForm.mPinNewBoth.focus();
				return false;
		}else if(replaceAll(document.changeCredsForm.confirmPinBoth.value," ","") == ""){
				alert(SSOJSResourceBundle.ERR_CONFIRM_PIN);
				document.changeCredsForm.confirmPinBoth.value = "";
				document.changeCredsForm.confirmPinBoth.focus();
				return false;
		}
		verifyBothPwdAndMPin();
	}
	doChange();
}

function replaceAll(str,src,dest){
	idx = str.indexOf(src);
	while(idx >= 0){
		str = str.replace(src,dest);
		idx = str.indexOf(src);
	}
	return str;
}

function disableCriteriaSection()
{		
	document.changeCredsForm.functionSelect.disabled = true;
	document.changeCredsForm.goBtn.disabled = true;
	document.changeCredsForm.clearBtn.disabled = true;
}

function doChange(){
	
	var reqType = document.changeCredsForm.REQ_TYPE.value;
	var alertMsg = null;
	if(reqType == "") return;
    appletObj.changeCredentials(reqType,oldPass,newPass,oldPin,newPin);
    alertMsg = appletObj.getErrorMessage();
    alert(alertMsg);
    if(appletObj.getErrorCode() == 0){
    	window.close();
    }
    clearDivFields();
}