//sso.js var
var marqueecontent='<nobr>No ticker configured</nobr>';
var marqueewidth="900px"
var marqueespeed=1
var marqueebgcolor="#DEEAF6"
//Pause marquee onMousever (0=no. 1=yes)?
var pauseit=1
marqueespeed=(document.all)? marqueespeed : Math.max(1, marqueespeed-1) //slow speed down by 1 for NS
var copyspeed=marqueespeed
var pausespeed=(pauseit==0)? copyspeed: 0
var iedom=document.all||document.getElementById
var cross_marquee, ns_marquee
var lefttime=0;
var len = parseInt(marqueewidth)+8+"px";
var http_request = false;
var counter = 0;
var url = 'ui/FinacleRSSFeed.xml';
desc ="";
var ticker_age = 30;
var tik_ref_time = 1500000;
var ticker_rb = SSOJSResourceBundle;
var tickerStatus=0;
var pauseStatus=0;
var openRSS="N";
var browser_name = navigator.appName;
var marqueehight = ("Microsoft Internet Explorer" == browser_name)? "0px" : "-6px";

function rssItem(pubDate,desc,link)
{
	this.pubDate =pubDate;
	this.desc=desc;
	this.link=link;
}

function rssFeed()
{
	this.items=new Array();
	this.getItems=rssReader;
}

function rssReader()
{
	var xmldoc = http_request.responseXML;
	var items1 = xmldoc.getElementsByTagName('item');
	if(items1){
		for(i=0;i<items1.length;i++)
		{
			try{
				pubDate =
				items1.item(i).getElementsByTagName('pubDate').item(0).firstChild.data;
			}
			catch(e){
				pubDate = new Date();
			}
			description =
			items1.item(i).getElementsByTagName('description').item(0).firstChild.data;
			link = items1.item(i).getElementsByTagName('link').item(0).firstChild.data;
			rss_feed.items[i] = new rssItem(pubDate,description,link)
		}
	}
}
function createAjaxObj() {
	http_request = false;
	desc="";
	if (window.XMLHttpRequest) { // Mozilla, Safari,...
		http_request = new XMLHttpRequest();
		if (http_request.overrideMimeType) {
			http_request.overrideMimeType('text/xml');
		}
	} else if (window.ActiveXObject) { // IE
		try {
			http_request = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try {
				http_request = new ActiveXObject("Microsoft.XMLHTTP");	
			} catch (e) {	
				alert(ticker_rb.XMLHTTP_EXCEPTION);
			}
		}
	}

	if (!http_request) {
		alert(ticker_rb.XMLHTTP_ERROR);
		return false;
	}
	var now = new Date();
	http_request.onreadystatechange = getContents;
	http_request.open('GET', url+"?currTime="+now.getTime(),true);
	//http_request.open('GET', url+"?now="+now.getTime(),true);
	http_request.send(null);
}

function getContents() {
	if (http_request.readyState == 4) {
		tickerStatus = http_request.status;
		if (http_request.status == 200) {
			if(openRSS == "Y"){
				window.open('ui/FinacleRSSFeed.xml');
				openRSS = "N";
			}
			rss_feed = new rssFeed();
			rss_feed.getItems();
			for(i=0;i<rss_feed.items.length;i++)
			{
				var pubDt = Date.parse(rss_feed.items[i].pubDate);
				if(isNaN(pubDt)){
					spldate = rss_feed.items[i].pubDate;
					lastIndex = spldate.lastIndexOf(" ")
					convDate = spldate.substr(0,lastIndex);
					pubDt=Date.parse(convDate);
				}
				curDate= new Date();
				diff=(curDate - pubDt)/(1000*60*60*24)
				if (diff < ticker_age){
					if(desc == ""){
						
						desc =desc +"<A href="+ rss_feed.items[i].link+
						" style ='text-decoration:none ' target='_blank' class='tickernavi'>"+
						rss_feed.items[i].desc+"</A> "
					}
					else{
						desc = desc +"&nbsp"+
						"<img src='ui/images/line.gif' width='1' height='12'>"+
						"&nbsp"+"<A href="+ rss_feed.items[i].link+
						" style ='text-decoration:none' target='_blank' class='tickernavi'> "+
						rss_feed.items[i].desc+"</A> ";
					}
				}
			}
			if(desc == "")
			{
				desc ="there is no new item in rss feed";
			}
			if(rss_feed.items.length>0){
			setTickerValue('<nobr>'+desc+'</nobr>');
			}
		} else {
			document.getElementById("iemarquee").innerHTML="";
			alert(ticker_rb.XML_FILE_ERROR);
		}
	}
}

function showTicker()
{
	
	var appletObj = window.parent.appletFrame.document.ClientApp;
	if(appletObj.getTickerAge() != null) 
		ticker_age = appletObj.getTickerAge();
	if(appletObj.getTikRefTime() != null)
		tik_ref_time = appletObj.getTikRefTime()*60*1000;
	createAjaxObj();
	ltime=setInterval(createAjaxObj,tik_ref_time);
}


function setTickerValue(val)
{	
	marqueecontent = val;
	if(lefttime!=0) {
			clearInterval(lefttime);
			len = cross_marquee.style.left;
	}
	populate();
	http_request.abort();
}

function populate(){	
	if (iedom){
		cross_marquee=document.getElementById? document.getElementById("iemarquee") : document.all.iemarquee
		cross_marquee.style.left = len;
		cross_marquee.innerHTML=marqueecontent;		
	}
	else if (document.layers){
		ns_marquee=document.ns_marquee.document.ns_marquee2
		ns_marquee.left=parseInt(marqueewidth)+8
		ns_marquee.document.write(marqueecontent)
		ns_marquee.document.close();		
	}	
	lefttime=setInterval("scrollmarquee()",20);
	
}

function scrollmarquee(){
	if (iedom){		
		if(parseInt(cross_marquee.style.left) > cross_marquee.offsetWidth*(-1))
			cross_marquee.style.left=parseInt(cross_marquee.style.left)-copyspeed+"px"				
		else			
			cross_marquee.style.left=parseInt(marqueewidth)+8+"px"
	}
	else if (document.layers){
		if(parseInt(cross_marquee.style.left) > cross_marquee.offsetWidth*(-1))
			ns_marquee.left-=copyspeed
		else
			ns_marquee.left=parseInt(marqueewidth)+8
	}
}

function pausePlayMarquee() {
	if (tickerStatus != 200) {
		alert(ticker_rb.XML_FILE_ERROR);
		return false;
	}
	pause_marquee=document.getElementById("marquee_pause_play");
	if(pauseStatus == 0) changeDisplay(pausespeed,"play_link","play.jpg",ticker_rb.SSO_PLAY_BTN,1);
	else changeDisplay(marqueespeed,"pause_link","pause.jpg",ticker_rb.SSO_PAUSE_BTN,0);
}

function changeDisplay(speed,linkid,image,title,status) {
	copyspeed = speed;
	pause_marquee.innerHTML = "<a href='#' id='"+linkid+"' onclick = 'pausePlayMarquee();return false;'><img src='ui/images/"+image+"' width='16' height='16' border='0' tabIndex=0 title='"+title+"'></a>"
	document.getElementById(linkid).focus();
	pauseStatus = status;
}

function openrssfeed() {
	openRSS = "Y";
	createAjaxObj();
}