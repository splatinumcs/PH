//method to check tfaData
var browser_name = navigator.appName;
var cdBaseURL = "SSOServlet";

function isValidTwoFactorAuth(appletObj, username, langCode, isAuthorizer)
{
	var twoFactorEnb;
	if(isAuthorizer == "false") {
		twoFactorEnb = appletObj.getIsTwoFactorEnabled(username);
	}
	else {
		twoFactorEnb = appletObj.getIsAuthorizerTwoFactorEnabled(username);
	}
	
	if(null == twoFactorEnb || "null" == twoFactorEnb || "" == twoFactorEnb)
		return false;
	
	if((twoFactorEnb == "Y") || (twoFactorEnb == "M") || (twoFactorEnb == "B"))
	{
		var argArr = new Array();
		argArr['appletObj'] = appletObj;
		argArr['isAuthorizer'] = isAuthorizer; 
		var tfaData='';
		var tfaDataToken='';
		if(browser_name == "Microsoft Internet Explorer") {
			tfaData = window.showModalDialog(cdBaseURL+"?CALLTYPE=GET_TWOFACTOR_AUTH_PAGE&LCLANG="+langCode+"&USER_ID="+username,argArr,"dialogWidth:626px;dialogHeight:500px;status:No;help:No;resizable:No;scroll:No");
		}
		else {
			var leftPos = screen.availWidth/2 - 313;
			var topPos = screen.availHeight/2 - 200;
			tfaData = window.showModalDialog(cdBaseURL+"?CALLTYPE=GET_TWOFACTOR_AUTH_PAGE&LCLANG="+langCode+"&USER_ID="+username,argArr,"dialogWidth:626px;dialogHeight:500px;dialogTop:"+topPos+";dialogLeft:"+leftPos+"; status:No;help:No;resizable:No;scroll:No");
		}
		
		if(tfaData.Errorcode == "01" )
		{
			alert(tfaData.Errormsg);
			return false;
		}
		else if (tfaData.Errorcode == "02")
		{
			alert(tfaData.Errormsg);
			return false;
		}
		else if (tfaData.Errorcode == null)
		{
			return false;
		}
		else
		{
		tfaDataToken = appletObj.encrypt(tfaData.Token);
		var tfaDataVerify = appletObj.checkTFAuth(username,tfaDataToken,isAuthorizer);
		if((tfaDataVerify == null) || (tfaDataVerify == "") || (tfaDataVerify != "true"))
			return false;		
	}
	}
	return true;
}


function isValidTwoFactorAuthWithWnd(wndRef, appletObj, username, langCode, isAuthorizer)
{
	var twoFactorEnb;
	if(isAuthorizer == "false") {
		twoFactorEnb = appletObj.getIsTwoFactorEnabled(username);
	}
	else {
		twoFactorEnb = appletObj.getIsAuthorizerTwoFactorEnabled(username);
	}

	if(null == twoFactorEnb || "null" == twoFactorEnb || "" == twoFactorEnb)
		return false;
	
	if((twoFactorEnb == "Y") || (twoFactorEnb == "M") || (twoFactorEnb == "B"))
	{
		var argArr = new Array();
		argArr['appletObj'] = appletObj;
		argArr['isAuthorizer'] = isAuthorizer; 
		var tfaData='';
		if(browser_name == "Microsoft Internet Explorer") {
			tfaData = wndRef.showModalDialog(cdBaseURL+"?CALLTYPE=GET_TWOFACTOR_AUTH_PAGE&LCLANG="+langCode+"&USER_ID="+username,argArr,"dialogWidth:626px;dialogHeight:500px;status:No;help:No;resizable:No;scroll:No");
		}
		else {
			var leftPos = screen.availWidth/2 - 313;
			var topPos = screen.availHeight/2 - 200;
			tfaData = window.showModalDialog(cdBaseURL+"?CALLTYPE=GET_TWOFACTOR_AUTH_PAGE&LCLANG="+langCode+"&USER_ID="+username,argArr,"dialogWidth:626px;dialogHeight:500px;dialogTop:"+topPos+";dialogLeft:"+leftPos+"; status:No;help:No;resizable:No;scroll:No");
		}
		if(tfaData == "" || tfaData == null)
			return false;
		tfaData = appletObj.encrypt(tfaData);
		var tfaDataVerify = appletObj.checkTFAuth(username,tfaData,isAuthorizer);
		if((tfaDataVerify == null) || (tfaDataVerify == "") || (tfaDataVerify != "true"))
			return false;		
	}
	return true;
}


function setCodeBase(codeBaseURL)
{           
     var test = codeBaseURL;
     if(test.indexOf("SSOServlet") != -1)
          cdBaseURL = codeBaseURL.substr(0,test.indexOf("SSOServlet"))+cdBaseURL;
            
}
