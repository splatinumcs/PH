
var SSOJSResourceBundle =
{    
    ERR_OLD_PASSWORD:		"Please enter your Old Password."
    ,ERR_NEW_PASSWORD:		"Please enter your New Password."
    ,ERR_CONFIRM_PASSWORD:	"Please confirm your password."
    ,ERR_MISMATCH_PASSWORD:	"New and confirmation passwords do not match."
    ,ERR_GIVE_DIFF_PASSWORD:	"New and Old Passwords are the same; Please give a different password."
	,ERR_OLD_PIN:               "Please enter your Old MPIN."
	,ERR_NEW_PIN:               "Please enter your New MPIN."
	,ERR_CONFIRM_PIN:           "Please confirm your MPIN."
	,ERR_MISMATCH_PIN:          "New and confirmation MPINs do not match."
	,ERR_GIVE_DIFF_PIN:         "New and Old MPINs are the same; Please give a different MPIN."
	,CHG_PWD_HELP:		"ui/help/ChangeCredentials/password.htm"
	,CHG_MPIN_HELP:		"ui/help/ChangeCredentials/change_mpin.htm"
	,BOTH_PWD_MPIN_HELP:"ui/help/ChangeCredentials/both_mpin_n_password.htm"
	,CHG_CRED_HELP:		"ui/help/ChangeCredentials/change_credential.htm"
}
