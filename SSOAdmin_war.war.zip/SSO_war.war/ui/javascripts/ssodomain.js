<!--
// Modify the below line to set the domain name of the server
dom_to_set = pageDomain;
DOM_TO_SET = dom_to_set.toUpperCase();
if(document.domain.toUpperCase().indexOf(DOM_TO_SET) < 0)
{
	alert('This page can only be accessed through a URL belonging to domain : ' + dom_to_set);
	document.location = 'about:blank';
}
else
{
	document.domain = dom_to_set;
}
//-->
