var applangcode = "en_US";

var SSOJSResourceBundle =
{   
    
    ERR_NO_USERID:		"Please enter User ID and Password."    
    ,ERR_NO_APPLET:		"Could not perform login; Applet not properly initialized."  
    ,SSO_APPLET_LOAD:		"Loading applet; Please wait..."
    ,ERR_APPLET_LOAD:		"Error loading applet"
    ,SSO_APPLET_LOAD_SUCCESS:	"Applet successfully loaded"  
    ,ERR_FORM_DATA:		"Invalid inputs."	
    ,SSO_TF_JAR_DOWNLOAD_SUCCESS:    "MobiToken jar has been successfully downloaded to your machine."
    ,SSO_TF_JAR_DOWNLOAD_CANCELLED:  "MobiToken jar download has been cancelled."
    ,SSO_TF_JAR_DOWNLOAD_FAILED:     "MobiToken jar download has failed."
    ,MSG_PASSWD_CLEAR:"Password field will be cleared.Continue?"
};
