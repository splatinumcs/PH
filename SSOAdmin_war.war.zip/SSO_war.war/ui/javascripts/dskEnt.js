var previousEntity = "";
var ERR_LCL_PARAM_NOT_FOUND = 1042;
var ERR_LCL_PARAM_IN_RANGE = 1051;
var ERR_LCL_PARAM_IN_BUFFER = 1052;
var ERR_LCL_PARAM_OUT_OF_RANGE = 1053;
var ERR_LIC_SERVER = -9999;
var currentResList = new Array();
var previousResList = new Array();

function changeEntity()
{	
	try {
		var appletObj = window.parent.appletFrame.document.ClientApp;
		if(confirm(rb.CONFIRM_ENTITY_CHG_MSG)) {
			var entIndex = document.dskAppForm.entitySelect.selectedIndex;
			var selectedEntity = document.dskAppForm.entitySelect.options[entIndex].value;
			var entitySwitchArr = new Array();
			var loggedIn = "";

			if(licChkForSwitchedEntity(selectedEntity)){
				previousEntity = currEntity;
				currEntity = selectedEntity;
				var tempResArray = entityResRefArray[selectedEntity];
				tempResArray.sort();

				if(null != tempResArray){
					var defSelect = document.dskAppForm.appSelect.options[0];
					document.dskAppForm.appSelect.options.length = 0;
					document.dskAppForm.appSelect.options.length = tempResArray.length+1;
					document.dskAppForm.appSelect.options[0] = defSelect;

					for(var i = 0; i < tempResArray.length; i++)
					{ 
						document.dskAppForm.appSelect.options[i+1] = 
							new Option(resourceArr[tempResArray[i]].resDisplayText, tempResArray[i]);
					}	
				}
				currentResList = entityResRefArray[currEntity];
				previousResList = entityResRefArray[previousEntity];

				for(var i = 0; i < previousResList.length; i++)
				{
					if(isUserLoggedInToApp(previousResList[i]))
					{
						loggedIn = true;

						for(var j = 0; j < currentResList.length; j++)
						{
							if(currentResList[j] == previousResList[i])
							{
								loggedIn = false;					
								entitySwitchArr.push(entityArray[currEntity]);
								if(window.frames[previousResList[i]].switchEntity)
								{
									try {
										window.frames[previousResList[i]].switchEntity(currEntity, entitySwitchArr);
									}
									catch(exc)
									{
										appletObj.logTime(previousResList[i], "switchEntity", exc.message);
									}
								}
								break;
							}
						}
						//If user doesn't have access to
						//logged in resource in new entity
						//log the user out from such resources
						if(loggedIn == true)
						{
							try {
								window.frames[previousResList[i]].logout('E');
							}
							catch(excp)
							{
								appletObj.logTime(previousResList[i], "logout", excp.message);
							}
						}	
					}
				}
				defApplication = entityDefResMap[currEntity];
				showDefaultApplication();
				updateForEntitySwitch();            
				setAppInputArr();
				entitySwitchArr = new Array();	

				//If timezone switched before entity switch then
				//login logout times on desktop are
				//modified as per current timezone
				if(selectedResID == 'none' && prevDeskTopTimeZone != defTimeZone)
				{
					changeLoginInformation();
					prevDeskTopTimeZone = defTimeZone;
				}	
			}
			else{ //License check failed ,revert the dropdown change 
				setSelectedValue("entitySelect", currEntity);
			}
			prevEventDate = new Date();
		}
		else{ //Revert the dropdown change 
			setSelectedValue("entitySelect", currEntity);
		}
	}
	catch(e)
	{
		appletObj.logTime("SSODeskTop", "changeEntity", e.message);
	}
}

function updateForEntitySwitch()
{
	var appletObj = window.parent.appletFrame.document.ClientApp;
	appletObj.entitySwitchUpdate(currEntity, previousEntity, getSessionID());
}

function licChkForSwitchedEntity(selEntity)
{ 
	var appletObj = window.parent.appletFrame.document.ClientApp; 
	var errorCode = appletObj.entitySwitchLicChk(selEntity);

	if(ERR_LCL_PARAM_OUT_OF_RANGE == errorCode) {
		alert(rb.ERR_LCL_PARAM_BREACH);
		return false;
	}
	else if(ERR_LIC_SERVER == errorCode) {
		alert(rb.ERR_LIC_SERVER);
		return false;
	}
	else if(ERR_LCL_PARAM_IN_RANGE == errorCode || 
			ERR_LCL_PARAM_IN_BUFFER == errorCode ||
			ERR_LCL_PARAM_NOT_FOUND == errorCode) {
	        return true;
	}
	else {
		alert(rb.ERR_SSO_FAILURE);
		return false;
	}	
}
