
var SSOJSResourceBundle =
{    
    ERR_OLD_PASSWORD:		"Por favor ingrese su contraseña vieja."
    ,ERR_NEW_PASSWORD:		"Por favor ingrese su contraseña nueva."
    ,ERR_CONFIRM_PASSWORD:	"Por favor confirme su contraseña."
    ,ERR_MISMATCH_PASSWORD:	"La Contraseña Nueva y la de Confirmación no Concuerdan."
    ,ERR_GIVE_DIFF_PASSWORD:	"La contraseña nueva y la vieja son las mismas. Ingrese una contraseña diferente."
	,ERR_OLD_PIN:               "Ingrese su MPIN anterior."
	,ERR_NEW_PIN:               "Ingrese su MPIN nuevo."
	,ERR_CONFIRM_PIN:           "Confirme su MPIN."
	,ERR_MISMATCH_PIN:          "El MPIN nuevo y la confirmación de MPIN no coinciden."
	,ERR_GIVE_DIFF_PIN:         "El MPIN nuevo y el anterior son iguales, ingrese un MPIN diferente."
	,CHG_PWD_HELP:		"ui/help/ChangeCredentials/password.htm"
	,CHG_MPIN_HELP:		"ui/help/ChangeCredentials/change_mpin.htm"
	,BOTH_PWD_MPIN_HELP:"ui/help/ChangeCredentials/both_mpin_n_password.htm"
	,CHG_CRED_HELP:		"ui/help/ChangeCredentials/change_credential.htm"
}
