var visiblePanelBeforeLock = "";
function lockSSO()
{
	stopTimerInApps();

	var divs = cbeGetElementsByTagName('DIV');
	for(var i = 0; i < divs.length; i++)
	{
		with(divs[i].cbe)
		{
			if(visibility() == 1)
			{
				visiblePanelBeforeLock = id;				
			}
		}
	}
	
	showFrame('blankPage',null);
	
	var selectField = cbeGetElementsByTagName('SELECT');
	for(var k = 0; k < selectField.length; k++)
		selectField[k].style.visibility='hidden';

	var heightVal = divs['DeskTop'].cbe.height()+50;
	var widthVal = divs['DeskTop'].cbe.width()+5;

	if("Microsoft Internet Explorer" != browser_name) 
	{		
		heightVal = window.innerHeight;
	}
	
	var screenLeft = window.screenLeft;
	var screenTop = window.screenTop;
	
	ssoLocked = 1;	
	
	var retCode = doc.ClientApp.lockSSO(widthVal,heightVal,screenLeft,screenTop);
	ssoLocked = 0;
	
	if(retCode == LOCK_TIME_OUT || retCode == MAX_PWD_ATTEMPTS)
   	{
		loggedOut = true;        
		window.parent.loginFrame.location.replace("ui/"+langCode+"/Logout.jsp?LCLANG="+langCode);
	}
	else if(retCode != 0) 
	{
		alert(doc.ClientApp.getErrorMessage());
		return;
	}

	for(var k = 0; k < selectField.length; k++)
		selectField[k].style.visibility='visible';
		
	showFrame(visiblePanelBeforeLock,null);	
	resetTimer();
}
