
var sessID = null;
var rb = null;
var SSO_DESKTOP = "SSODeskTopServlet";

//set the resource bundle to proper language specific resbundle
function setSSOResourceBundle(SSOJSResourceBundle)
{
	rb = SSOJSResourceBundle;
}	
//setLoginStatus();

//set the status message in login window.
var appletCheckCount = 0;
function setLoginStatus()
{
	if(window.parent.appletFrame.appletReady && 
			window.parent.appletFrame.appletReady == 'true')
	{
		window.status = rb.SSO_APPLET_LOAD_SUCCESS;
		appletCheckCount = 0;
		return;
	}
	else
	{
		if(appletCheckCount > 20) {
			window.status = rb.ERR_APPLET_LOAD;
			appletCheckCount = 0;
			window.parent.appletFrame.appletReady = 'true';
			return;
		}
		else{
			window.status = rb.SSO_APPLET_LOAD;
			appletCheckCount++;
			window.setTimeout('setLoginStatus()', 500);
		}
	}
}

function openFinacleLink()
{
	window.open("http://www.finacle.com");
}
//set the focus on usertxt field once the applet is loaded
function setFormFocus()
{
	if(window.parent.appletFrame.appletReady && window.parent.appletFrame.appletReady == 'true')
	{
		if(document.loginForm && document.loginForm.usertxt) document.loginForm.usertxt.focus();
	}
	else window.setTimeout('setFormFocus()', 500);
}

// show the status message given in the status bar of the window
function showStatus(statusMsg)
{
	window.status = statusMsg;
}

// perform login with the values in form.
function login(formObj, desktopForm)
{
	var sessID = null;
	if(formObj.Submit) formObj.Submit.disabled = true;
	if(formObj.passtxt) formObj.passtxt.disabled = true;
	
	try {
		var username = formObj.usertxt.value;
		var pwd = formObj.passtxt.value;
		var langCode = formObj.langCode.value;
		var appletObj = window.parent.appletFrame.document.ClientApp;

		if(username == "" || pwd == "")
		{
			alert(rb.ERR_NO_USERID);
			if(formObj.Submit) formObj.Submit.disabled = false;
			if(formObj.passtxt) formObj.passtxt.disabled = false;
			return;
		}
		sessID = appletObj.login(username, pwd, langCode);
	}
	catch(exc)
	{
		alert(rb.ERR_NO_APPLET);
		if(formObj.Submit) formObj.Submit.disabled = false;
		if(formObj.passtxt) formObj.passtxt.disabled = false;
		return;
	}

	if((null == sessID) || ("" == sessID) || (appletObj.getErrorCode() != 0))
	{	
		
        window.location.replace("ui/error.jsp?LCLANG="+ langCode );
		return;
	}

	if((sessID != null) && (sessID != ""))
	{
		if(!isValidTwoFactorAuth(appletObj, username, langCode, "false"))
		{
			appletObj.logout(sessID, "F");
			window.location.replace("ui/error.jsp?LCLANG="+ langCode +
				"&ERROR_MSG=ERR_TF_PASSCODE_INCORRECT");
			return;
		}
		var serviceToken = appletObj.getServiceToken(sessID, SSO_DESKTOP, "");
		
		if((null == serviceToken) || (" "== serviceToken))
		{
			appletObj.logout(sessID, "F");
			window.location.replace("ui/error.jsp?LCLANG="+ langCode +
				"&ERROR_MSG=ERR_GET_SRVC_TOK_DESK");
			return;
		}
		desktopForm.SERVICE_TOKEN.value = serviceToken;
		desktopForm.USER_ID.value = username;
		desktopForm.SESSION_ID.value = sessID;
		desktopForm.LCLANG.value = langCode;
		desktopForm.IS_CHANGE_PWD_REQ.value = appletObj.getPwdExpiryFlag();
		desktopForm.submit();
	}
	else
	{
		if(formObj.Submit) formObj.Submit.disabled = false;
		if(formObj.passtxt) formObj.passtxt.disabled = false;
		formObj.passtxt.value="";
	}
}

// password clearing confirmation for virtual keypad
function respConfirm (formObj) {
	 var passln = formObj.passtxt.value.length;

	 if (passln != 0 ) {
		 var response = confirm(rb.MSG_PASSWD_CLEAR);
			if (response){
				formObj.passtxt.value='';
				return true;
			}
		 else return false;
	 }
	 return true;
}

// Invoking the virtual Keypad
function doKeyPad(formObj,field)
{
	var mode = 2; //for password field.
	var isSel = formObj.chkKeypad.checked;
	var sel = respConfirm(formObj);

	if(! sel ) {
		if(isSel)	formObj.chkKeypad.checked=false ;
		else		formObj.chkKeypad.checked=true;
		return true;
	}
	if ( isSel == true ) {
		disbleTextField(field);
		settingPinPadCtl(this, mode,field);
		randomDisplay();
	}
	else{
		setPinPadCtl(null);
		enableTextField(field);
		}
	
}
