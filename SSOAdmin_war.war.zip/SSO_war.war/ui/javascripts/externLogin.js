
var sessID = null;
var rb = null;
var SSO_DESKTOP = "SSODeskTopServlet";

//set the resource bundle to proper language specific resbundle
function setSSOResourceBundle(SSOJSResourceBundle)
{
	rb = SSOJSResourceBundle;
}	

//set the focus on usertxt field once the applet is loaded
function setFormFocus()
{
	if(window.parent.appletFrame.appletReady && window.parent.appletFrame.appletReady == 'true')
	{
		if(document.loginForm && document.loginForm.usertxt) document.loginForm.usertxt.focus();
	}
	else window.setTimeout('setFormFocus()', 500);
}

// show the status message given in the status bar of the window
function showStatus(statusMsg)
{
	window.status = statusMsg;
}

// perform login with the values in form.
function performLogin(formObj, desktopForm)
{
    var sessID = null;
    var username = null;
    try {
        if(!formObj || formObj == null) {
            alert(rb.ERR_FORM_DATA);
            return;
        }
        
		if(formObj.USER_ID) {
			username = formObj.USER_ID.value;
			
			if(username == "")
			{
				alert(rb.ERR_FORM_DATA);
				return;
			}
		}

        var langCode = formObj.LCLANG.value;
        var formData = "";
        var appletObj = window.parent.appletFrame.document.ClientApp;
		
		for(var i = 0; null != formObj && formObj && i < formObj.elements.length; i++)
        {
            if(i != 0)  formData += "&";
            formData += formObj.elements[i].name + "="+ formObj.elements[i].value;
        }
		
		sessID = appletObj.performLogin(username, formData);
		
		if(!username || null == username || "" == username) {
			username = appletObj.getUserName();
        }
	}
    catch(exc)
    {
        alert(rb.ERR_NO_APPLET);
        return;
    }

    if((null==sessID) || (""==sessID) || (appletObj.getErrorCode()!=0))
    {
        window.location.replace("ui/error.jsp?LCLANG="+ langCode );
		return;
    }

    if((sessID != null) && (sessID != ""))
    {
		if(!isValidTwoFactorAuth(null,appletObj,username, langCode, "false"))
		{
			var errMsg;
			twoFactorEnb = appletObj.getIsTwoFactorEnabled(username);
			
			if(null == twoFactorEnb || "null" == twoFactorEnb || "" == twoFactorEnb)
			{
				errMsg ="ERR_TFA_FAILED";
			}
			if((twoFactorEnb == "Y") || (twoFactorEnb == "M"))
			{
				errMsg ="ERR_TF_PASSCODE_INCORRECT";
			}						
			else if (twoFactorEnb == "B")
			{
				errMsg = "ERR_TF_FINGER_CHECK_FAILED";		
			}
			appletObj.logout(sessID, "F");
			window.location.replace("ui/error.jsp?LCLANG="+ langCode +
				"&ERROR_MSG=" +errMsg);
			return;	
		}
		var serviceToken = appletObj.getServiceToken(sessID, SSO_DESKTOP, "");
		if((null == serviceToken) || ("" == serviceToken))
		{
			appletObj.logout(sessID, "F");
			window.location.replace("ui/error.jsp?LCLANG="+ langCode +
				"&ERROR_MSG=ERR_GET_SRVC_TOK_DESK");
			return;
		}
        desktopForm.SERVICE_TOKEN.value = serviceToken;
        desktopForm.USER_ID.value = username;
        desktopForm.SESSION_ID.value = sessID;
        desktopForm.IS_CHANGE_PWD_REQ.value = appletObj.getPwdExpiryFlag();
		if("undefined" == desktopForm.IS_CHANGE_PWD_REQ.value)
			desktopForm.IS_CHANGE_PWD_REQ.value ="";
        desktopForm.submit();
    }
    else
    {
        formObj.reset();
    }
}
