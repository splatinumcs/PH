var applangcode = "es_ES";

var SSOJSResourceBundle =
{   
    
    ERR_NO_USERID:		"Por favor, introduzca el ID de usuario y contraseña."    
    ,ERR_NO_APPLET:		"No se pudo ejecutar el login: Applet no inicio correctamente."  
    ,SSO_APPLET_LOAD:		"Cargando el applet, por favor Espere…"
    ,ERR_APPLET_LOAD:		"Error al cargar el applet"
    ,SSO_APPLET_LOAD_SUCCESS:	"Applet se ha cargado exitosamente"  
    ,ERR_FORM_DATA:		"Datos ingresados no válidos."	
    ,SSO_TF_JAR_DOWNLOAD_SUCCESS:    "MobiToken jar se descargó correctamente en su máquina."
    ,SSO_TF_JAR_DOWNLOAD_CANCELLED:  "Se canceló la descarga de MobiToken jar."
    ,SSO_TF_JAR_DOWNLOAD_FAILED:     "Se produjo un error en la descarga de MobiToken jar."
    ,MSG_PASSWD_CLEAR:"El campo contraseña será limpiado.¿Desea continuar?"
    
};
