package connect;

import obj.DashbDataModel2;
import obj.Tranfile;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import util.Constant;
import gen.ClearTempFile;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.DataSource;

import java.io.*;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import obj.DashbDataModel;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.*;
import static java.util.Map.Entry.*;
import tmb.com.config.TmbUtility;

public class EmailService {

	final static org.apache.log4j.Logger logger = Logger.getLogger(EmailService.class);

	private Properties prop;

	public EmailService(Properties prop) {

		this.prop = prop;

	}

	public void sendEmailToUser(File pathFile, Date dateReport) {

		logger.info("Connecting to smtp sever");
		Session session = Session.getDefaultInstance(prop,
				new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(prop.getProperty("mail.user"),
						prop.getProperty("mail.pass"));
			}
		});
		logger.debug("host : " + prop.getProperty("mail.smtp.host"));
		logger.debug("port : " + prop.getProperty("mail.smtp.port"));

		session.setDebug(Boolean.parseBoolean(prop.getProperty("mail.debug")));
		dateReport = dateReport == null ? new Date() : dateReport;
		// Part two is attachment
		DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
		File file = new File("Trantracking_" + dateFormat.format(dateReport) + "." + Constant.TypeFile.ZIP);
		logger.debug(file.getAbsoluteFile());
		logger.debug(file.getName());

		try {
			logger.info("Connection complete !!");

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(prop.getProperty("mail.sender")));
			if (!StringUtils.isEmpty(prop.getProperty("mailUser.to"))) {
				message.addRecipients(MimeMessage.RecipientType.TO,
						splitEmailList(prop.getProperty("mailUser.to")));
			}
			if (!StringUtils.isEmpty(prop.getProperty("mailUser.cc"))) {
				message.addRecipients(MimeMessage.RecipientType.CC,
						splitEmailList(prop.getProperty("mailUser.cc")));
			}
			if (!StringUtils.isEmpty(prop.getProperty("mailUser.bcc"))) {
				message.addRecipients(MimeMessage.RecipientType.BCC,
						splitEmailList(prop.getProperty("mailUser.bcc")));
			}

			message.setSubject(replaceDataFormat(prop.getProperty("mail.subject.trantacking")));

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			// Now set the actual message
			//InputStream in = new FileInputStream(new File(System.getProperty("user.dir") + "/config/" + prop.getProperty("mail.message.html.file")));
			//String content = replaceDataFormat(IOUtils.toString(in, Charset.forName(Constant.CharSet.UTF)), tranfiles);
			String content = prop.getProperty("mail.message.trantacking");

			messageBodyPart.setContent(content, Constant.CharSet.UTF);

			// Create a multipar message
			Multipart multipart = new MimeMultipart();
			// Set text message part
			multipart.addBodyPart(messageBodyPart);

			if (file.exists()) {
				messageBodyPart = new MimeBodyPart();
				DataSource source = new FileDataSource(file.getAbsolutePath());
				messageBodyPart.setDataHandler(new DataHandler(source));
				messageBodyPart.setFileName(file.getName());
				multipart.addBodyPart(messageBodyPart);
			}

			// Send the complete message parts
			message.setContent(multipart);

			Transport.send(message);

			logger.info("Send email complete");

		} catch (MessagingException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void sendEmail(List<Tranfile> tranfiles, List<DashbDataModel> dashbList) throws FileNotFoundException {

		logger.info("Connecting to smtp sever");
		Session session = Session.getDefaultInstance(prop,
				new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(prop.getProperty("mail.user"),
						prop.getProperty("mail.pass"));
			}
		});
		logger.debug("host : " + prop.getProperty("mail.smtp.host"));
		logger.debug("port : " + prop.getProperty("mail.smtp.port"));

		session.setDebug(Boolean.parseBoolean(prop.getProperty("mail.debug")));

		try {
			logger.info("Connection complete !!");

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(prop.getProperty("mail.sender")));
			if (!StringUtils.isEmpty(prop.getProperty("mail.to"))) {
				message.addRecipients(MimeMessage.RecipientType.TO,
						splitEmailList(prop.getProperty("mail.to")));
			}
			if (!StringUtils.isEmpty(prop.getProperty("mail.cc"))) {
				message.addRecipients(MimeMessage.RecipientType.CC,
						splitEmailList(prop.getProperty("mail.cc")));
			}
			if (!StringUtils.isEmpty(prop.getProperty("mail.bcc"))) {
				message.addRecipients(MimeMessage.RecipientType.BCC,
						splitEmailList(prop.getProperty("mail.bcc")));
			}

			message.setSubject(replaceDataFormat(prop.getProperty("mail.subject")));

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			// Now set the actual message
			InputStream in = new FileInputStream(new File(System.getProperty("user.dir") + "/config/" + prop.getProperty("mail.message.html.file")));
			String content = replaceDataFormat(IOUtils.toString(in, Charset.forName(Constant.CharSet.UTF)), tranfiles);
			content = replaceDataFormatDASHB(content, dashbList);
			messageBodyPart.setContent(content, Constant.CharSet.HTML_TYPE);

			// Create a multipar message
			Multipart multipart = new MimeMultipart();
			// Set text message part
			multipart.addBodyPart(messageBodyPart);

			// Part two is attachment
			DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
			File file = new File(prop.getProperty("file.name.prefix")
					+ dateFormat.format(new Date()) + "." + Constant.TypeFile.ZIP);

			if (file.exists()) {
				messageBodyPart = new MimeBodyPart();
				DataSource source = new FileDataSource(file.getAbsolutePath());
				messageBodyPart.setDataHandler(new DataHandler(source));
				messageBodyPart.setFileName(file.getName());
				multipart.addBodyPart(messageBodyPart);
			}

			// Send the complete message parts
			message.setContent(multipart);

			Transport.send(message);

			logger.info("Send email complete");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendEmailLogs(File fLogs, String args[]) throws FileNotFoundException {

		logger.info("Connecting to smtp sever");
		Session session = Session.getDefaultInstance(prop,
				new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(prop.getProperty("mail.user"),
						prop.getProperty("mail.pass"));
			}
		});
		logger.debug("host : " + prop.getProperty("mail.smtp.host"));
		logger.debug("port : " + prop.getProperty("mail.smtp.port"));

		session.setDebug(Boolean.parseBoolean(prop.getProperty("mail.debug")));

		try {
			logger.info("Connection complete !!");

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(prop.getProperty("mail.sender")));
			if (!StringUtils.isEmpty(prop.getProperty("mail.to"))) {
				message.addRecipients(MimeMessage.RecipientType.TO,
						splitEmailList(prop.getProperty("mail.to")));
			}
			if (!StringUtils.isEmpty(prop.getProperty("mail.cc"))) {
				message.addRecipients(MimeMessage.RecipientType.CC,
						splitEmailList(prop.getProperty("mail.cc")));
			}
			if (!StringUtils.isEmpty(prop.getProperty("mail.bcc"))) {
				message.addRecipients(MimeMessage.RecipientType.BCC,
						splitEmailList(prop.getProperty("mail.bcc")));
			}

			message.setSubject(replaceDataFormat(prop.getProperty("mail.subject.trantracking")));

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			// Now set the actual message
			// InputStream in = new FileInputStream(new File(System.getProperty("user.dir") + "/config/" + prop.getProperty("mail.message.html.file")));
			// String content = replaceDataFormat(IOUtils.toString(in, Charset.forName(Constant.CharSet.UTF)), tranfiles);
			messageBodyPart.setContent("Logs file ", Constant.CharSet.UTF);

			// Create a multipar message
			Multipart multipart = new MimeMultipart();
			// Set text message part
			multipart.addBodyPart(messageBodyPart);

			// Part two is attachment
			DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
			File file = new File(prop.getProperty("file.name.prefix_logs")
					+ dateFormat.format(new Date()) + "." + Constant.TypeFile.ZIP);

			if (file.exists()) {
				messageBodyPart = new MimeBodyPart();
				DataSource source = new FileDataSource(file.getAbsolutePath());
				messageBodyPart.setDataHandler(new DataHandler(source));
				messageBodyPart.setFileName(file.getName());
				multipart.addBodyPart(messageBodyPart);
			}

			// Send the complete message parts
			message.setContent(multipart);

			Transport.send(message);

			logger.info("Send email complete");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	private static InternetAddress[] splitEmailList(String email) {
		List<InternetAddress> emList = new ArrayList<>();
		InternetAddress cc[] = null;
		if (!StringUtils.isEmpty(email)) {
			String sp[] = email.split(",");
			if (sp != null && sp.length > 0) {
				for (String em : sp) {
					if (!StringUtils.isEmpty((em))) {
						try {
							InternetAddress ipAddress = new InternetAddress(em);
							emList.add(ipAddress);
						} catch (AddressException ex) {
							try {
								throw ex;
							} catch (AddressException e) {
								logger.error(e);
							}
						}
					}

				}

			}
			if (emList != null && emList.size() > 0) {
				cc = new InternetAddress[emList.size()];
				int idx = 0;
				for (InternetAddress em : emList) {
					cc[idx] = em;
					idx++;
				}
			}
		}
		return cc;
	}

	public String replaceDataFormat(String str) {

		String pattern = prop.getProperty("mail.dateformat");
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		return str.replace(pattern, dateFormat.format(new Date()));
	}

	public String replaceDataFormat(String str, List<Tranfile> list) {


		//"#DETAIL_STATUS_TABLE"

		String data = replaceDataFormat(str);
		String table = "";
		if (list == null || list.isEmpty()) {
			table = "<TR>"
					+ "<th colspan=6 align=\"center\">No data not found</th>"
					+ "</TR>";
		} else {
			for (Tranfile f : list) {
				table += "<TR>"
						+ "<th  align=\"left\">" + f.getInOutFileName() + "</TD>"
						+ "<th  align=\"center\">" + TmbUtility.getEmptyString(f.getTrandate()) + "</th>" 
						+ "<th align=\"center\">" + TmbUtility.getEmptyString(f.getDifferenceInMinutes()) + "</th>"
						+ "<th align=\"center\">" + f.getCountMsd() + "</th>"
						+ "<th align=\"center\">" + f.getCountCtx() + "</th>" 
						+ "<th align=\"center\">" + TmbUtility.getEmptyString(f.getBatStatus()) + "</th>"
						+ "</TR>";
			}
		}

		data = data.replace(":TABLE_DATA", table);
		data = data.replace(":TOTAL_DATA", (list == null || list.isEmpty() ?0:list.size()) + "");

		return data;
	}



	/* display  dashb  report */

	public String replaceDataFormatDASHB(String str, List<DashbDataModel> list) {

		StringBuilder tempBatchesDetails = new StringBuilder();
		String templateBatches = "<tr bgcolor=\"#008000\"> "+
				"<th colspan=\"17\" style=\"color: #FFFFFF\">Batches status</th>"+
				"</tr>";

		String batchesDetail =	"<tr bgcolor=\"#008000\">"+

					"<th style=\"color: #FFFFFF\">Product</th>"+
					"<th style=\"color: #FFFFFF\">CRP Suspense</th>"+
					"<th style=\"color: #FFFFFF\">Partial Suspense</th>"+
					"<th style=\"color: #FFFFFF\">Hold Pending</th>"+
					"<th style=\"color: #FFFFFF\">Hold Retry</th>"+
					"<th style=\"color: #FFFFFF\">Debit Pending</th>"+
					"<th style=\"color: #FFFFFF\">In Progress</th>"+
					"<th style=\"color: #FFFFFF\">Partial Debit</th>"+
					"<th style=\"color: #FFFFFF\">Partial Retry</th>"+
					"<th style=\"color: #FFFFFF\">Debit Retry</th>"+
					"<th style=\"color: #FFFFFF\">Suspense</th>"+
					"<th style=\"color: #FFFFFF\">Partial Complete</th>"+
					"<th style=\"color: #FFFFFF\">Completed</th>"+
					"<th style=\"color: #FFFFFF\">Rejected</th>"+
					"<th style=\"color: #FFFFFF\">Cancelled</th>"+
					"<th style=\"color: #FFFFFF\">Other</th>"+
					"<th style=\"color: #FFFFFF\">Total</th>"+

				"</tr>";
		tempBatchesDetails.append(templateBatches);
		tempBatchesDetails.append(batchesDetail);

		/*String batchesTotal = "<TR  style=\"background-color: #1E90FF; \">"+
				"<TD colspan=16>Total of Files</TD>"+
				"<TD colspan=1 align=\"center\">#DETAIL_STATUS_TOTAL</TD>"+
				"</TR>";*/


		String data = str;
		String tableDetail = "";
		String table = "";
		HashMap<String, Integer> dashbMap = new HashMap();

		int totalDetail = 0;
		if (list.isEmpty()) {
			tableDetail = "<TR>"
					+ "<th colspan=17 align=\"center\">No data found</th>"
					+ "</TR>";
			tempBatchesDetails.append(tableDetail);
			logger.debug("tableDetail  emtpy ");
		} else {
			//List<DashbDataModel> list


			//HashMap<String, DashbDataModel2> dashbProductMap = new HashMap();
			HashMap<String, DashbDataModel2> dashbProductMap = tranformDataToDashModel(list);

			if (dashbProductMap.isEmpty()) {

				table = "<TR> <th colspan=17 align=\"center\">No data found</th> </TR>";
				tempBatchesDetails.append(table);
				//logger.debug("dashbMap  emtpy ");
			} else {

				DashbDataModel2 grandTotal = new DashbDataModel2();

				for (Map.Entry m : dashbProductMap.entrySet()) {

					if (m.getKey() != null ) {
						DashbDataModel2 itemModel = (DashbDataModel2) m.getValue();
						logger.debug("ProductCode = "+itemModel.getProductCode()+" TotalOfFile = "+itemModel.getTotalOfFile());
						//logger.info(" #### "+itemModel.toString());

						grandTotal.setCrpSuspense( itemModel.getCrpSuspense() +grandTotal.getCrpSuspense());
						grandTotal.setPartialSusp( itemModel.getPartialSusp() +grandTotal.getPartialSusp());
						grandTotal.setHoldPending( itemModel.getHoldPending() +grandTotal.getHoldPending());
						grandTotal.setHoldRetry( itemModel.getHoldRetry()+grandTotal.getHoldRetry());
						grandTotal.setDebitePending( itemModel.getDebitePending() +grandTotal.getDebitePending());
						grandTotal.setInprogress( itemModel.getInprogress() +grandTotal.getInprogress());
						grandTotal.setPartialDebit(itemModel.getPartialDebit() +grandTotal.getPartialDebit());
						grandTotal.setPartialRetry(itemModel.getPartialRetry() +grandTotal.getPartialRetry());
						grandTotal.setDebiteRetry(itemModel.getDebiteRetry() +grandTotal.getDebiteRetry());
						grandTotal.setSuspense(itemModel.getSuspense() +grandTotal.getSuspense());
						grandTotal.setPartiallyComplete(itemModel.getPartiallyComplete() +grandTotal.getPartiallyComplete());
						grandTotal.setComplete( itemModel.getComplete() +grandTotal.getComplete());
						grandTotal.setReject(itemModel.getReject() +grandTotal.getReject());

						grandTotal.setCancelC((itemModel.getCancelC()+itemModel.getCancelO()) +(grandTotal.getCancelC()+grandTotal.getCancelO()));
						grandTotal.setOther(itemModel.getOther() +grandTotal.getOther());
						grandTotal.setTotalOfFile(itemModel.getTotalOfFile() +grandTotal.getTotalOfFile()); 


						//int total

						logger.debug("ProductCode = "+itemModel.getProductCode()+" TotalOfFile = "+itemModel.getTotalOfFile());

						table += "<TR>"
								+ "<th align=\"center\">" + m.getKey() + "</th>"
								+ "<th  align=\"center\">" + itemModel.getCrpSuspense() + "</th>"
								+ "<th align=\"center\">" + itemModel.getPartialSusp() + "</th>"
								+ "<th align=\"center\">" + itemModel.getHoldPending() + "</th>"
								+ "<th align=\"center\">" + itemModel.getHoldRetry() + "</th>"
								+ "<th align=\"center\">" + itemModel.getDebitePending() + "</th>"
								+ "<th align=\"center\">" + itemModel.getInprogress() + "</th>"
								+ "<th align=\"center\">" + itemModel.getPartialDebit() + "</th>"
								+ "<th align=\"center\">" + itemModel.getPartialRetry() + "</th>"
								+ "<th align=\"center\">" + itemModel.getDebiteRetry() + "</th>"
								+ "<th align=\"center\">" + itemModel.getSuspense() + "</th>"
								+ "<th align=\"center\">" + itemModel.getPartiallyComplete() + "</th>"
								+ "<th align=\"center\">" + itemModel.getComplete() + "</th>"
								+ "<th align=\"center\">" + itemModel.getReject() + "</th>"
								+ "<th align=\"center\">" + (itemModel.getCancelC()+ itemModel.getCancelO())+ "</th>"
								+ "<th align=\"center\">" + itemModel.getOther() + "</th>"
								+ "<th align=\"center\">" + itemModel.getTotalOfFile() + "</th>"

								+ "</TR> \n ";
					}




				}

				if(grandTotal !=null ){
					table += "<TR>"
							+ "<th align=\"center\">Total</th>"
							+ "<th align=\"center\">" + grandTotal.getCrpSuspense() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getPartialSusp() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getHoldPending() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getHoldRetry() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getDebitePending() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getInprogress() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getPartialDebit() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getPartialRetry() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getDebiteRetry() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getSuspense() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getPartiallyComplete() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getComplete() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getReject() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getCancelC()+ "</th>"
							+ "<th align=\"center\">" + grandTotal.getOther() + "</th>"
							+ "<th align=\"center\">" + grandTotal.getTotalOfFile() + "</th>"

							+ "</TR> \n ";
				}
				if(dashbProductMap.get(Constant.ProductCode.MCL) !=null ){

					DashbDataModel2 itmMCL = (DashbDataModel2) dashbProductMap.get(Constant.ProductCode.MCL); 
					table += "<TR>"
							+ "<th align=\"center\">"+Constant.ProductCode.MCL+"  (Debit pending) </th>"
							+ "<th colspan=16 align=\"left\"> Debit(Today) : " + itmMCL.getDebitDateT() +" batch , Debit(Next day) : "+itmMCL.getDebitDateN()+" batch </th>"  
							+ "</TR> \n ";
				}

				tempBatchesDetails.append(table);
			}


			dashbMap.put("CHQ", 0);
			dashbMap.put("NCHQ", 0);
			dashbMap.put("WHT", 0);

			String statusDB = list != null && list.size() > 0 ? list.get(0).getBatStatus() : "";
			String statusColorA = "style=\"background-color: #C0C0C0; \"";
			String statusColorB = "style=\"background-color: #DEB887; \"";

			String statusColor = statusColorA;
			for (DashbDataModel f : list) {
				if (!statusDB.equalsIgnoreCase(f.getBatStatus())) {
					statusColor = (statusColor.equalsIgnoreCase(statusColorA)) ? statusColorB : statusColorA;
				}
				statusDB = f.getBatStatus();
				/*tableDetail += "<TR " + statusColor + " >"
						+ "<th align=\"center\">" + TmbUtility.getEmptyString(f.getBatStatus()) + "</th>"
						+ "<th align=\"center\">" + f.getProductCode() + "</th>"
						+ "<th align=\"center\">" + f.getTotalOfFile() + "</th>"
						+ "<th align=\"center\">" + TmbUtility.getEmptyString(f.getDebitDate()) + "</th>"
						+ "</TR>";*/
				if (dashbMap.get(f.getProductCode()) == null) {
					if (f.getProductCode().equalsIgnoreCase("MCP")
							|| f.getProductCode().equalsIgnoreCase("CCP")
							|| f.getProductCode().equalsIgnoreCase("COP")
							|| f.getProductCode().equalsIgnoreCase("DDP")
							|| f.getProductCode().equalsIgnoreCase("INC")
							|| f.getProductCode().equalsIgnoreCase("IND")) {
						int cnt = dashbMap.get("CHQ").intValue();
						dashbMap.put("CHQ", (f.getTotalOfFile() + cnt));
					}else if (f.getProductCode().equalsIgnoreCase("WHT")) {
						int cnt = dashbMap.get("WHT").intValue();
						dashbMap.put("WHT", (f.getTotalOfFile() + cnt));
					} else {
						dashbMap.put(f.getProductCode(), f.getTotalOfFile());
					}

				} else {
					if (f.getProductCode().equalsIgnoreCase("MCP")
							|| f.getProductCode().equalsIgnoreCase("CCP")
							|| f.getProductCode().equalsIgnoreCase("COP")
							|| f.getProductCode().equalsIgnoreCase("DDP")
							|| f.getProductCode().equalsIgnoreCase("INC")
							|| f.getProductCode().equalsIgnoreCase("IND")) {
						int cnt = dashbMap.get("CHQ").intValue();
						dashbMap.put("CHQ", (f.getTotalOfFile() + cnt));
					}else if (f.getProductCode().equalsIgnoreCase("WHT")) {
						int cnt = dashbMap.get("WHT").intValue();
						dashbMap.put("WHT", (f.getTotalOfFile() + cnt));
					} else {
						int cnt = dashbMap.get(f.getProductCode()).intValue();
						dashbMap.put(f.getProductCode(), (f.getTotalOfFile() + cnt));
					}

				}
				totalDetail += f.getTotalOfFile();
			}
		}
		Map<String, Integer> sorted  =  null;
		String  table2  = "";
		if(!dashbMap.isEmpty()){
			sorted  = dashbMap
					.entrySet()
					.stream()
					.sorted(comparingByKey())
					.collect(
							toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2,
									LinkedHashMap::new));
		}

		if (sorted.isEmpty()) {
			table2 = "<TR>"
					+ "<th colspan=2 align=\"center\">No data found</th>"
					+ "</TR>";

			//logger.debug("dashbMap  emtpy ");
		} else {

			Map<String, Long> listOfTrans = new ClearTempFile(prop).getDataTotalOfTrans();

			for (Map.Entry m : sorted.entrySet()) {

				if (m.getKey() != null && TmbUtility.convertStrToInt(String.valueOf(m.getValue()))>0) {

					table2 += "<TR>"
							+ "<th align=\"center\">" + m.getKey() + "</th>"
							+ "<th align=\"center\">" + m.getValue() + "</th>"; 

					table2 +="<th align=\"center\">" + ((listOfTrans.get(m.getKey())!=null)?listOfTrans.get(m.getKey()):0) + "</th>";
					table2 += "</TR> \n ";
				}

			}
			// logger.debug("dashbMap  true ");
		}
		data = data.replace("#DETAIL_STATUS_TABLE", tempBatchesDetails.toString());
		//data = data.replace("#DETAIL_STATUS_TOTAL", totalDetail + "");

		// logger.info("table 1 "+table);
		//  logger.info("data 1 "+data);
		data = data.replace("#DASHB_FILES_TABLE", table2);
		data = data.replace("#DASHB_FILES_TOTAL", totalDetail + "");

		return data;
	}





	private HashMap<String, DashbDataModel2> tranformDataToDashModel(List<DashbDataModel> list) {


		HashMap<String, DashbDataModel2> dashbProductMap = new HashMap<String, DashbDataModel2>();

		HashMap<String, DashbDataModel2> sorts = new HashMap<String, DashbDataModel2>();

		HashMap<String, DashbDataModel2> mclData = new HashMap<String, DashbDataModel2>();


		for (DashbDataModel f : list) {

			//logger.info("DashbDataModel #### = "+f.toString());


			if(dashbProductMap.get(f.getProductCode()) == null){

				DashbDataModel2 dsahb2 = new DashbDataModel2();
				dsahb2.setProductCode(f.getProductCode());

				for (DashbDataModel txn : list) {
					if(dsahb2.getProductCode().equalsIgnoreCase(txn.getProductCode())){



						if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.REJECTED)){
							dsahb2.setReject(dsahb2.getReject()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.CENCEL_O)){
							dsahb2.setCancelO(dsahb2.getCancelO()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.SUSPENSE)){
							dsahb2.setSuspense(dsahb2.getSuspense()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.PROCESS)){
							dsahb2.setProcess(dsahb2.getProcess()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.CANCEL_C)){
							dsahb2.setCancelC(dsahb2.getCancelC()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.COMPLETED)){
							dsahb2.setComplete(dsahb2.getComplete()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.DEBIT_PENDING)){
							dsahb2.setDebitePending(dsahb2.getDebitePending()+txn.getTotalOfFile());
							if(txn.getProductCode().equalsIgnoreCase(Constant.ProductCode.MCL)){
								if(TmbUtility.isNull(f.getDebitDate())){
									dsahb2.setDebitDateN(dsahb2.getDebitDateN()+txn.getTotalOfFile());
								}else if(f.getDebitDate().equalsIgnoreCase(Constant.DashbStatus.DEBIT_TODAY)){
									dsahb2.setDebitDateT(dsahb2.getDebitDateT()+txn.getTotalOfFile());
								}
							}


						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.DEBIT_RETRY)){
							dsahb2.setDebiteRetry(dsahb2.getDebiteRetry()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.INPROGRESS)){
							dsahb2.setInprogress(dsahb2.getInprogress()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.SUCCESS)){
							dsahb2.setSuccess(dsahb2.getSuccess()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.HOLD_PENDING)){
							dsahb2.setHoldPending(dsahb2.getHoldPending()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.HOLD_RETRY)){
							dsahb2.setHoldRetry(dsahb2.getHoldRetry()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.PARTIALLY_COMPLETED)){
							dsahb2.setPartiallyComplete(dsahb2.getPartiallyComplete()+txn.getTotalOfFile());
						}
						else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.PARTIAL_DEBIT)){
							dsahb2.setPartialDebit(dsahb2.getPartialDebit()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.PARTIAL_SUSPENSE)){
							dsahb2.setPartialSusp(dsahb2.getPartialSusp()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.PARTIAL_RETRY)){
							dsahb2.setPartialRetry(dsahb2.getPartialRetry()+txn.getTotalOfFile());
						}else if(txn.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.CRP_SUSPENSE)){
							dsahb2.setCrpSuspense(dsahb2.getCrpSuspense()+txn.getTotalOfFile());
						}else {
							dsahb2.setOther(dsahb2.getOther()+txn.getTotalOfFile());
						}
					} 

				}

				int totalAll =  dsahb2.getCrpSuspense() +   
						dsahb2.getPartialSusp() +  
						dsahb2.getHoldPending() +  
						dsahb2.getHoldRetry() + 
						dsahb2.getDebitePending() + 
						dsahb2.getInprogress() + 
						dsahb2.getPartialDebit() +  
						dsahb2.getPartialRetry() + 
						dsahb2.getDebiteRetry() +  
						dsahb2.getSuspense() +  
						dsahb2.getPartiallyComplete() + 
						dsahb2.getComplete() + 
						dsahb2.getReject() +  
						dsahb2.getCancelC()+ 
						dsahb2.getCancelO()+  
						dsahb2.getOther()  ;
				dsahb2.setTotalOfFile(totalAll);

				dashbProductMap.put(f.getProductCode(), dsahb2);
			}
		}
		if(!dashbProductMap.isEmpty()){
			ClearTempFile  clearTempFile = new ClearTempFile(prop);

			List<DashbDataModel> dataDASHBCrpSusp =  clearTempFile.getDataDASHBCrpSusp();

			if(dataDASHBCrpSusp !=null && dataDASHBCrpSusp.size()>0){
				if(list ==null || list.size() == 0){
					list = new ArrayList<DashbDataModel>();
				}
				for(DashbDataModel itm : dataDASHBCrpSusp){
					if((itm.getBatStatus().equalsIgnoreCase(Constant.DashbStatus.DEBIT_PENDING))&&
							(itm.getProductCode().equalsIgnoreCase(Constant.ProductCode.CHQ_CCP)||
									itm.getProductCode().equalsIgnoreCase(Constant.ProductCode.CHQ_INC)||
									itm.getProductCode().equalsIgnoreCase(Constant.ProductCode.CHQ_IND)||
									itm.getProductCode().equalsIgnoreCase(Constant.ProductCode.CHQ_COP)||
									itm.getProductCode().equalsIgnoreCase(Constant.ProductCode.CHQ_DDP)||
									itm.getProductCode().equalsIgnoreCase(Constant.ProductCode.CHQ_MCP)||
									itm.getProductCode().equalsIgnoreCase(Constant.ProductCode.CHQ_WHT))){
						DashbDataModel2 tmp = dashbProductMap.get(itm.getProductCode()); 
						if(tmp.getProductCode().equalsIgnoreCase(itm.getProductCode())){
							tmp.setDebitePending(tmp.getDebitePending()- itm.getTotalOfFile());
							tmp.setCrpSuspense(itm.getTotalOfFile());
							tmp.setTotalOfFile(tmp.getTotalAll());
							dashbProductMap.put(itm.getProductCode(), tmp);
						}
					}else{
						DashbDataModel2 tmp = dashbProductMap.get(itm.getProductCode()); 
						if(tmp.getProductCode().equalsIgnoreCase(itm.getProductCode())){ 
							tmp.setCrpSuspense(itm.getTotalOfFile());
							tmp.setTotalOfFile(tmp.getTotalAll());
							dashbProductMap.put(itm.getProductCode(), tmp);
						}
					}

				}

			}

			sorts  = dashbProductMap
					.entrySet()
					.stream()
					.sorted(comparingByKey())
					.collect(
							toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2,
									LinkedHashMap::new));
		}

		return sorts;
	}


	public void sendEmailAutoDelete(String content) {


		Session session = Session.getDefaultInstance(prop,
				new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(prop.getProperty("mail.user"),
						prop.getProperty("mail.pass"));
			}
		});


		session.setDebug(Boolean.parseBoolean(prop.getProperty("mail.debug")));
		//dateReport = dateReport == null ? new Date() : dateReport;
		// Part two is attachment
		//DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
		//File file = new File("Trantracking_" + dateFormat.format(dateReport) + "." + Constant.TypeFile.ZIP);
		//logger.debug(file.getAbsoluteFile());
		//logger.debug(file.getName());

		try {
			logger.info("Connection complete !!");

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(prop.getProperty("mail.sender")));
			if (!StringUtils.isEmpty(prop.getProperty("mail.auto.delete.to"))) {
				message.addRecipients(MimeMessage.RecipientType.TO,
						splitEmailList(prop.getProperty("mail.auto.delete.to")));
			}
			if (!StringUtils.isEmpty(prop.getProperty("mail.auto.delete.cc"))) {
				message.addRecipients(MimeMessage.RecipientType.CC,
						splitEmailList(prop.getProperty("mail.auto.delete.cc")));
			}
			if (!StringUtils.isEmpty(prop.getProperty("mail.auto.delete.bcc"))) {
				message.addRecipients(MimeMessage.RecipientType.BCC,
						splitEmailList(prop.getProperty("mail.auto.delete.bcc")));
			}

			message.setSubject(replaceDataFormat(prop.getProperty("mail.auto.delete.subject")));

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			// Now set the actual message
			//InputStream in = new FileInputStream(new File(System.getProperty("user.dir") + "/config/" + prop.getProperty("mail.message.html.file")));
			//String content = replaceDataFormat(IOUtils.toString(in, Charset.forName(Constant.CharSet.UTF)), tranfiles);
			//String content = prop.getProperty("mail.auto.delete.message");

			//messageBodyPart.setContent(content, Constant.CharSet.UTF);
			messageBodyPart.setContent(content, Constant.CharSet.HTML_TYPE);
			// Create a multipar message
			Multipart multipart = new MimeMultipart();
			// Set text message part
			multipart.addBodyPart(messageBodyPart);



			// Send the complete message parts
			message.setContent(multipart);

			Transport.send(message);

			logger.info("Send email complete");

		} catch (MessagingException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void sendEmailLog(String content,String subject) {


		Session session = Session.getDefaultInstance(prop,
				new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(prop.getProperty("mail.user"),
						prop.getProperty("mail.pass"));
			}
		});


		session.setDebug(Boolean.parseBoolean(prop.getProperty("mail.debug")));


		try {
			logger.info("Connection complete !!");

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(prop.getProperty("mail.sender")));
			if (!StringUtils.isEmpty(prop.getProperty("mail.auto.delete.to"))) {
				message.addRecipients(MimeMessage.RecipientType.TO,
						splitEmailList(prop.getProperty("mail.auto.delete.to")));
			}
			if (!StringUtils.isEmpty(prop.getProperty("mail.auto.delete.cc"))) {
				message.addRecipients(MimeMessage.RecipientType.CC,
						splitEmailList(prop.getProperty("mail.auto.delete.cc")));
			}
			if (!StringUtils.isEmpty(prop.getProperty("mail.auto.delete.bcc"))) {
				message.addRecipients(MimeMessage.RecipientType.BCC,
						splitEmailList(prop.getProperty("mail.auto.delete.bcc")));
			}

			message.setSubject(replaceDataFormat(subject));

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();

			messageBodyPart.setContent(content, Constant.CharSet.HTML_TYPE);
			// Create a multipar message
			Multipart multipart = new MimeMultipart();
			// Set text message part
			multipart.addBodyPart(messageBodyPart);



			// Send the complete message parts
			message.setContent(multipart);

			Transport.send(message);

			logger.info("Send email complete");

		} catch (MessagingException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void sendEmailAttachedFile(File fileZip,Properties propOriginal,Properties propAdd,String content) throws FileNotFoundException {

		logger.info("Connecting to smtp sever");
		Session session = Session.getDefaultInstance(propOriginal,
				new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(propOriginal.getProperty("mail.user"),
						propOriginal.getProperty("mail.pass"));
			}
		});
		//logger.debug("host : " + prop.getProperty("mail.smtp.host"));
		//logger.debug("port : " + prop.getProperty("mail.smtp.port"));

		session.setDebug(Boolean.parseBoolean(propOriginal.getProperty("mail.debug")));

		try {
			logger.info("Connection complete !!");

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(propOriginal.getProperty("mail.sender")));
			if (!StringUtils.isEmpty(propAdd.getProperty("mail.to"))) {
				message.addRecipients(MimeMessage.RecipientType.TO,
						splitEmailList(propAdd.getProperty("mail.to")));
			}
			if (!StringUtils.isEmpty(propAdd.getProperty("mail.cc"))) {
				message.addRecipients(MimeMessage.RecipientType.CC,
						splitEmailList(propAdd.getProperty("mail.cc")));
			}
			if (!StringUtils.isEmpty(propAdd.getProperty("mail.bcc"))) {
				message.addRecipients(MimeMessage.RecipientType.BCC,
						splitEmailList(propAdd.getProperty("mail.bcc")));
			}

			message.setSubject(replaceDataFormat(propAdd.getProperty("mail.subject")));

			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			// Now set the actual message
			//InputStream in = new FileInputStream(new File(System.getProperty("user.dir") + "/config/" + prop.getProperty("mail.message.html.file")));
			//String content = "Report";//replaceDataFormat(IOUtils.toString(in, Charset.forName(Constant.CharSet.UTF)), tranfiles);
			//content = replaceDataFormatDASHB(content, dashbList);
			messageBodyPart.setContent(content, Constant.CharSet.HTML_TYPE);

			// Create a multipar message
			Multipart multipart = new MimeMultipart();
			// Set text message part
			multipart.addBodyPart(messageBodyPart);

			// Part two is attachment
			 

			if (fileZip.exists()) {
				messageBodyPart = new MimeBodyPart();
				DataSource source = new FileDataSource(fileZip.getAbsolutePath());
				messageBodyPart.setDataHandler(new DataHandler(source));
				messageBodyPart.setFileName(fileZip.getName());
				multipart.addBodyPart(messageBodyPart);
			}

			// Send the complete message parts
			message.setContent(multipart);

			Transport.send(message);

			logger.info("Send email complete");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		} 
	}


}
