/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tmb.com.config;

import gen.ClearTempFile;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import sun.util.logging.resources.logging;

/**
 *
 * @author 47758
 */
public class CSVManagementFile {

	public static final String NEW_LINE_SEPARATOR = "\n";
	private static Log logger = LogFactory.getLog(CSVManagementFile.class);

	 

public static StringBuilder readTextFileAppend(String fileName) {
	StringBuilder str = new StringBuilder();

	File file = new File(fileName);

	try {
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "TIS-620"));
		String line;
		while ((line = br.readLine()) != null) {
			str.append(line);
		}
		br.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return str;
}
public static StringBuilder readTextFileSQlScript(String fileName) {
	StringBuilder str = new StringBuilder();

	File file = new File(fileName);

	try {
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "TIS-620"));
		String line;
		while ((line = br.readLine()) != null) {
			str.append(line+" \n ");
			//str.append(line+" || chr(10) || ");
		}
		br.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return str;
}

public static List<String> readTextFile(String fileName) {
	List<String> responseModel = new ArrayList();
	File file = new File(fileName);

	try {
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "TIS-620"));
		String line;
		while ((line = br.readLine()) != null) {
			// System.out.println(line);
			responseModel.add(line);
		}
		br.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return responseModel;
}

public static void fileWriter(String fileHeader, String fileFooter, List<String> dataList, String filenameOut) {
	if (dataList != null && dataList.size() > 0) {

		System.out.println("CSV  File Writer !!!");

		Writer fileWriter = null;
		try {
			fileWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(filenameOut)), "UTF8"));

			//Write the CSV file header
			if (!TmbUtility.isNull(fileHeader)) {
				fileWriter.append(fileHeader);

				//Add a new line separator after the header
				fileWriter.append(NEW_LINE_SEPARATOR);
			}

			//Write a new student object list to the CSV file
			for (String model : dataList) {
				fileWriter.append(model);
				fileWriter.append(NEW_LINE_SEPARATOR);
			}
			if (!TmbUtility.isNull(fileHeader)) {
				fileWriter.append(fileFooter);
			}
			System.out.println("file was created successfully !!!");
			System.out.println(filenameOut);

		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		} finally {

			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}

		}

	}
}


public static void fileWriterFromQueryToCsv(String fileHeader, String fileFooter, List<String> dataList, String filenameOut) {
	if (dataList != null && dataList.size() > 0) {

		System.out.println("CSV  File Writer !!!");

		Writer fileWriter = null;
		try {
			fileWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(filenameOut)), "TIS-620"));

			//Write the CSV file header
			if (!TmbUtility.isNull(fileHeader)) {
				fileWriter.append(fileHeader);

				//Add a new line separator after the header
				fileWriter.append(NEW_LINE_SEPARATOR);
			}

			//Write a new student object list to the CSV file
			for (String model : dataList) {
				fileWriter.append(model);
				fileWriter.append(NEW_LINE_SEPARATOR);
			}
			if (!TmbUtility.isNull(fileHeader)) {
				fileWriter.append(fileFooter);
			}
			System.out.println("file was created successfully !!!");
			System.out.println(filenameOut);

		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		} finally {

			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}

		}

	}
}

public static void fileWriter(String destinationFolderFileCore, String fileName, byte bytesArray) {

	System.out.println("  File Writer !!!");

	FileOutputStream fos = null;
	try {
		fos = new FileOutputStream(destinationFolderFileCore + "\\" + fileName);
		fos.write(bytesArray);
		fos.close();

		System.out.println("  file was created successfully !!!");
		System.out.println(destinationFolderFileCore + "\\" + fileName);

	} catch (Exception e) {
		System.err.println("" + e.getLocalizedMessage());
		e.printStackTrace();
	} finally {

		try {
			fos.flush();
			fos.close();
		} catch (IOException e) {
			System.err.println("Error while flushing/closing fileWriter !!!");
			e.printStackTrace();
		}

	}

}

public static void moveFileDesc(File srcfile, String descPathFile, String filename, boolean delete) {
	try {
		logger.info(new File(descPathFile + "/" + filename).getAbsoluteFile());
		if (srcfile.renameTo(new File(descPathFile + "/" + filename))) {
			logger.info(" File is moved successful! [" + new File(descPathFile + "/" + filename).getAbsoluteFile() + "]");
			if (srcfile.exists() && delete) {
				srcfile.delete();
			}
		} else {
			System.out.println("File is failed to move!");
		}

	} catch (Exception e) {
		e.printStackTrace();
	}
}

public static int readCountTextFile(String startPrifix, String fileName) {

	int txn = 0;

	try {
		File file = new File(fileName.replace("..", "."));
		if (file.exists()) {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));

			String line;

			while ((line = br.readLine()) != null) {
				//logger.debug(" read line =" + line);
				if (!TmbUtility.isNull(line) && line.length() > 0 && line.toUpperCase().startsWith(startPrifix.toUpperCase())) {
					//  logger.debug(" line =" + line);
					txn += 1;

				}

			}

			br.close();

		} else {
			logger.debug("file  not exist :" + file.getAbsolutePath());
		}
	} catch (IOException e) {

		// TODO Auto-generated catch block
		e.printStackTrace();

	}

	logger.debug(" file name =" + fileName + " , txn =" + txn);

	return txn;

}

}
