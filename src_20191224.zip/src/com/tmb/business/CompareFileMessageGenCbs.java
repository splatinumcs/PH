package com.tmb.business;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset; 
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List; 
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import obj.DashbDataModel;
import obj.MessageFileGenModel;
import obj.Tranfile;
import obj.TransResponseModel;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import tmb.com.config.CSVManagementFile;
import tmb.com.config.TmbUtility;
import util.Constant;
import connect.DbManagement;
import connect.EmailService;
import connect.FileSFTP;

public class CompareFileMessageGenCbs {
	final static Logger logger = Logger.getLogger(CompareFileMessageGenCbs.class);
	private Properties prop;
	private SimpleDateFormat dateFormat;
 
 
	private FileSFTP fileSFTP = null;
	public static String scriptsInquiry = System.getProperty("user.dir") + "/config/scriptsInquiryMessageGen.txt";
	public CSVManagementFile fileMGT = null;
	public File fileGen = new  File("D:\\Users\\47758\\Desktop\\UAT\\UAT_FILE_GEN\\");
	
	private List<MessageFileGenModel> fileGenList= null;

	public CompareFileMessageGenCbs(Properties prop, SimpleDateFormat dateFormat) {
		this.prop = prop;
		this.dateFormat = dateFormat;
	}
	public void process(){
		
		fileSFTP = new FileSFTP(prop);
		fileGenList= new ArrayList<MessageFileGenModel>();
		fileMGT = new CSVManagementFile();
		logger.info("############# START Compare File MessageGen Cbs ###################");

		//readSourceFileINT();
		
		List<MessageFileGenModel> listFileName  = getDataMessageGen();
	/*	listFileName.stream().forEach(fp -> {
			logger.info(" case1 ="+fp.toString());
		});*/
		listFileName = compareDbAndFile(listFileName);
		listFileName.stream().forEach(fp -> {
			logger.info(" case2 ="+fp.toString());
		});
		sendEmail(listFileName) ; 
		logger.info("############# END Compare File MessageGen Cbs ###################");

	}
	
	
	private List<MessageFileGenModel>  compareDbAndFile(List<MessageFileGenModel> listFileGen) {
		
		 if(listFileGen !=null && listFileGen.size()>0){
			
		 
			 
			 listFileGen.stream().forEach(fg -> {
				 long countTXN = 0;
				 String pathFileOut = fileGen.getAbsolutePath()+"/"+ fg.getFileName();;
				 if( fg.getFileName().startsWith("0506")){
					 countTXN =  countFileGenEXTERNAL(pathFileOut);
				 }else  if( fg.getFileName().startsWith("IPMH")){
					 countTXN =  countFileGenINTERNAL("D", pathFileOut);
				 }
				 fg.setTotalOfFile(countTXN); 
				 
			 });
		 }
		 return listFileGen;
	}
		
	private void sendEmail(List<MessageFileGenModel> listFileGen) {	
		InputStream in = null;
		try {
			in = new FileInputStream(new File(System.getProperty("user.dir") + "/config/templateFileGenMessage.html"));
			String content = IOUtils.toString(in, Charset.forName(Constant.CharSet.UTF));
			String table = "";
			long grandTotalDB = 0;
			long grandTotalFile = 0;
			if (listFileGen == null || listFileGen.isEmpty()) {
				table = "<TR>"
						+ "<th colspan=6 align=\"center\">No data not found</th>"
						+ "</TR>";
			} else {
				for (MessageFileGenModel fd : listFileGen) {
					table += "<TR>"
							+ "<th  align=\"center\">" + fd.getFileDate() + "</th>"
							+ "<th  align=\"center\">" + fd.getProductName() + "</th>"
							+ "<th  align=\"center\">" + fd.getFileName() + "</th>"
							+ "<th  align=\"center\">" + fd.getTotalOfAmtInDb() + "</th>"
							+ "<th  align=\"center\">" +fd.getTotalOfDb()+ "</th>" 
							+ "<th align=\"center\">" + fd.getTotalOfFile() + "</th>" 
							+ "</TR>";
					grandTotalDB += fd.getTotalOfDb();
					grandTotalFile += fd.getTotalOfFile();
				}
			}

			content = content.replace("#DETAIL_OF_DATA", table);
			content = content.replace("#TOTAL_FILES_DB", grandTotalDB+"");
			content = content.replace("#TOTAL_FILES_FL", grandTotalFile + "");
			
			String subject = "Monitor Message File Gen To CBS PH";
			
			logger.info(content);
			//new EmailService(prop).sendEmailLog(content,subject);
			
		} catch (IOException e) {
			logger.error(" error ,"+e.getLocalizedMessage());
		}
		
		
	}
	
	
	public List<MessageFileGenModel> getDataMessageGen() {

		List<MessageFileGenModel> list = new ArrayList<MessageFileGenModel>();
		Connection conn = new DbManagement(prop).connection();
	 
		StringBuilder sqlScripts = CSVManagementFile.readTextFileAppend(scriptsInquiry);
		

		PreparedStatement preStmt = null;
		String sqlCheck = sqlScripts.toString();
		logger.debug("start  query Data message gen ");
		//logger.debug("sqlCheck >>"+sqlCheck);
		try {
			preStmt = conn.prepareStatement(sqlCheck);
			ResultSet rs = preStmt.executeQuery();

			while (rs.next()) {
				MessageFileGenModel dataModel = new MessageFileGenModel();
				dataModel.setFileDate(rs.getString(1));
				dataModel.setFileName(rs.getString(2));
				dataModel.setProductName(rs.getString(3));
				dataModel.setTotalOfDb(rs.getLong(4));
				dataModel.setTotalOfAmtInDb(rs.getBigDecimal(5));
				list.add(dataModel);
			}
		 
			preStmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getLocalizedMessage());
		} finally {
			try {
				logger.debug("end query Data message gen ");
				preStmt.close();
			} catch (SQLException e) {
				logger.error(e.getLocalizedMessage());
			}
			try {
				conn.close();
			} catch (SQLException e) {
				logger.error(e.getLocalizedMessage());
			}
		}

		return list;
	}
	
 

	private int countFileGenINTERNAL(String  prefix,String  pathFileName) {
		//IPMH
		prefix = TmbUtility.isNull(prefix)?"D":prefix;
		return   CSVManagementFile.readCountTextFile(prefix, pathFileName);
	}
	private int countFileGenEXTERNAL(String  pathFileName) {
		//0506 
		 List<String> listRXX = CSVManagementFile.readTextFile(pathFileName);
		return   (listRXX.size()>=3?(listRXX.size()-3):0);
	}


}
