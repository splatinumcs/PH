package com.tmb.business;

import gen.PHFileManagement;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Vector;

import obj.PprModel;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import tmb.com.config.CSVManagementFile;
import tmb.com.config.TmbUtility;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

import connect.DbManagement;
import connect.FileSFTP;

public class PickupPprProcessing {
	final static Logger logger = Logger.getLogger(PickupPprProcessing.class);
	private Properties prop; 

	private FileSFTP fileSFTP = null;
	private static File pathSrc = new File("/app/PHCheckDeleteFile/TEMP_PPR"); 
	private static String sftpPath = "/paymenthub/UAT/TRFSingle/CIB/Inbound/";
	private static String localPathPPR =  "/app/staging/in/cib/pps/download/";
	private static int timeForPickup = 3;  
	private  static Calendar calendarOld = null;
	private  static String  prefixFolder = null;

	public PickupPprProcessing(Properties prop) {
		this.prop = prop; 
		if(prop.getProperty("TIME_FOR_PICKUP_PPR_FILE_RESEND") !=null){
			timeForPickup = TmbUtility.convertStrToInt(prop.getProperty("TIME_FOR_PICKUP_PPR_FILE_RESEND").trim());
		}
		
		Date currentDate = new  Date();
		calendarOld = Calendar.getInstance(Locale.US);
		calendarOld.setTime(currentDate); 
		calendarOld.add(Calendar.MINUTE, (timeForPickup*-1)); 
		prefixFolder = TmbUtility.formateDateBySimpleDateFormat(calendarOld.getTime(), TmbUtility.YYMMDD)+"_"+TmbUtility.formateDateBySimpleDateFormat(calendarOld.getTime(), TmbUtility.HHmm);
		if(!pathSrc.exists()){
			pathSrc.mkdirs();
		}
		if(prop.getProperty("SFTP_PICKUP_PPR_FILE_RESEND_PO") !=null){
			sftpPath = prop.getProperty("SFTP_PICKUP_PPR_FILE_RESEND_PO");
		}

		if(prop.getProperty("PATH_PO_FILE_PPR") !=null){
			localPathPPR = prop.getProperty("PATH_PO_FILE_PPR");
		}
		
	}
	public void process(){ 

		fileSFTP = new FileSFTP(prop); 
		try { 
			if(!new File(localPathPPR).exists()){
				new File(localPathPPR).mkdirs();
			} 
			FileUtils.cleanDirectory(pathSrc);
			getFileFromSftpParam(sftpPath, pathSrc.getAbsolutePath(), true); 
			FileUtils.cleanDirectory(pathSrc);
			logger.debug("Clean Directory path >> :  "+pathSrc);
		}catch(Exception e){
			//logger.info("########### case 1 error not found Config_Report.properties ");
			e.printStackTrace();
		}  

		logger.info("############# START CHECK PickupPPRTransaction###################");
	}


	public String[] getFileFromSftpParam(String sftpDownloadPath, String localPath, boolean FlagDelete) {

		//DateFormat dateFormat = new SimpleDateFormat(prop.getProperty("file.name.dateformat"));
		List<PprModel> sftpPathFolder = new ArrayList<PprModel>();
		Session session = null;
		try { 
			session = fileSFTP.getSession();
			ChannelSftp sftpChannel = fileSFTP.getChanel(session);
			sftpChannel.cd(sftpDownloadPath.trim());
			Vector<ChannelSftp.LsEntry> list = sftpChannel.ls("*"); 


			final int i = list.size();

			for(int j = 0; j<i ;j++){
				LsEntry entry = list.get(j);
				SftpATTRS attr = entry.getAttrs();
				if(attr.isDir()){ 
					String  pprFolder = entry.getFilename(); 
					

					if(pprFolder.startsWith(prefixFolder)){ 
						Session sessionTemp = fileSFTP.getSession(); 
						ChannelSftp sftpChannelTemp = fileSFTP.getChanel(sessionTemp);
						sftpChannelTemp.cd(sftpDownloadPath+""+pprFolder);
						Vector<ChannelSftp.LsEntry> listTemp = sftpChannelTemp.ls(prop.getProperty("FILE_PPR_PATTURN"));
						try {
							if(listTemp !=null&&listTemp.size()>0){
								for (ChannelSftp.LsEntry fileTemp : listTemp) {
									sftpChannelTemp.get(fileTemp.getFilename(), localPath + File.separator + fileTemp.getFilename());
									PprModel pprModel = new PprModel();
									pprModel.setPathFile(localPath + File.separator + fileTemp.getFilename()); 
									sftpPathFolder.add(pprModel); 
									sftpChannel.rmdir(pprFolder); 
								}
							} 
							sftpChannelTemp.exit();
						} catch (Exception e) {
							//logger.error(e);
							logger.error(e.getLocalizedMessage());
						}finally{ 
							sessionTemp.disconnect();
						}
					}

				}else{
					logger.debug(" PPR Folder = "+entry.getFilename());
				} 
			}

			sftpChannel.exit();

		} catch (JSchException e) {
			e.printStackTrace();
			logger.error(e);
		} catch (SftpException e) {
			e.printStackTrace();
			logger.error(e);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
			logger.debug(e.getLocalizedMessage());
		} finally {
			logger.debug("Disconnect from SFTP");
			logger.debug(session.getHost());
			session.disconnect();
		} 

		try {  
			sftpPathFolder.stream().forEach(md->{
				List<String> contentFile = CSVManagementFile.readTextFile(md.getPathFile());
				if(contentFile !=null && contentFile.size()>=1){
					String  batchRefNo = contentFile.get(1).substring(3, 23).trim(); 
					boolean chk = checkBatchDup(new  File(md.getPathFile()).getName(),batchRefNo);
					md.setBatchRefNo(batchRefNo);
					md.setCheckDup(chk);
					if(chk==false){
						File srcPH = new  File(md.getPathFile());
						try {
							//logger.debug("source :  "+srcPH.getAbsolutePath());
							//logger.debug("dest :  "+new File(localPathPPR+srcPH.getName()).getAbsolutePath());

							PHFileManagement.copyFileUsingApacheCommonsIO(srcPH, new File(localPathPPR+srcPH.getName()));
							md.setFlagUpload(true);
							logger.debug("Reupload file PPR was completed :  "+md.getPathFile());
						} catch (Exception e) {
							logger.debug("Error:  "+e.getLocalizedMessage());
						}
					}else{
						logger.debug("Duplicated file :  "+md.getPathFile());
					}
				}
			}); 

		}catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
			logger.debug(e.getLocalizedMessage());
		} finally {
			logger.info("Disconnect DB");
			logger.debug(session.getHost());
			session.disconnect();
		}
		return null;
	}

	public int countCon(Connection conn, String sql, String param) throws SQLException {

		PreparedStatement countstmt = null;
		int count = 0;

		try {

			countstmt = conn.prepareStatement(sql);
			countstmt.setString(1, param);

			ResultSet rs = countstmt.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
			}

		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		} finally {
			countstmt.close();
		}

		return count;
	}

	public boolean checkBatchDup(String filename,String batchRefNo) {
		boolean chk =  false;
		String cntCpyckv = "select count(1) from custom.cpyckv where  file_name = ?  ";
		String cntBatch = "select count(1) from custom.cbatrec  where  fe_bat_ref_num = ? ";
		try {
			DbManagement db = new DbManagement(prop); 
			int cnt1 =  countCon(db.connection(), cntCpyckv, filename);
			int cnt2 =  countCon(db.connection(), cntBatch, batchRefNo);
			if(cnt1>=1|| cnt2>=1){
				chk =  true;
			} 
		} catch(Exception e){
			logger.error(""+e.getLocalizedMessage());
		}

		return chk;
	}







}
