package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import obj.CheuqeDataModel;
import obj.CheuqeMainDataModel;
import obj.Tranfile;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.tmb.business.PutFileSFTP;

import connect.DbManagement;
import tmb.com.config.CSVManagementFile;


public class TestMove {

	public static String config = System.getProperty("user.dir") + "/config/config.properties";
	private static CheuqeMainDataModel cheuqeMainDataModel =null ;
	private static int countChqPaid = 0;
	private static int countChqOther = 0;
	
	final static Logger logger = Logger.getLogger(TestMove.class);
	
	/*public static void main(String[] args)  throws InterruptedException, IOException {
		//PAYREQTRF_CIB_MCL_00000014619043_0541065538_20190827022809_00535.TXT_SAFE.FILE_MISSING
		String fileName = "D:/app/CHQ/CHQ/RPMD190927.R01";
		cheuqeMainDataModel = new CheuqeMainDataModel();
		
		List<String> dataList = CSVManagementFile.readTextFile(fileName);
		  
		
		dataList.stream().filter(ftl -> !ftl.isEmpty() && ftl.startsWith("D")  )
		.forEach(df -> {
			System.out.println(""+df);
			System.out.println(" cheuqe no.=|"+df.substring(8, 17).trim()+"| status =|"+df.substring(175, 176).trim()+"| paid date =|"+df.substring(38, 44).trim()+"|");
			 if(df.substring(175, 176).trim().equalsIgnoreCase("P")){
				 countChqPaid++; 
			 }else{
				 countChqOther++;
			 }
		});

		System.out.println("countChqPaid= "+countChqPaid+" , countChqOther= "+countChqOther);
		
		PutFileSFTP p = new PutFileSFTP(null);
		 



	}*/
	
	public  CheuqeDataModel checkDataInPH(Connection conn,String cheuqeNo) throws SQLException {

        logger.info("checkDataInPH starting..");

        CheuqeDataModel cheuqeDataModel = new CheuqeDataModel();
        
        PreparedStatement preStmt = null;

 
        try {
            preStmt = conn.prepareStatement("select CHEQUE_STATUS,cheque_number  from ECECUSER.CQDT  where  cheque_number =?  and  rownum <=1 order  by r_cre_time desc ");
            preStmt.setString(1, cheuqeNo);
            ResultSet rs = preStmt.executeQuery();
 
            if (rs.next()) {
            	cheuqeDataModel.setCheuqeStatusDb(rs.getString(1));
            	cheuqeDataModel.setCheuqeNo(rs.getString(2));
            }else{
            	cheuqeDataModel = null;
            }

            preStmt.close();
 

        } catch (Exception e) {
            logger.error(e.getLocalizedMessage());
            e.printStackTrace();
        } finally {
            preStmt.close();
        }

        return cheuqeDataModel;
    }
	

	/*public static void main(String[] args)  throws InterruptedException, IOException {
		 Properties prop = new Properties();
		 String  po = "PAYREQCHQ_CIB_00000000821390_20190726090610_00005.TXT";

		 System.out.println("found file name mismatch PAYREQCHQ_ == "+po.startsWith("PAYREQCHQ_"));

		 if(po.indexOf("PAYREQCHQ_")>0){
			 System.out.println("found file name mismatch PAYREQCHQ_ == "+po);
		 }

		try {
            if (StringUtils.isEmpty(config)) {
                config = System.getProperty("user.dir") + "/config/config.properties";
            }

            System.out.println(config);
            prop.load(new FileInputStream(config));

            String prefixSmart[] = prop.getProperty("PREFIX_SMART") !=null?prop.getProperty("PREFIX_SMART").split(","):null ;

            for(String tr : prefixSmart){
            	System.out.println("out== "+tr);

            }
            String prefixChq[] = prop.getProperty("PREFIX_CHQ") !=null?prop.getProperty("PREFIX_CHQ").split(","):null ;  
            for(String tr : prefixChq){
            	System.out.println("chq out== "+tr);

            }
		}catch(Exception e){

		}
        File source = new File("d:/Users/47758/Desktop/Issue_daily/20190730/lib_node1_batch.zip");
        File dest = new File("d:/Users/47758/Desktop/Issue_daily/20190801/NODE1/lib_node1_batch.zip");

        File dest1 = new File("d:/Users/47758/Desktop/Issue_daily/20190801/NODE1/lib_node1_batch.zip");
        File dest2 = new File("d:/Users/47758/Desktop/Issue_daily/20190801/NODE2/lib_node1_batch.zip");
        File dest3 = new File("d:/Users/47758/Desktop/Issue_daily/20190801/NODE3/lib_node1_batch.zip");
        File dest4 = new File("d:/Users/47758/Desktop/Issue_daily/20190801/NODE4/lib_node1_batch.zip");

        dest1.delete();
        dest2.delete();
        dest3.delete();
        dest4.delete();
        //copy file conventional way using Stream
        long start = new Date().getTime();
        copyFileUsingStream(source, dest);
        Date d1 = new Date(start);

       // TmbUtility.diffTime(d1, new Date());
        System.out.println("Time taken by Stream Copy = "+TmbUtility.diffTime(d1, new Date()));

        //copy files using java.nio FileChannel
        //source = new File("/Users/pankaj/tmp/sourceChannel.avi");
        dest = new File("d:/Users/47758/Desktop/Issue_daily/20190801/NODE2/lib_node1_batch.zip");
        start = System.currentTimeMillis();
        copyFileUsingChannel(source, dest);
        d1 = new Date(start);
        //TmbUtility.diffTime(d1, new Date());

        System.out.println("Time taken by Channel Copy = "+TmbUtility.diffTime(d1, new Date()));

        //copy files using apache commons io
       // source = new File("/Users/pankaj/tmp/sourceApache.avi");
        dest = new File("d:/Users/47758/Desktop/Issue_daily/20190801/NODE3/lib_node1_batch.zip");
        start = System.currentTimeMillis();
        copyFileUsingApacheCommonsIO(source, dest);
        d1 = new Date(start);
       // TmbUtility.diffTime(d1, new Date());

        System.out.println("Time taken by Apache Commons IO Copy = "+TmbUtility.diffTime(d1, new Date()));

        //using Java 7 Files class
       // source = new File("/Users/pankaj/tmp/sourceJava7.avi");
        dest = new File("d:/Users/47758/Desktop/Issue_daily/20190801/NODE4/lib_node1_batch.zip");
        start = System.currentTimeMillis();
        copyFileUsingJava7Files(source, dest);
        d1 = new Date(start);
       // TmbUtility.diffTime(d1, new Date());

        System.out.println("Time taken by Java7 Files Copy = "+TmbUtility.diffTime(d1, new Date()));        
    }
	private static void copyFileUsingJava7Files(File source, File dest) throws IOException {
	    Files.copy(source.toPath(), dest.toPath());
	}
	private static void copyFileUsingApacheCommonsIO(File source, File dest) throws IOException {
	    FileUtils.copyFile(source, dest);
	}
	private static void copyFileUsingChannel(File source, File dest) throws IOException {
	    FileChannel sourceChannel = null;
	    FileChannel destChannel = null;
	    try {
	        sourceChannel = new FileInputStream(source).getChannel();
	        destChannel = new FileOutputStream(dest).getChannel();
	        destChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
	       }finally{
	           sourceChannel.close();
	           destChannel.close();
	   }
	}

	private static void copyFileUsingStream(File source, File dest) throws IOException {
	    InputStream is = null;
	    OutputStream os = null;
	    try {
	        is = new FileInputStream(source);
	        os = new FileOutputStream(dest);
	        byte[] buffer = new byte[1024];
	        int length;
	        while ((length = is.read(buffer)) > 0) {
	            os.write(buffer, 0, length);
	        }
	    } finally {
	        is.close();
	        os.close();
	    }
	}
	 */
}
