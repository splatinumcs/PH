package com.tmb.business;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException; 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List; 
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
 
import obj.TransResponseModel;
import obj.TrantrackingReport;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.jcraft.jsch.JSchException;

import tmb.com.config.CSVManagementFile;
import tmb.com.config.ConnectDB;
import tmb.com.config.TmbUtility;
import util.Constant;
import connect.DbManagement;
import connect.EmailService;
import connect.FileSFTP;

public class PickupPprProcessing {
	final static Logger logger = Logger.getLogger(PickupPprProcessing.class);
	private Properties prop; 
	private Properties propInput; 
	private  List<TransResponseModel> responseFileList = new ArrayList<>();
	private  String searchRefNo = null;
	private FileSFTP fileSFTP = null;
	private static File pathSrc = new File("/app/PHCheckDeleteFile/TEMP_CONFIG"); 
	private static String sftpPath = "/paymenthub/UAT/PMH/Report/GENREPORT/";
	private static String fileNameScript = "Scripts_Report.txt";
	private  static String fileNameConfig = "Config_Report.properties";
	private  static String SPLIT_PI = "|";

	private List<TransResponseModel> transList= new ArrayList<TransResponseModel>();

	public PickupPprProcessing(Properties prop) {
		this.prop = prop; 
	}
	public void process(){
		fileSFTP = new FileSFTP(prop);
		logger.info("############# START CHECK PickupPPRTransaction###################");


		try {
			FileUtils.cleanDirectory(pathSrc);
			fileSFTP.getFileFromSftpParam(sftpPath, pathSrc.getAbsolutePath(), fileNameConfig, false);

			String  listFile [] = pathSrc.list();

			if(listFile !=null && listFile.length>=1){

				String script = "";
				propInput = new Properties();
				propInput.load(new FileInputStream(new File(pathSrc.getAbsolutePath()+"/"+fileNameConfig)));
				if(propInput.getProperty("READ_FROM_PROPERTIRES") !=null 
						&& propInput.getProperty("READ_FROM_PROPERTIRES").trim().equalsIgnoreCase("Y")){
					script = propInput.getProperty("SCRIPTS_SQL");
				}else{
					fileSFTP.getFileFromSftpParam(sftpPath, pathSrc.getAbsolutePath(), fileNameScript, false);

					script =  CSVManagementFile.readTextFileSQlScript(pathSrc.getAbsolutePath()+"/"+fileNameScript).toString();
				}

				List<String> temp  =  inquiryDataforGenReport(script) ; 

				String sharePath = pathSrc.getAbsolutePath()+ "/Report_" + TmbUtility.formateDateYYYYMMDD(new Date()) + ".csv";

				CSVManagementFile.fileWriter(null, null, temp, sharePath);
				try {
					File reportFile  = new File(sharePath);

					String out = "FILE_REPORT_" +TmbUtility.formateDateYYYYMMDD(new Date())+"."+ Constant.TypeFile.ZIP;
					FileOutputStream fos = new FileOutputStream(out);
					ZipOutputStream zos = new ZipOutputStream(fos);
					ZipEntry ze = new ZipEntry(reportFile.getName()); 
					zos.putNextEntry(ze); 
					FileInputStream in = new FileInputStream(reportFile.getAbsoluteFile());
					IOUtils.write(IOUtils.toByteArray(in), zos);
					in.close();

					zos.closeEntry(); 
					zos.close(); 
					logger.debug("Output to Zip : " + out + " Complete!!"+System.getProperty("user.dir") + "/"+out);
					new EmailService(prop).sendEmailAttachedFile(new File(System.getProperty("user.dir") + "/"+out),prop,propInput);
				} catch (IOException e) {
					logger.error(e);
					e.printStackTrace();
				}

			}


		}catch(Exception e){
			//logger.info("########### case 1 error not found Config_Report.properties ");
			e.printStackTrace();
		}




		logger.info("############# START CHECK PickupPPRTransaction###################");
	}


	public List<String> inquiryDataforGenReport(String scripts) throws SQLException {
		DbManagement db = new DbManagement(prop);

		Connection conn = db.connection(); 
		List<String> list = new ArrayList<String>();
		ResultSet rs = null;
		ResultSet rs2 = null;
		//logger.info("inquiryDataforGenReport == "+scripts);
		PreparedStatement preStmt = conn.prepareStatement(scripts);
		try {
			int numberOfColumns =  0;
			rs = preStmt.executeQuery();
			StringBuilder  header =  new StringBuilder();
			ResultSetMetaData rsMetaData = rs.getMetaData();
			numberOfColumns = rsMetaData.getColumnCount();

			if(rs !=null){

				while (rs.next()) { 
					StringBuilder tempData = new StringBuilder();

					//logger.info(numberOfColumns+" numberOfColumns 1 = ");

					for(int col=1;col<=numberOfColumns;col++){
						//logger.info(" 2 = "+rs.getString(2));
						tempData.append(rs.getString(col)+SPLIT_PI);
						//logger.info(" rs2.getString(col) = "+rs.getString(col));
					}
					if(tempData.toString().length()>=1){
						tempData = new StringBuilder(tempData.toString().substring(0, tempData.length()-1));
					}
					list.add(tempData.toString());
					logger.info(" tempData = "+tempData.toString());
				}
				if (list.isEmpty()) {
					logger.info("No Tranfile pending");
				} else {
					logger.info("Complete Tranfile pending!!");
				}



				logger.info("numberOfColumns = "+numberOfColumns); 
				for (int i = 1; i < numberOfColumns + 1; i++) {
					String columnName = rsMetaData.getColumnName(i);
					header.append(columnName+SPLIT_PI); 
				} 
				if(header.toString().length()>=1){
					header = new StringBuilder(header.toString().substring(0, header.length()-1));
				}
				logger.info("numberOfColumns = "+numberOfColumns); 
				logger.info(" header = "+header.toString());
				list.add(0,header.toString());

			} 
			//rs2 = preStmt.executeQuery();


		} finally {
			if (rs != null) {
				try {
					ConnectDB.closeResultSet(rs);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}if (rs2 != null) {
				try {
					ConnectDB.closeResultSet(rs2);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (preStmt != null) {
				try {
					ConnectDB.closePreparedStatement(preStmt);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					ConnectDB.closeConnection(conn);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		logger.info(" list = "+list.size());

		return list;
	}

	private String appendData(TrantrackingReport tranfile) {
		StringBuilder stemp = new StringBuilder();
		stemp.append(tranfile.toString());

		return stemp.toString();

	}

	private void processPutFileOnSFTP() {
		//CSVManagementFile.fileWriter(fileHeader, fileFooter, dataList, filenameOut);

		List<String> dataList = new ArrayList<String>();

		if(responseFileList !=null &&responseFileList.size()>0){
			//CSVManagementFile.fileWriter(destinationFolderFileCore, fileName, bytesArray);
			responseFileList.stream().forEach(fl ->
			{ 
				try {
					if(fl.getFileName() !=null){
						boolean status = fileSFTP.putResponseFileToSftp(fl.getFileName(),sftpPath);
						fl.setUploadFile(status);
						logger.info(fl.getFileName()+" upload status was "+status);
						dataList.add(fl.toString());
					} 
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
			if(dataList !=null &&dataList.size()>0){
				CSVManagementFile.fileWriter(null, null, dataList, System.getProperty("user.dir") + "/LOG/LOGS_PUT_FILE_SFTP_"+TmbUtility.sdfYYYYMMDDHHmmss.format(new Date())+".log");
			} 

		}
		responseFileList = new ArrayList<TransResponseModel>();
		transList= new ArrayList<TransResponseModel>();

	}
	private    void searchStringFromFile() {

		responseFileList = new ArrayList<>();
		transList.stream().forEach(batchNo -> {

			searchRefNo = batchNo.getBatRefNo();
			if(!TmbUtility.isNull(searchRefNo)){
				Arrays.stream(pathSrc.list()).forEach(fb -> { 
					String fileName = pathSrc+File.separator+fb.trim();
					Path path = Paths.get(fileName);


					try(Stream <String> streamOfLines = Files.lines(path,Charset.defaultCharset())) {
						// Filter all male students
						List<String> list = streamOfLines
								.filter(s-> s.contains(searchRefNo) )
								.collect(Collectors.toList());

						if(list !=null&&list.size()>0){
							//logger.info(" searchRefNo = found "+fileName);
							responseFileList.add( new TransResponseModel(searchRefNo,fileName,true));
						} else{
							//logger.info(" searchRefNo not found ");
							responseFileList.add( new TransResponseModel(searchRefNo,null,false));
						}
					}catch(Exception e) {  }


				});
			} 
		});


		logger.info("############# searchStringFromFile ###################");
		searchRefNo = null;
		//responseFileList.forEach(System.out::println);

	}

	public static void readStringFromFile(String fileName,String searchTerm) {

		List<String> list = new ArrayList<>();

		try (Stream<String> stream = Files.lines(Paths.get(fileName))) {

			//1. filter line 3
			//2. convert all content to upper case
			//3. convert it into a List
			stream
			.filter(x -> searchTerm.indexOf(x)>0)
			.forEach(System.out::println);
			//System.out.println("count : "+ count);


		} catch (IOException e) {
			e.printStackTrace();
		}

		list.forEach(System.out::println);

	}


	public static void FileWordCount(String args[]) {
		long wordCount = 0;
		Path textFilePath = Paths.get("C:\\JavaBrahman\\WordCount.txt");
		try {
			Stream<String> fileLines = Files.lines(textFilePath, Charset.defaultCharset());
			wordCount = fileLines.flatMap(line -> Arrays.stream(line.split(" "))).count();
		} catch (IOException ioException) {
			ioException.printStackTrace();
		}
		System.out.println("Number of words in WordCount.txt: "+ wordCount);
	}





}
