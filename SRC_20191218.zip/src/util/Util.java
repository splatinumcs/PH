package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.Arrays;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Util {
   /* public static void main( String[] args ) {

        changeFileLastModified();

    }*/


    private static void zip(){

        byte[] buffer = new byte[1024];

        try{

            File file = new File("logs");

            FileOutputStream fos = new FileOutputStream("D:\\MyFile.zip");
            ZipOutputStream zos = new ZipOutputStream(fos);

            for (File f : file.listFiles()) {
                ZipEntry ze= new ZipEntry(f.getName());
                zos.putNextEntry(ze);
                System.out.println(f.getAbsoluteFile());
                FileInputStream in = new FileInputStream(f.getAbsoluteFile());

                int len;
                while ((len = in.read(buffer)) > 0) {
                    zos.write(buffer, 0, len);
                }

                in.close();
            }

            zos.closeEntry();
            //remember close it
            zos.close();

            System.out.println("Done");

        }catch(IOException ex){
            ex.printStackTrace();
        }
    }

    private static void changeFileLastModified() {

        File file = new File("t1/app/staging/in/cib/FILEBKUP/");

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date newDate = new Date();

        Arrays.stream(file.listFiles()).forEach(f->{
            System.out.println("Original Last Modified Date : "
                    + sdf.format(f.lastModified()));

            f.setLastModified(newDate.getTime());

            System.out.println("Lastest Last Modified Date : "
                    + sdf.format(f.lastModified()));
        });

    }

}
