package util;

public final class Constant {


    public final class Part{
        public static final String GET  = "get";
        public static final String COMPARE  = "compare";
        public static final String DELETE  = "delete";
        public static final String TRANTRACKING_REPORT  = "TRANTRACKING_REPORT";
        
        public static final String RECON_CIB_PH  = "RECON_CIB_PH";
    } 
    public final class DoAction{
        public static final String CHECK_TRANS_RESPONSE  = "CHECK_TRANS_RESPONSE"; 
        public static final String MODE_AUTO_DELETE  = "MODE_AUTO_DELETE"; 
        public static final String AUTO_PUT_SFTP_FILE  = "AUTO_PUT_SFTP_FILE"; 
        public static final String COMPARE_FILE_MESSAGE_GEN  = "COMPARE_FILE_MESSAGE_GEN"; 
        public static final String CLEAR_TEMP_NOTI  = "CLEAR_TEMP_NOTI"; 
        public static final String PICKUP_PPR_STRUCK  = "PICKUP_PPR_STRUCK"; 
        public static final String PICKUP_FOR_GEN_REPORT  = "PICKUP_FOR_GEN_REPORT"; 
    }
    
    public final class ProductCode{
        public static final String MCL  = "MCL"; 
        public static final String SCS  = "SCS"; 
        public static final String BNT  = "BNT"; 
        public static final String CHQ  = "CHQ"; 
        public static final String WHT  = "WHT"; 
        public static final String PPR  = "PPR"; 
        public static final String PAY  = "PAY"; 
        public static final String DDS  = "DDS"; 
        public static final String DCS  = "DCS"; 
        public static final String CHQ_INC  = "INC"; 
        public static final String CHQ_CCP  = "CCP"; 
        public static final String CHQ_IND  = "IND"; 
        public static final String CHQ_COP  = "COP"; 
        public static final String CHQ_DDP  = "DDP"; 
        public static final String CHQ_MCP  = "MCP"; 
        public static final String CHQ_WHT  = "WHT"; 
        //'CCP','INC','IND','COP','DDP','MCP','WHT'
    }


    public final class Session{
        public static final String OPEN_CHANNEL = "sftp";
    }
    public final class DashbStatus{
    	
    	public static final  String  REJECTED = "J";
    	public static final  String  CENCEL_O= "O";
    	public static final  String  SUSPENSE= "H";
    	public static final  String  PROCESS= "R";
    	public static final  String  CANCEL_C= "C";
    	public static final  String  COMPLETED= "CL";
    	public static final  String  DEBIT_PENDING= "DP";
    	public static final  String  DEBIT_RETRY= "DR";
    	public static final  String  INPROGRESS= "IP";
    	public static final  String  SUCCESS= "S";
    	public static final  String  HOLD_PENDING= "HP";
    	public static final  String  HOLD_RETRY= "HR";
    	public static final  String  PARTIALLY_COMPLETED= "PC";
    	public static final  String  PARTIAL_DEBIT= "PD";
    	public static final  String  PARTIAL_SUSPENSE= "PH";
    	public static final  String  PARTIAL_RETRY= "PR";
    	public static final  String  OTHER= "OTH";
    	public static final  String  CRP_SUSPENSE= "CH";
    	
    	
    	public static final  String  DEBIT_TODAY= "Y";
    	 
    	
    }

    public final class Folder{
        public static final String Temp = "temp_file_node_";
        public static final String TempFilePO = "D:/app/staging/in/cib/TMB_FILE_PO/";
        public static final String TempFilePOBK = "D:/app/staging/in/cib/TMB_FILE_PO/BK/";
         public static final String LINUX_TempFilePO = "/app/staging/in/cib/TMB_FILE_PO/";
        public static final String LINUX_TempFilePOBK = "/app/staging/in/cib/TMB_FILE_PO/BK/";
        public static final String TMB_LOGS_REPORTS = "/payhshare/Finacle/ONS_LOGS/TMB_LOGS_REPORTS/";
        public static final String TMB_LOGS_TRANS_RES = "/payhshare/Finacle/ONS_LOGS/TMB_LOGS_TRANS_RES/";
        
        public static final String RESULT = "result";
    }

    public final class DbCol{
        public static final String UPLOAD_DATE = "UPLOAD_DATE";
        public static final String FILE_NAME = "FILE_NAME";
        public static final String SANITY_STATUS = "SANITY_STATUS";
        public static final String ERR_DESC = "ERR_DESC";
    }

    public final class TypeFile{
        public static final String ZIP = "zip";
        public static final String ERR = ".ERR";
        public static final String MSS = ".MSS";
    }

    public final class CharSet{
        public static final String UTF = "UTF-8";
        public static final String HTML_TYPE = "text/html; charset=utf-8";
    }
    public final class ParamerConfig{
        public static final String FORCE_DELETE = "FORCE";
         public static final String AUTO_DELETE = "AUTO";
         public static final String AUTO_MOVE_FILE_PO = "AUTO";
    }

    public final class Cryto {
        public static final String ALGORITHM = "AES";
        public static final String KEY = "1Hbfh667adfDEJ78";
    }
}